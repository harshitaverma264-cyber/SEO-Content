import { MonthlyData, ContentItem, ContentType, FunnelStage, ContentAction, Region, mFilterItSolution, IcpPersona, Priority, PotentialLevel } from '../types/seo';
import { enrichContentItemWithRealKeywords } from '../data/keywordDataRepository';
import {
  LiveMFilterItArticle,
  compareTopicAgainstLiveBlogs,
  generateLiveCannibalizationAlerts,
  baselineMFilterItBlogs
} from './liveBlogAnalysis';

const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

interface MonthlyTheme {
  theme: string;
  focusRegion: Region;
  primaryKeyword: string;
  solution: mFilterItSolution;
  persona: IcpPersona;
}

const SEASONAL_THEMES: Record<number, MonthlyTheme> = {
  1: {
    theme: 'Q1 Enterprise Mobile Acquisition & App Install Security',
    focusRegion: 'MENA',
    primaryKeyword: 'app install fraud uae ecommerce',
    solution: 'Ad Fraud Detection',
    persona: 'Performance Marketing Head'
  },
  2: {
    theme: 'Ramadan Campaign Brand Safety & Super Bowl Video Extensions',
    focusRegion: 'MENA',
    primaryKeyword: 'ramadan campaign brand safety mena',
    solution: 'Brand Safety',
    persona: 'Brand Safety Head'
  },
  3: {
    theme: 'IPL Live Sports CTV Video Fraud & BFSI Year-End Compliance',
    focusRegion: 'INDIA',
    primaryKeyword: 'ott ad fraud detection india',
    solution: 'Ad Fraud Detection',
    persona: 'Performance Marketing Head'
  },
  4: {
    theme: 'Eid Regional Shopping Peak & Affiliate Compliance',
    focusRegion: 'MENA',
    primaryKeyword: 'affiliate compliance ksa ecommerce',
    solution: 'Affiliate Monitoring / Affiliate Fraud Detection',
    persona: 'Affiliate Marketing Head'
  },
  5: {
    theme: 'Memorial Day Summer Retail & Programmatic Brand Protection',
    focusRegion: 'USA',
    primaryKeyword: 'programmatic brand safety filters',
    solution: 'Brand Safety',
    persona: 'Brand Safety Head'
  },
  6: {
    theme: 'Mid-Year Marketplace MAP Enforcement & Prime Day Readiness',
    focusRegion: 'USA',
    primaryKeyword: 'map violation monitoring amazon',
    solution: 'Digital Shelf / Marketplace Monitoring',
    persona: 'E-commerce Head'
  },
  7: {
    theme: 'Back-to-School Retail Surge & Social Commerce Safeguards',
    focusRegion: 'USA',
    primaryKeyword: 'unauthorized reseller enforcement',
    solution: 'Digital Shelf / Marketplace Monitoring',
    persona: 'E-commerce Head'
  },
  8: {
    theme: 'Pre-Festive Marketplace Ramp-Up & D2C Price Integrity',
    focusRegion: 'INDIA',
    primaryKeyword: 'amazon india buy box protection',
    solution: 'Digital Shelf / Marketplace Monitoring',
    persona: 'E-commerce Head'
  },
  9: {
    theme: 'Flipkart Big Billion Days, Amazon GIF & GITEX Summit Prep',
    focusRegion: 'INDIA',
    primaryKeyword: 'marketplace brand protection india',
    solution: 'Affiliate Monitoring / Affiliate Fraud Detection',
    persona: 'Affiliate Marketing Head'
  },
  10: {
    theme: 'Diwali Festive Shopping Peak & GITEX Global B2B Week',
    focusRegion: 'INDIA',
    primaryKeyword: 'brand bidding affiliate fraud india',
    solution: 'Affiliate Monitoring / Affiliate Fraud Detection',
    persona: 'Affiliate Marketing Head'
  },
  11: {
    theme: 'Black Friday, Cyber Monday & White Friday E-Commerce Peak',
    focusRegion: 'USA',
    primaryKeyword: 'cookie stuffing affiliate fraud',
    solution: 'Affiliate Monitoring / Affiliate Fraud Detection',
    persona: 'Affiliate Marketing Head'
  },
  12: {
    theme: 'Dubai Shopping Festival (DSF) & Q4 Holiday Campaign Retrospective',
    focusRegion: 'MENA',
    primaryKeyword: 'app install fraud uae ecommerce',
    solution: 'Ad Fraud Detection',
    persona: 'Performance Marketing Head'
  }
};

const SEED_TOPIC_TEMPLATES: {
  contentType: ContentType;
  funnel: FunnelStage;
  action: ContentAction;
  region: Region;
  solution: mFilterItSolution;
  persona?: IcpPersona;
  keyword: string;
  topicTitlePattern: (monthName: string, year: number) => string;
}[] = [
  // =========================================================================
  // 1. 15 Website Blogs (5 India, 5 USA, 5 MENA)
  // =========================================================================
  // India (5)
  { contentType: 'Website Blog', funnel: 'BOFU', action: 'NEW', region: 'INDIA', solution: 'Affiliate Monitoring / Affiliate Fraud Detection', persona: 'Affiliate Marketing Head', keyword: 'brand bidding affiliate fraud india', topicTitlePattern: (m, y) => `Affiliate Growth vs Brand Infringement: 5 Signs Rogue Partners Are Cannibalizing Paid Search (${m} ${y})` },
  { contentType: 'Website Blog', funnel: 'MOFU', action: 'NEW', region: 'INDIA', solution: 'Ad Fraud Detection', persona: 'Performance Marketing Head', keyword: 'ott ad fraud detection india', topicTitlePattern: (m, y) => `Connected TV & OTT Ad Fraud: How SSAI Spoofing Drains Streaming Budgets and How to Audit Placements (${m} ${y})` },
  { contentType: 'Website Blog', funnel: 'TOFU', action: 'SUPPORTING', region: 'INDIA', solution: 'Creative Compliance', persona: 'Brand Protection Head', keyword: 'creative compliance automation bfsi', topicTitlePattern: (m, y) => `Automating Ad Creative Compliance Trails: Meeting ASCI & BFSI Mandates in ${y}` },
  { contentType: 'Website Blog', funnel: 'BOFU', action: 'NEW', region: 'INDIA', solution: 'Digital Shelf / Marketplace Monitoring', persona: 'E-commerce Head', keyword: 'amazon india buy box protection', topicTitlePattern: (m, y) => `Amazon India Buy Box Defense: How D2C Brands Eliminate Unauthorized Resellers (${m} ${y})` },
  { contentType: 'Website Blog', funnel: 'MOFU', action: 'REVAMP', region: 'INDIA', solution: 'Ad Fraud Detection', persona: 'Performance Marketing Head', keyword: 'app install fraud detection india', topicTitlePattern: (m, y) => `Mobile App Install Fraud & SDK Spoofing: Root Cause Analysis for Indian Growth Marketers (${m} ${y})` },

  // USA (5)
  { contentType: 'Website Blog', funnel: 'BOFU', action: 'REVAMP', region: 'USA', solution: 'Affiliate Monitoring / Affiliate Fraud Detection', persona: 'Affiliate Marketing Head', keyword: 'cookie stuffing affiliate fraud', topicTitlePattern: (m, y) => `Stopping Cookie Stuffing & Attribution Theft: How Rogue Affiliates Exploit Search Budgets (${m} ${y})` },
  { contentType: 'Website Blog', funnel: 'BOFU', action: 'NEW', region: 'USA', solution: 'Digital Shelf / Marketplace Monitoring', persona: 'E-commerce Head', keyword: 'map violation monitoring amazon', topicTitlePattern: (m, y) => `Amazon Buy Box Defense: 4 Early Warning Signals of Price Scraping & MAP Undercutting (${m} ${y})` },
  { contentType: 'Website Blog', funnel: 'MOFU', action: 'EXPAND', region: 'USA', solution: 'Brand Safety', persona: 'Brand Safety Head', keyword: 'programmatic brand safety filters', topicTitlePattern: (m, y) => `Pre-Bid Avoidance vs. Post-Bid Verification: Why Viewability Isn't Catching Sophisticated Invalid Traffic (${m} ${y})` },
  { contentType: 'Website Blog', funnel: 'TOFU', action: 'SUPPORTING', region: 'USA', solution: 'Brand Protection', persona: 'Brand Protection Head', keyword: 'unauthorized reseller enforcement', topicTitlePattern: (m, y) => `Brand Infringement in Retail: How Counterfeit Listings Target Customers and How to Protect Them (${m} ${y})` },
  { contentType: 'Website Blog', funnel: 'BOFU', action: 'NEW', region: 'USA', solution: 'Ad Fraud Detection', persona: 'CMO', keyword: 'best ad fraud detection software', topicTitlePattern: (m, y) => `Enterprise Ad Fraud Detection Software: Comparing Valid8 vs Legacy Verification Tools (${y})` },

  // MENA (5)
  { contentType: 'Website Blog', funnel: 'MOFU', action: 'EXPAND', region: 'MENA', solution: 'Brand Safety', persona: 'Brand Safety Head', keyword: 'ramadan campaign brand safety mena', topicTitlePattern: (m, y) => `Ramadan Campaign Brand Safety: Contextual AI Vetting Across Arabic Video & Social Channels (${y})` },
  { contentType: 'Website Blog', funnel: 'BOFU', action: 'NEW', region: 'MENA', solution: 'Digital Shelf / Marketplace Monitoring', persona: 'E-commerce Head', keyword: 'noon express price scraping monitoring', topicTitlePattern: (m, y) => `Noon & Amazon AE Buy-Box Strategy: Stopping Price Scraping Bots in UAE & KSA (${m} ${y})` },
  { contentType: 'Website Blog', funnel: 'MOFU', action: 'NEW', region: 'MENA', solution: 'Ad Fraud Detection', persona: 'Performance Marketing Head', keyword: 'app install fraud uae ecommerce', topicTitlePattern: (m, y) => `Are You Paying for Clicks, or Paying for Users? Why App Install Fraud Begins Before the Install (${m} ${y})` },
  { contentType: 'Website Blog', funnel: 'BOFU', action: 'NEW', region: 'MENA', solution: 'Affiliate Monitoring / Affiliate Fraud Detection', persona: 'Affiliate Marketing Head', keyword: 'affiliate compliance ksa ecommerce', topicTitlePattern: (m, y) => `MENA E-Commerce Ramadan Prep: Preventing Affiliate Fraud & Fake Leads (${m} ${y})` },
  { contentType: 'Website Blog', funnel: 'MOFU', action: 'REVAMP', region: 'MENA', solution: 'Ad Fraud Detection', persona: 'Digital Marketing Head', keyword: 'mobile ad fraud', topicTitlePattern: (m, y) => `Ad Fraud Prevention for Super-Apps & Mobile Gaming in GCC Markets (${m} ${y})` },

  // =========================================================================
  // 2. 23 SEO / Guest Posts (8 India, 8 USA, 7 MENA)
  // =========================================================================
  // India (8)
  { contentType: 'SEO / Guest Post', funnel: 'MOFU', action: 'NEW', region: 'INDIA', solution: 'Ad Fraud Detection', persona: 'Performance Marketing Head', keyword: 'invalid traffic ivt filtering', topicTitlePattern: (m, y) => `Invalid Traffic (IVT) Filtering: The Performance Marketer’s Audit Guide (${m} ${y})` },
  { contentType: 'SEO / Guest Post', funnel: 'MOFU', action: 'NEW', region: 'INDIA', solution: 'Digital Shelf / Marketplace Monitoring', persona: 'E-commerce Head', keyword: 'flipkart price scraping prevention', topicTitlePattern: (m, y) => `Marketplace Price Scraping Prevention: Preserving D2C Margins on Flipkart & Amazon (${m} ${y})` },
  { contentType: 'SEO / Guest Post', funnel: 'BOFU', action: 'NEW', region: 'INDIA', solution: 'Affiliate Monitoring / Affiliate Fraud Detection', persona: 'Affiliate Marketing Head', keyword: 'quick commerce buy box monitoring', topicTitlePattern: (m, y) => `Quick Commerce Buy Box Defense: Stopping Out-of-Stock Suppression on Blinkit, Zepto, and Instamart (${m} ${y})` },
  { contentType: 'SEO / Guest Post', funnel: 'TOFU', action: 'NEW', region: 'INDIA', solution: 'Creative Compliance', persona: 'Brand Protection Head', keyword: 'asci ad compliance automated audit', topicTitlePattern: (m, y) => `Automating ASCI & RBI Financial Ad Disclosure Compliance in BFSI (${m} ${y})` },
  { contentType: 'SEO / Guest Post', funnel: 'BOFU', action: 'NEW', region: 'INDIA', solution: 'Ad Fraud Detection', persona: 'Performance Marketing Head', keyword: 'ad fraud detection bangalore', topicTitlePattern: (m, y) => `Enterprise Ad Spend Leakage & Invalid Traffic Audit — Bangalore & Gurgaon Tech Hubs (${m} ${y})` },
  { contentType: 'SEO / Guest Post', funnel: 'MOFU', action: 'NEW', region: 'INDIA', solution: 'Digital Shelf / Marketplace Monitoring', persona: 'E-commerce Head', keyword: 'ecommerce monitoring gurgaon', topicTitlePattern: (m, y) => `D2C Marketplace Buy-Box Protection & MAP Enforcement Clinic (${m} ${y})` },
  { contentType: 'SEO / Guest Post', funnel: 'TOFU', action: 'NEW', region: 'INDIA', solution: 'Brand Protection', keyword: 'brand safety visual guide', topicTitlePattern: (m, y) => `Visual Guide: 8 Early Signs Your Affiliates Are Bidding on Your Brand Trademark (${m} ${y})` },
  { contentType: 'SEO / Guest Post', funnel: 'TOFU', action: 'NEW', region: 'INDIA', solution: 'Creative Compliance', keyword: 'financial ad compliance visual', topicTitlePattern: (m, y) => `Compliance Matrix: Financial Ad Creative Regulatory Approval Standards in India (${m} ${y})` },

  // USA (8)
  { contentType: 'SEO / Guest Post', funnel: 'BOFU', action: 'EXPAND', region: 'USA', solution: 'Affiliate Monitoring / Affiliate Fraud Detection', persona: 'Affiliate Marketing Head', keyword: 'rogue affiliate brand hijacking', topicTitlePattern: (m, y) => `Rogue Affiliate Brand Hijacking: How Search Poaching Inflates Enterprise CPCs by 30% (${y})` },
  { contentType: 'SEO / Guest Post', funnel: 'TOFU', action: 'SUPPORTING', region: 'USA', solution: 'Brand Safety', persona: 'Brand Safety Head', keyword: 'brand suitability garm', topicTitlePattern: (m, y) => `Brand Safety Floors vs. Brand Suitability Frameworks: Applying GARM Standards in Programmatic Buying (${y})` },
  { contentType: 'SEO / Guest Post', funnel: 'BOFU', action: 'NEW', region: 'USA', solution: 'Ad Fraud Detection', persona: 'Performance Marketing Head', keyword: 'high cpm video ad fraud protection', topicTitlePattern: (m, y) => `High-CPM Video Ad Fraud: Eliminating Domain Spoofing in Premium Programmatic Channels (${m} ${y})` },
  { contentType: 'SEO / Guest Post', funnel: 'TOFU', action: 'SUPPORTING', region: 'USA', solution: 'Ad Fraud Detection', persona: 'CMO', keyword: 'ad fraud mitigation enterprise', topicTitlePattern: (m, y) => `Enterprise Ad Spend Wastage Audits: What CMOs Must Demand from Media Verification (${m} ${y})` },
  { contentType: 'SEO / Guest Post', funnel: 'TOFU', action: 'NEW', region: 'USA', solution: 'Ad Fraud Detection', keyword: 'click injection vs click spamming', topicTitlePattern: (m, y) => `Architecture Diagram: Click Injection vs Click Spamming in Mobile Performance Campaigns (${y})` },
  { contentType: 'SEO / Guest Post', funnel: 'TOFU', action: 'NEW', region: 'USA', solution: 'Digital Shelf / Marketplace Monitoring', keyword: 'map violation monitoring amazon', topicTitlePattern: (m, y) => `Infographic: The Anatomy of an Amazon Buy Box Suppression Attack (${y})` },
  { contentType: 'SEO / Guest Post', funnel: 'BOFU', action: 'NEW', region: 'USA', solution: 'Affiliate Monitoring / Affiliate Fraud Detection', persona: 'Affiliate Marketing Head', keyword: 'affiliate fraud audit usa', topicTitlePattern: (m, y) => `North America Affiliate Partner Compliance & Commission Fraud Audits (${m} ${y})` },
  { contentType: 'SEO / Guest Post', funnel: 'TOFU', action: 'NEW', region: 'USA', solution: 'Brand Protection', keyword: 'brand protection software usa', topicTitlePattern: (m, y) => `Enterprise Brand Protection & Anti-Counterfeit Office Hours (${m} ${y})` },

  // MENA (7)
  { contentType: 'SEO / Guest Post', funnel: 'MOFU', action: 'NEW', region: 'MENA', solution: 'Affiliate Monitoring / Affiliate Fraud Detection', persona: 'Affiliate Marketing Head', keyword: 'affiliate compliance ksa ecommerce', topicTitlePattern: (m, y) => `Partner Marketing Compliance in KSA & UAE: Navigating GCC Affiliate Transparency (${m} ${y})` },
  { contentType: 'SEO / Guest Post', funnel: 'TOFU', action: 'SUPPORTING', region: 'MENA', solution: 'Creative Compliance', persona: 'Brand Protection Head', keyword: 'google ads competitor brand hijacking uae', topicTitlePattern: (m, y) => `Protecting Paid Search Budgets from Competitor Brand Bidding in GCC Markets (${m} ${y})` },
  { contentType: 'SEO / Guest Post', funnel: 'MOFU', action: 'NEW', region: 'MENA', solution: 'Digital Shelf / Marketplace Monitoring', keyword: 'noon express price scraping', topicTitlePattern: (m, y) => `Real-Time Price Scraping Flow on Regional GCC Marketplaces (${y})` },
  { contentType: 'SEO / Guest Post', funnel: 'BOFU', action: 'NEW', region: 'MENA', solution: 'Brand Safety', persona: 'Brand Safety Head', keyword: 'brand safety services dubai', topicTitlePattern: (m, y) => `GCC Regional Brand Safety & Contextual Video Vetting — Dubai Media City (${m} ${y})` },
  { contentType: 'SEO / Guest Post', funnel: 'BOFU', action: 'NEW', region: 'MENA', solution: 'Creative Compliance', persona: 'Brand Protection Head', keyword: 'ad compliance advisory riyadh', topicTitlePattern: (m, y) => `Financial Ad Creative Regulatory Compliance — Riyadh Regional Hub (${m} ${y})` },
  { contentType: 'SEO / Guest Post', funnel: 'MOFU', action: 'NEW', region: 'MENA', solution: 'Brand Safety', persona: 'Brand Safety Head', keyword: 'ramadan campaign checklist', topicTitlePattern: (m, y) => `Audit Checklist: Ramadan Digital Campaign Placement Vetting & Suitability (${m} ${y})` },
  { contentType: 'SEO / Guest Post', funnel: 'MOFU', action: 'NEW', region: 'MENA', solution: 'Ad Fraud Detection', persona: 'Performance Marketing Head', keyword: 'fraud detection uae', topicTitlePattern: (m, y) => `Preventing Ad Campaign Leakage Across Dubai & Abu Dhabi Enterprises (${m} ${y})` },

  // =========================================================================
  // 3. 2 Infographics (1 India, 1 MENA)
  // =========================================================================
  { contentType: 'Infographic', funnel: 'TOFU', action: 'NEW', region: 'INDIA', solution: 'Affiliate Monitoring / Affiliate Fraud Detection', keyword: 'brand bidding affiliate fraud', topicTitlePattern: (m, y) => `Infographic: 7 Red Flags of Affiliate Brand Bidding & Attribution Cannibalization (${m} ${y})` },
  { contentType: 'Infographic', funnel: 'TOFU', action: 'NEW', region: 'MENA', solution: 'Brand Safety', keyword: 'ramadan campaign brand safety mena', topicTitlePattern: (m, y) => `Infographic: MENA Brand Safety & Contextual Placement Risk Matrix (${m} ${y})` },

  // =========================================================================
  // 4. 10 Glossary items overall
  // =========================================================================
  { contentType: 'Glossary', funnel: 'TOFU', action: 'NEW', region: 'OVERALL', solution: 'Ad Fraud Detection', keyword: 'what is click injection', topicTitlePattern: (m, y) => `Glossary: What is Click Injection in Mobile Performance Advertising? (${y})` },
  { contentType: 'Glossary', funnel: 'TOFU', action: 'NEW', region: 'OVERALL', solution: 'Affiliate Monitoring / Affiliate Fraud Detection', keyword: 'what is cookie stuffing', topicTitlePattern: (m, y) => `Glossary: What is Cookie Stuffing & How Does It Drain Affiliate Budgets? (${y})` },
  { contentType: 'Glossary', funnel: 'TOFU', action: 'NEW', region: 'OVERALL', solution: 'Brand Safety', keyword: 'what is brand suitability floor', topicTitlePattern: (m, y) => `Glossary: What is a Brand Suitability Floor in Programmatic Buying? (${y})` },
  { contentType: 'Glossary', funnel: 'TOFU', action: 'NEW', region: 'OVERALL', solution: 'Digital Shelf / Marketplace Monitoring', keyword: 'what is map violation', topicTitlePattern: (m, y) => `Glossary: What is Minimum Advertised Price (MAP) Violation on Marketplaces? (${y})` },
  { contentType: 'Glossary', funnel: 'TOFU', action: 'NEW', region: 'OVERALL', solution: 'Ad Fraud Detection', keyword: 'what is invalid traffic ivt', topicTitlePattern: (m, y) => `Glossary: What is Invalid Traffic (IVT) & General vs Sophisticated IVT (SIVT)? (${y})` },
  { contentType: 'Glossary', funnel: 'TOFU', action: 'NEW', region: 'OVERALL', solution: 'Creative Compliance', keyword: 'what is ad creative compliance', topicTitlePattern: (m, y) => `Glossary: What is Automated Ad Creative Compliance in Regulated Industries? (${y})` },
  { contentType: 'Glossary', funnel: 'TOFU', action: 'NEW', region: 'OVERALL', solution: 'Brand Protection', keyword: 'what is brand infringement', topicTitlePattern: (m, y) => `Glossary: What is Online Trademark Infringement & Counterfeit Detection? (${y})` },
  { contentType: 'Glossary', funnel: 'TOFU', action: 'NEW', region: 'OVERALL', solution: 'Ad Fraud Detection', keyword: 'what is ctv ad fraud', topicTitlePattern: (m, y) => `Glossary: What is Connected TV (CTV) & OTT Ad Fraud? (${y})` },
  { contentType: 'Glossary', funnel: 'TOFU', action: 'NEW', region: 'OVERALL', solution: 'Affiliate Monitoring / Affiliate Fraud Detection', keyword: 'what is brand bidding', topicTitlePattern: (m, y) => `Glossary: What is Brand Bidding in Paid Search & PPC? (${y})` },
  { contentType: 'Glossary', funnel: 'TOFU', action: 'NEW', region: 'OVERALL', solution: 'Digital Shelf / Marketplace Monitoring', keyword: 'what is buy box suppression', topicTitlePattern: (m, y) => `Glossary: What is Marketplace Buy Box Suppression & MAP Enforcement? (${y})` }
];

function getConsultativeCta(solution: mFilterItSolution): string {
  if (solution.includes('Affiliate')) return 'Request Free Affiliate Traffic & Brand Bidding Audit';
  if (solution.includes('Ad Fraud')) return 'Schedule Enterprise Ad Fraud Assessment with mFilterIt';
  if (solution.includes('Brand Protection')) return 'Run a Complimentary Brand Infringement Scan';
  if (solution.includes('Digital Shelf')) return 'Request Digital Shelf & Buy Box Health Check';
  if (solution.includes('Creative Compliance')) return 'Schedule Automated Ad Creative Compliance Demo';
  if (solution.includes('Brand Safety')) return 'Request Contextual Brand Safety & Suitability Audit';
  return 'Request Free Enterprise Digital Trust Audit';
}

function getDiagnosticRationale(solution: mFilterItSolution, funnel: FunnelStage, monthLabel: string, theme: string): string {
  if (solution.includes('Affiliate')) {
    return `Diagnostic focus: Up to 43% of affiliate traffic in competitive retail is invalid. Closes attribution cannibalization and stops trademark poaching during ${monthLabel} (${theme}).`;
  }
  if (solution.includes('Ad Fraud')) {
    return `Data-backed focus: Sophisticated bot networks and SSAI manipulation drain up to 25% of media budgets. Establishes full-funnel verification across programmatic and CTV in ${monthLabel}.`;
  }
  if (solution.includes('Digital Shelf')) {
    return `Commercial margin defense: Unauthorized seller discounting and Buy Box suppression reduce sales velocity. Enforces MAP adherence and automated pricing intelligence in ${monthLabel}.`;
  }
  if (solution.includes('Brand Protection')) {
    return `Asset protection focus: Lookalike domains and counterfeit listings erode consumer trust. Delivers continuous threat detection and rapid enforcement for ${monthLabel}.`;
  }
  if (solution.includes('Brand Safety')) {
    return `Risk avoidance focus: Balances campaign reach with brand suitability floors across regional channels to prevent toxic content adjacency in ${monthLabel}.`;
  }
  if (solution.includes('Creative Compliance')) {
    return `Regulatory audit trail: Automates ASCI & regulatory ad disclosures to eliminate compliance fines and pre-screen creatives during ${monthLabel}.`;
  }
  return `Strategic ${funnel} initiative aligned with ${theme} during ${monthLabel}.`;
}

export function generateMonthDataFor(
  year: number,
  month: number,
  liveBlogs: LiveMFilterItArticle[] = baselineMFilterItBlogs,
  allUrls: Array<{ url: string; slug: string; topicLabel: string }> = []
): MonthlyData {
  const monthFormatted = month < 10 ? `0${month}` : `${month}`;
  const monthKey = `${year}-${monthFormatted}`;
  const monthName = MONTH_NAMES[month - 1];
  const monthLabel = `${monthName} ${year}`;

  const seasonalTheme = SEASONAL_THEMES[month] || {
    theme: `Enterprise SEO & Ad Integrity Optimization for ${monthName} ${year}`,
    focusRegion: 'OVERALL' as Region,
    primaryKeyword: 'ad fraud detection software',
    solution: 'Ad Fraud Detection' as mFilterItSolution,
    persona: 'CMO' as IcpPersona
  };

  const items: ContentItem[] = SEED_TOPIC_TEMPLATES.map((tmpl, idx) => {
    const day = (idx % 28) + 1;
    const dayFormatted = day < 10 ? `0${day}` : `${day}`;
    const dateStr = `${monthKey}-${dayFormatted}`;
    const topic = tmpl.topicTitlePattern(monthName, year);

    // Live mFilterIt blog comparison: detect genuine gaps vs cannibalization
    const liveComparison = compareTopicAgainstLiveBlogs(topic, tmpl.keyword, liveBlogs, allUrls);
    const resolvedAction: ContentAction = liveComparison.isCannibalizing ? liveComparison.recommendedAction : tmpl.action;

    const baseDiagnostic = getDiagnosticRationale(tmpl.solution, tmpl.funnel, monthLabel, seasonalTheme.theme);
    const combinedRationale = `${liveComparison.gapRationale} | ${baseDiagnostic}`;

    const isHighPriority = idx % 3 === 0 || tmpl.funnel === 'BOFU';
    const priority: Priority = isHighPriority ? 'High' : idx % 2 === 0 ? 'Medium' : 'Low';
    const potential: PotentialLevel = isHighPriority ? 'High' : 'Medium';

    const rawItem: ContentItem = {
      id: `${monthKey.replace('-', '')}-${tmpl.contentType.toLowerCase().replace(/[^a-z0-9]/g, '')}-${idx + 1}`,
      date: dateStr,
      contentType: tmpl.contentType,
      topic: topic,
      primaryKeyword: tmpl.keyword,
      focusKeyword: tmpl.keyword,
      region: tmpl.region === 'OVERALL' ? seasonalTheme.focusRegion : tmpl.region,
      productMapping: tmpl.solution,
      icpPersona: tmpl.persona || seasonalTheme.persona,
      searchIntent: tmpl.funnel === 'BOFU' ? 'Transactional' : tmpl.funnel === 'MOFU' ? 'Commercial Investigation' : 'Informational',
      funnelStage: tmpl.funnel,
      priority: priority,
      leadPotential: potential,
      conversionPotential: potential,
      contentAction: resolvedAction,
      leadRationale: combinedRationale,
      status: 'Planned',
      recommendedCta: getConsultativeCta(tmpl.solution),
      referenceLink: liveComparison.matchedLiveBlog ? liveComparison.matchedLiveBlog.url : undefined
    };

    return enrichContentItemWithRealKeywords(rawItem);
  });

  // Generate verified cannibalization alerts against real live published mFilterIt articles
  const cannibalizationAlerts = generateLiveCannibalizationAlerts(items, liveBlogs);

  return {
    monthKey,
    monthLabel,
    year,
    month,
    summaryNotes: `Strategic Focus for ${monthLabel}: ${seasonalTheme.theme}. Targeted campaigns across ${seasonalTheme.focusRegion} markets with primary focus on ${seasonalTheme.solution}. Live analysis verified against ${liveBlogs.length}+ published mFilterIt blog assets to identify genuine gaps and prevent cannibalization.`,
    cannibalizationAlerts,
    items
  };
}

// Pre-build full 2026 and 2027 monthly datasets
export function generateAll2026And2027MonthlyData(): Record<string, MonthlyData> {
  const result: Record<string, MonthlyData> = {};

  // 2026: October to December
  [10, 11, 12].forEach((m) => {
    const key = `2026-${m < 10 ? '0' : ''}${m}`;
    result[key] = generateMonthDataFor(2026, m);
  });

  // 2027: January to December
  for (let m = 1; m <= 12; m++) {
    const key = `2027-${m < 10 ? '0' : ''}${m}`;
    result[key] = generateMonthDataFor(2027, m);
  }

  return result;
}
