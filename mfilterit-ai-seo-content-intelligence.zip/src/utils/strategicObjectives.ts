import { StrategicObjective, ContentItem } from '../types/seo';

export interface StrategicObjectiveMeta {
  id: StrategicObjective;
  label: string;
  shortLabel: string;
  description: string;
  badgeBg: string;
  badgeText: string;
  badgeBorder: string;
  activeBg: string;
  activeText: string;
  activeBorder: string;
  iconSymbol: string;
  alignedFunnelStages: string[];
}

export const ALL_STRATEGIC_OBJECTIVES: StrategicObjectiveMeta[] = [
  {
    id: 'Brand Awareness',
    label: 'Brand Awareness',
    shortLabel: 'Awareness',
    description: 'Build high-visibility search presence, industry authority, and brand recall through educational guides, infographics, and TOFU content.',
    badgeBg: 'bg-purple-50',
    badgeText: 'text-[#530093]',
    badgeBorder: 'border-purple-200',
    activeBg: 'bg-[#530093]',
    activeText: 'text-white',
    activeBorder: 'border-[#530093]',
    iconSymbol: '✨',
    alignedFunnelStages: ['TOFU']
  },
  {
    id: 'Website Traffic Increase',
    label: 'Website Traffic Increase',
    shortLabel: 'Traffic',
    description: 'Drive high-volume organic search visitors by capturing high search volume keywords, glossary terms, and guest post backlink networks.',
    badgeBg: 'bg-blue-50',
    badgeText: 'text-blue-800',
    badgeBorder: 'border-blue-200',
    activeBg: 'bg-blue-700',
    activeText: 'text-white',
    activeBorder: 'border-blue-700',
    iconSymbol: '📈',
    alignedFunnelStages: ['TOFU', 'MOFU']
  },
  {
    id: 'Lead Generation',
    label: 'Lead Generation',
    shortLabel: 'Leads',
    description: 'Capture decision-maker leads with commercial investigation topics, audit frameworks, whitepapers, and free risk assessments.',
    badgeBg: 'bg-amber-50',
    badgeText: 'text-amber-900',
    badgeBorder: 'border-amber-200',
    activeBg: 'bg-amber-600',
    activeText: 'text-white',
    activeBorder: 'border-amber-600',
    iconSymbol: '🎯',
    alignedFunnelStages: ['MOFU', 'BOFU']
  },
  {
    id: 'Conversions',
    label: 'Conversions',
    shortLabel: 'Conversions',
    description: 'Convert bottom-of-funnel buyers using transactional keywords, software comparisons, buy-box defense, and high conversion potential offers.',
    badgeBg: 'bg-emerald-50',
    badgeText: 'text-emerald-900',
    badgeBorder: 'border-emerald-200',
    activeBg: 'bg-emerald-700',
    activeText: 'text-white',
    activeBorder: 'border-emerald-700',
    iconSymbol: '⚡',
    alignedFunnelStages: ['BOFU']
  },
  {
    id: 'Market Expansion',
    label: 'Market Expansion',
    shortLabel: 'Expansion',
    description: 'Expand enterprise market share across regional growth hubs (India, USA, and MENA) tailored to localized campaign events and compliance.',
    badgeBg: 'bg-rose-50',
    badgeText: 'text-rose-900',
    badgeBorder: 'border-rose-200',
    activeBg: 'bg-rose-700',
    activeText: 'text-white',
    activeBorder: 'border-rose-700',
    iconSymbol: '🌍',
    alignedFunnelStages: ['TOFU', 'MOFU', 'BOFU']
  }
];

/**
 * Determine which strategic objectives a content item aligns with based on its metadata.
 */
export function getItemStrategicObjectives(item: ContentItem): StrategicObjective[] {
  if (item.strategicObjectives && item.strategicObjectives.length > 0) {
    return item.strategicObjectives;
  }

  const objectives: Set<StrategicObjective> = new Set();

  const sv = item.primarySearchVolume || item.searchVolume || 0;
  const funnel = item.funnelStage || 'MOFU';
  const intent = item.searchIntent || 'Commercial Investigation';
  const type = item.contentType;
  const region = item.region;
  const leadPot = item.leadPotential || 'Medium';
  const convPot = item.conversionPotential || 'Medium';

  // 1. Brand Awareness
  if (
    funnel === 'TOFU' ||
    type === 'Infographic' ||
    intent === 'Informational' ||
    item.productMapping === 'Brand Safety' ||
    item.productMapping === 'Brand Protection'
  ) {
    objectives.add('Brand Awareness');
  }

  // 2. Website Traffic Increase
  if (
    sv >= 1000 ||
    type === 'SEO / Guest Post' ||
    type === 'Glossary' ||
    funnel === 'TOFU' ||
    funnel === 'MOFU'
  ) {
    objectives.add('Website Traffic Increase');
  }

  // 3. Lead Generation
  if (
    funnel === 'MOFU' ||
    leadPot === 'High' ||
    intent === 'Commercial Investigation' ||
    item.productMapping === 'Affiliate Monitoring / Affiliate Fraud Detection' ||
    item.productMapping === 'Ad Fraud Detection'
  ) {
    objectives.add('Lead Generation');
  }

  // 4. Conversions
  if (
    funnel === 'BOFU' ||
    convPot === 'High' ||
    intent === 'Transactional' ||
    item.contentAction === 'REVAMP' ||
    item.contentAction === 'EXPAND' ||
    item.productMapping === 'Digital Shelf / Marketplace Monitoring'
  ) {
    objectives.add('Conversions');
  }

  // 5. Market Expansion
  if (
    region === 'INDIA' ||
    region === 'USA' ||
    region === 'MENA' ||
    item.topic.toLowerCase().includes('india') ||
    item.topic.toLowerCase().includes('usa') ||
    item.topic.toLowerCase().includes('mena') ||
    item.topic.toLowerCase().includes('ramadan') ||
    item.topic.toLowerCase().includes('diwali') ||
    item.topic.toLowerCase().includes('black friday')
  ) {
    objectives.add('Market Expansion');
  }

  return Array.from(objectives);
}

/**
 * Check if a content item aligns with ANY of the user's active selected strategic objectives.
 */
export function isItemAlignedWithObjectives(
  item: ContentItem,
  activeObjectives: StrategicObjective[]
): boolean {
  if (!activeObjectives || activeObjectives.length === 0) {
    return true; // No filter active = all items included
  }

  const itemObjs = getItemStrategicObjectives(item);
  return activeObjectives.some((obj) => itemObjs.includes(obj));
}

/**
 * Calculate alignment score (0 - 100) for a content item given active strategic objectives.
 */
export function calculateObjectiveAlignmentScore(
  item: ContentItem,
  activeObjectives: StrategicObjective[]
): number {
  if (!activeObjectives || activeObjectives.length === 0) return 100;

  const itemObjs = getItemStrategicObjectives(item);
  const matchCount = activeObjectives.filter((obj) => itemObjs.includes(obj)).length;

  if (matchCount === 0) return 0;
  return Math.round((matchCount / activeObjectives.length) * 100);
}
