import { TrustPillar, mFilterItSolution } from '../types/seo';

/**
 * Accurately determines the authoritative Trust Pillar for any content item or opportunity
 * according to the exact mFilterIt corporate hierarchy:
 *
 * 1. Media Trust:
 *    - Ad Traffic Validation: Full Funnel Ad Traffic Validation, Branding Campaign Validation,
 *      Performance Campaign Validation (Web Traffic Validation, App Ad Traffic Validation,
 *      Affiliate Fraud Detection & Monitoring, Direct Carrier Billing Fraud Detection)
 *    - Brand Safety & Suitability Monitoring
 *    - Measurement: Digital Commerce Intelligence (Digital Shelf, Buy Box, MAP Monitoring)
 *    - Agentic AI: mPulse Ecommerce, mPulse Branding
 *
 * 2. Brand Trust:
 *    - Brand Protection
 *    - Counterfeit Detection
 *
 * 3. Financial Trust:
 *    - Digital Scam Monitoring & Detection
 *    - Merchant Onboarding Screening & Risk Verification
 *    - Mule Account & Transaction Laundering Monitoring
 */
export function getTrustPillarForItem(item: {
  trustPillar?: TrustPillar;
  productMapping?: string;
  solution?: string;
  topic?: string;
  focusKeyword?: string;
  primaryKeyword?: string;
}): TrustPillar {
  const mapping = (item.productMapping || item.solution || '').trim();
  const mappingLower = mapping.toLowerCase();
  const text = `${item.topic || ''} ${item.focusKeyword || ''} ${item.primaryKeyword || ''}`.toLowerCase();

  // 1. FINANCIAL TRUST CHECKS
  if (
    mappingLower === 'digital scam monitoring & detection' ||
    mappingLower === 'merchant onboarding screening & risk verification' ||
    mappingLower === 'mule account & transaction laundering monitoring' ||
    text.includes('mule account') ||
    text.includes('transaction laundering') ||
    text.includes('merchant onboarding') ||
    text.includes('merchant screening') ||
    text.includes('merchant risk') ||
    text.includes('digital scam') ||
    text.includes('scam monitoring') ||
    text.includes('synthetic identity') ||
    text.includes('banking fraud') ||
    text.includes('loan fraud')
  ) {
    return 'Financial Trust';
  }

  // 2. BRAND TRUST CHECKS
  if (
    mappingLower === 'brand protection' ||
    mappingLower === 'counterfeit detection' ||
    mappingLower === 'creative compliance' ||
    text.includes('brand protection') ||
    text.includes('counterfeit') ||
    text.includes('anti-counterfeit') ||
    text.includes('trademark infringement') ||
    text.includes('lookalike domain') ||
    text.includes('domain spoofing') ||
    text.includes('phishing domain') ||
    text.includes('fake website') ||
    text.includes('executive impersonation') ||
    text.includes('brand impersonation') ||
    text.includes('unauthorized reseller') ||
    text.includes('rogue reseller')
  ) {
    return 'Brand Trust';
  }

  // 3. MEDIA TRUST CHECKS (Primary & Flagship Suite)
  // Ad Traffic Validation, Brand Safety & Suitability, Measurement (Digital Commerce Intelligence / Digital Shelf), Affiliate Monitoring
  if (
    mappingLower.includes('ad fraud') ||
    mappingLower.includes('brand safety') ||
    mappingLower.includes('digital shelf') ||
    mappingLower.includes('digital commerce') ||
    mappingLower.includes('affiliate') ||
    text.includes('brand safety') ||
    text.includes('brand suitability') ||
    text.includes('ad fraud') ||
    text.includes('invalid traffic') ||
    text.includes('ivt') ||
    text.includes('sivt') ||
    text.includes('click fraud') ||
    text.includes('click injection') ||
    text.includes('click spamming') ||
    text.includes('app install fraud') ||
    text.includes('sdk spoofing') ||
    text.includes('ctv') ||
    text.includes('ott') ||
    text.includes('ssai') ||
    text.includes('brand bidding') ||
    text.includes('affiliate fraud') ||
    text.includes('cookie stuffing') ||
    text.includes('digital shelf') ||
    text.includes('buy box') ||
    text.includes('map violation') ||
    text.includes('pricing intelligence') ||
    text.includes('direct carrier billing') ||
    text.includes('dcb') ||
    text.includes('mpulse')
  ) {
    return 'Media Trust';
  }

  // Fallback to explicit item trust pillar if valid, else default to Media Trust
  if (item.trustPillar) {
    return item.trustPillar;
  }

  return 'Media Trust';
}

export interface TrustPillarSubGroup {
  category: string;
  solutions: string[];
}

export interface TrustPillarInfo {
  id: TrustPillar;
  label: string;
  description: string;
  subGroups: TrustPillarSubGroup[];
  solutions: string[];
  colorClass: string;
  badgeBg: string;
  badgeText: string;
  badgeBorder: string;
}

export const ALL_TRUST_PILLARS: TrustPillarInfo[] = [
  {
    id: 'Media Trust',
    label: 'Media Trust',
    description: 'Ad Traffic Validation, Brand Safety & Suitability, Measurement & Agentic AI',
    subGroups: [
      {
        category: 'Ad Traffic Validation',
        solutions: [
          'Full Funnel Ad Traffic Validation',
          'Branding Campaign Validation',
          'Performance Campaign Validation',
          'Web Traffic Validation for Performance Campaigns',
          'App Ad Traffic Validation',
          'Affiliate Fraud Detection & Monitoring',
          'Direct Carrier Billing Fraud Detection'
        ]
      },
      {
        category: 'Brand Safety & Suitability',
        solutions: ['Brand Safety & Suitability Monitoring']
      },
      {
        category: 'Measurement',
        solutions: ['Digital Commerce Intelligence']
      },
      {
        category: 'Agentic AI',
        solutions: ['mPulse Ecommerce', 'mPulse Branding']
      }
    ],
    solutions: [
      'Ad Fraud Detection',
      'Brand Safety & Suitability Monitoring',
      'Digital Commerce Intelligence',
      'Affiliate Fraud Detection & Monitoring'
    ],
    colorClass: '#530093',
    badgeBg: 'bg-purple-50',
    badgeText: 'text-[#530093]',
    badgeBorder: 'border-purple-200',
  },
  {
    id: 'Brand Trust',
    label: 'Brand Trust',
    description: 'Brand Protection & Counterfeit Detection',
    subGroups: [
      {
        category: 'Brand Protection',
        solutions: ['Brand Protection']
      },
      {
        category: 'Counterfeit Detection',
        solutions: ['Counterfeit Detection']
      }
    ],
    solutions: [
      'Brand Protection',
      'Counterfeit Detection'
    ],
    colorClass: '#059669',
    badgeBg: 'bg-emerald-50',
    badgeText: 'text-emerald-800',
    badgeBorder: 'border-emerald-200',
  },
  {
    id: 'Financial Trust',
    label: 'Financial Trust',
    description: 'Digital Scam Monitoring, Merchant Onboarding Risk & Mule Account Detection',
    subGroups: [
      {
        category: 'Digital Scam Defense',
        solutions: ['Digital Scam Monitoring & Detection']
      },
      {
        category: 'Merchant Risk',
        solutions: ['Merchant Onboarding Screening & Risk Verification']
      },
      {
        category: 'Transaction Integrity',
        solutions: ['Mule Account & Transaction Laundering Monitoring']
      }
    ],
    solutions: [
      'Digital Scam Monitoring & Detection',
      'Merchant Onboarding Screening & Risk Verification',
      'Mule Account & Transaction Laundering Monitoring'
    ],
    colorClass: '#d97706',
    badgeBg: 'bg-amber-50',
    badgeText: 'text-amber-800',
    badgeBorder: 'border-amber-200',
  },
];
