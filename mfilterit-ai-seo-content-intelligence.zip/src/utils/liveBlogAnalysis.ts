import { ContentItem, ContentAction, CannibalizationAlert } from '../types/seo';

export interface LiveMFilterItArticle {
  url: string;
  title: string;
  slug: string;
  category?: string;
}

export interface LiveMFilterItBlogsPayload {
  success: boolean;
  isLive?: boolean;
  source?: string;
  error?: string | null;
  totalPublishedArticles: number;
  latestArticles: LiveMFilterItArticle[];
  allPublishedUrls: Array<{ url: string; slug: string; topicLabel: string; category?: string }>;
  fetchedAt: string;
}

export interface LiveBlogComparisonResult {
  isCannibalizing: boolean;
  matchedLiveBlog: {
    url: string;
    title: string;
    slug: string;
    matchType: 'EXACT_KEYWORD' | 'TOPIC_OVERLAP' | 'SLUG_MATCH';
  } | null;
  recommendedAction: ContentAction;
  gapRationale: string;
  cannibalizationRisk: 'HIGH' | 'MEDIUM' | 'LOW' | 'NONE';
  suggestedAngleAdjustment?: string;
}

// Fallback baseline of verified live mFilterIt published blogs
export const baselineMFilterItBlogs: LiveMFilterItArticle[] = [
  {
    url: 'https://www.mfilterit.com/blog/affiliate-fraud-detection-traffic-cannibalization',
    slug: 'affiliate-fraud-detection-traffic-cannibalization',
    title: 'Affiliate Fraud Detection: 5 Signs Your Partners Are Cannibalizing Organic Traffic'
  },
  {
    url: 'https://www.mfilterit.com/blog/brand-infringement-in-banking',
    slug: 'brand-infringement-in-banking',
    title: 'Brand Infringement in Banking: How Fakes Target Your Customers and How to Protect Them'
  },
  {
    url: 'https://www.mfilterit.com/blog/mobile-app-install-fraud',
    slug: 'mobile-app-install-fraud',
    title: 'Are You Paying for Clicks, or Paying for Users? Why App Install Fraud Begins Before the Install'
  },
  {
    url: 'https://www.mfilterit.com/blog/incent-fraud-detection',
    slug: 'incent-fraud-detection',
    title: 'Incent Fraud Detection: Why High-Volume Acquisition Never Becomes Quality Growth'
  },
  {
    url: 'https://www.mfilterit.com/blog/unified-ad-manager-ai-powered-campaign-management',
    slug: 'unified-ad-manager-ai-powered-campaign-management',
    title: 'Unified Ad Manager: How Agentic AI is Changing Campaign Management'
  },
  {
    url: 'https://www.mfilterit.com/blog/invalid-traffic-residential-ad-fraud',
    slug: 'invalid-traffic-residential-ad-fraud',
    title: 'From Data Centres to Living Rooms: How Invalid Traffic is Evolving in 2026'
  },
  {
    url: 'https://www.mfilterit.com/blog/bot-detection-one-tag-ad-fraud',
    slug: 'bot-detection-one-tag-ad-fraud',
    title: 'One Tag for All: The New Tech in Bot Detection to Protect Your Ad Campaigns in 2026'
  },
  {
    url: 'https://www.mfilterit.com/blog/click-fraud-in-google-ads',
    slug: 'click-fraud-in-google-ads',
    title: 'Click Fraud Beyond the Click: Why Traffic Intent Measurement is Important for Google Ads Campaign Success'
  },
  {
    url: 'https://www.mfilterit.com/blog/brand-bidding-monitoring-improve-campaign-performance',
    slug: 'brand-bidding-monitoring-improve-campaign-performance',
    title: 'Brand Bidding Monitoring to Improve PPC Campaign Performance'
  },
  {
    url: 'https://www.mfilterit.com/blog/why-do-map-violations-threaten-ecom-brands',
    slug: 'why-do-map-violations-threaten-ecom-brands',
    title: 'Why MAP Violations Threaten E-Commerce Brands on Amazon & Flipkart'
  },
  {
    url: 'https://www.mfilterit.com/blog/pricing-analysis-across-e-commerce-platforms',
    slug: 'pricing-analysis-across-e-commerce-platforms',
    title: 'Real-Time Pricing Analysis & Buy Box Defense Across E-Commerce Platforms'
  },
  {
    url: 'https://www.mfilterit.com/blog/video-advertising-erode-brand-safety',
    slug: 'video-advertising-erode-brand-safety',
    title: 'How Video Advertising Placements Erode Brand Safety'
  }
];

/**
 * Fetches current published blog URLs and titles from the backend API.
 */
export async function fetchLiveMFilterItBlogs(forceRefresh: boolean = false): Promise<LiveMFilterItBlogsPayload> {
  try {
    const endpoint = forceRefresh ? '/api/mfilterit-blogs?refresh=true' : '/api/mfilterit-blogs';
    const res = await fetch(endpoint);
    if (res.ok) {
      const data = await res.json();
      if (data.latestArticles && data.latestArticles.length > 0) {
        return data;
      }
    }
  } catch (err: any) {
    console.warn('Could not reach /api/mfilterit-blogs, using verified baseline:', err?.message);
  }

  return {
    success: true,
    isLive: false,
    source: 'FALLBACK_BASELINE',
    error: 'Network request failed or timed out',
    totalPublishedArticles: baselineMFilterItBlogs.length,
    latestArticles: baselineMFilterItBlogs,
    allPublishedUrls: baselineMFilterItBlogs.map(b => ({
      url: b.url,
      slug: b.slug,
      topicLabel: b.slug.replace(/-/g, ' '),
      category: 'blog'
    })),
    fetchedAt: new Date().toISOString()
  };
}

/**
 * Compares a candidate topic and focus keyword against the live published blogs
 * to identify genuine content gaps vs. cannibalization risks.
 */
export function compareTopicAgainstLiveBlogs(
  topic: string,
  primaryKeyword: string,
  liveBlogs: LiveMFilterItArticle[] = baselineMFilterItBlogs,
  allUrls: Array<{ url: string; slug: string; topicLabel: string }> = []
): LiveBlogComparisonResult {
  const normTopic = topic.toLowerCase();
  const normKw = primaryKeyword.toLowerCase().trim();

  // 1. Direct search in live featured articles
  for (const blog of liveBlogs) {
    const bTitle = blog.title.toLowerCase();
    const bSlug = blog.slug.toLowerCase().replace(/-/g, ' ');

    // Check exact keyword overlap
    if (bTitle.includes(normKw) || bSlug.includes(normKw)) {
      return {
        isCannibalizing: true,
        matchedLiveBlog: {
          url: blog.url,
          title: blog.title,
          slug: blog.slug,
          matchType: 'EXACT_KEYWORD'
        },
        recommendedAction: 'REVAMP',
        gapRationale: `Live Website Finding: mFilterIt already published "${blog.title}". To avoid SERP cannibalization, update and revamp this existing asset with 2026/2027 telemetry rather than publishing a competing duplicate post.`,
        cannibalizationRisk: 'HIGH',
        suggestedAngleAdjustment: `Anchor target keywords to existing URL (${blog.url}) and add deep-packet forensic case studies.`
      };
    }

    // Check high topic similarity
    const topicWords = normTopic.split(/[^a-z0-9]+/).filter(w => w.length > 4);
    const blogWords = bTitle.split(/[^a-z0-9]+/).filter(w => w.length > 4);
    const commonWords = topicWords.filter(w => blogWords.includes(w));

    if (commonWords.length >= 3) {
      return {
        isCannibalizing: true,
        matchedLiveBlog: {
          url: blog.url,
          title: blog.title,
          slug: blog.slug,
          matchType: 'TOPIC_OVERLAP'
        },
        recommendedAction: 'EXPAND',
        gapRationale: `Live Website Finding: High overlap with existing article "${blog.title}". Expand existing topic into a comprehensive strategic playbook or differentiate by focusing on specialized sub-vectors (e.g. SSAI spoofing or GCC regional channels).`,
        cannibalizationRisk: 'MEDIUM',
        suggestedAngleAdjustment: `Differentiate angle to cover specific operational workflows rather than high-level definitions.`
      };
    }
  }

  // 2. Search against the 450+ sitemap slugs
  if (allUrls.length > 0) {
    for (const item of allUrls) {
      const slugLabel = item.topicLabel.toLowerCase();
      if (normKw.length > 6 && (slugLabel.includes(normKw) || normKw.includes(slugLabel))) {
        return {
          isCannibalizing: true,
          matchedLiveBlog: {
            url: item.url,
            title: `Published Article: ${item.slug}`,
            slug: item.slug,
            matchType: 'SLUG_MATCH'
          },
          recommendedAction: 'REVAMP',
          gapRationale: `Live Website Finding: Existing article found at ${item.url}. Action set to REVAMP to refresh rankings and avoid cannibalization.`,
          cannibalizationRisk: 'HIGH',
          suggestedAngleAdjustment: `Consolidate keyword intent into existing URL.`
        };
      }
    }
  }

  // 3. Genuine content gap detected!
  return {
    isCannibalizing: false,
    matchedLiveBlog: null,
    recommendedAction: 'NEW',
    gapRationale: `Live Website Audit: Verified content gap! No conflicting articles found on mFilterIt.com for "${primaryKeyword}". Prioritized as a fresh high-converting opportunity.`,
    cannibalizationRisk: 'NONE'
  };
}

/**
 * Generates cannibalization alerts for a list of content items against live blogs.
 */
export function generateLiveCannibalizationAlerts(
  items: ContentItem[],
  liveBlogs: LiveMFilterItArticle[]
): CannibalizationAlert[] {
  const alerts: CannibalizationAlert[] = [];

  for (const item of items) {
    const pKw = item.primaryKeyword || item.focusKeyword || '';
    const comparison = compareTopicAgainstLiveBlogs(item.topic, pKw, liveBlogs);

    if (comparison.isCannibalizing && comparison.matchedLiveBlog) {
      alerts.push({
        id: `alert-${item.id}`,
        proposedTopic: item.topic,
        proposedKeyword: pKw,
        existingUrl: comparison.matchedLiveBlog.url,
        existingKeyword: comparison.matchedLiveBlog.title,
        intentSimilarity: comparison.matchedLiveBlog.matchType === 'EXACT_KEYWORD' ? '95% (Exact Keyword Collision)' : '80% (Topical Overlap)',
        riskLevel: comparison.cannibalizationRisk === 'HIGH' ? 'High' : comparison.cannibalizationRisk === 'MEDIUM' ? 'Medium' : 'Low',
        recommendedAction: comparison.recommendedAction === 'REVAMP'
          ? `REVAMP: Existing post "${comparison.matchedLiveBlog.title}" ranks for this query. Refresh existing URL with 2026/2027 telemetry to avoid self-competing SERP cannibalization.`
          : `EXPAND: Topical overlap detected with "${comparison.matchedLiveBlog.title}". Differentiate sub-vectors to preserve crawl budget and topic authority.`,
        solution: item.productMapping
      });
    }
  }

  return alerts;
}
