import { LiveRankingRecord, LiveRankingWorkbookInfo } from '../types/keywordIntelligence';

// Authoritative weekly ranking dataset extracted directly from the uploaded Weekly Keyword Ranking Sheet.xlsx
// Total rows: 211 (India: 81, USA: 66, MENA: 64)
export const WEEKLY_RANKING_DATA: Record<'INDIA' | 'USA' | 'MENA', LiveRankingRecord[]> = {
  "INDIA": [
    {
      "id": "india-live-1",
      "keyword": "click injection",
      "currentPosition": 20,
      "previousPosition": 18,
      "positionChange": -2,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "18",
        "Raw Current Rank": "20"
      }
    },
    {
      "id": "india-live-2",
      "keyword": "click injection fraud",
      "currentPosition": 19,
      "previousPosition": 17,
      "positionChange": -2,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "17",
        "Raw Current Rank": "19"
      }
    },
    {
      "id": "india-live-3",
      "keyword": "impression fraud",
      "currentPosition": 8,
      "previousPosition": 8,
      "positionChange": 0,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "8",
        "Raw Current Rank": "8"
      }
    },
    {
      "id": "india-live-4",
      "keyword": "mobile ad fraud",
      "currentPosition": 15,
      "previousPosition": 15,
      "positionChange": 0,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "15(AI-Overview ) (AI-9)",
        "Raw Current Rank": "15"
      }
    },
    {
      "id": "india-live-5",
      "keyword": "prevent click fraud",
      "currentPosition": 8,
      "previousPosition": 8,
      "positionChange": 0,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "8 (ai-overview)(ai-12)",
        "Raw Current Rank": "8"
      }
    },
    {
      "id": "india-live-6",
      "keyword": "mmp ad",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "100+",
        "Raw Current Rank": "100+"
      }
    },
    {
      "id": "india-live-7",
      "keyword": "ad fraud",
      "currentPosition": 22,
      "previousPosition": 26,
      "positionChange": 4,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 500,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "26",
        "Raw Current Rank": "22"
      }
    },
    {
      "id": "india-live-8",
      "keyword": "ad fraud detection",
      "currentPosition": 35,
      "previousPosition": 28,
      "positionChange": -7,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "28(AI-9)",
        "Raw Current Rank": "35"
      }
    },
    {
      "id": "india-live-9",
      "keyword": "ad fraud prevention",
      "currentPosition": 29,
      "previousPosition": 29,
      "positionChange": 0,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "29(ai-overview)(Ai-6)",
        "Raw Current Rank": "29"
      }
    },
    {
      "id": "india-live-10",
      "keyword": "ad fraud solution",
      "currentPosition": 15,
      "previousPosition": 7,
      "positionChange": -8,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "7",
        "Raw Current Rank": "15"
      }
    },
    {
      "id": "india-live-11",
      "keyword": "ad spoofing",
      "currentPosition": 11,
      "previousPosition": 10,
      "positionChange": -1,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "10 (ai-10)",
        "Raw Current Rank": "11(ai-8)(ai-overview)"
      }
    },
    {
      "id": "india-live-12",
      "keyword": "ctv ad fraud",
      "currentPosition": 4,
      "previousPosition": 2,
      "positionChange": -2,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "2(AI-3)(AI-Overview)",
        "Raw Current Rank": "4(ai-10)(ai-overview)"
      }
    },
    {
      "id": "india-live-13",
      "keyword": "programmatic ad fraud",
      "currentPosition": 4,
      "previousPosition": 6,
      "positionChange": 2,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "6(ai-5)(AI-overview)",
        "Raw Current Rank": "4"
      }
    },
    {
      "id": "india-live-14",
      "keyword": "programmatic fraud",
      "currentPosition": 4,
      "previousPosition": 3,
      "positionChange": -1,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "3(AI-overview)(Ai-3)",
        "Raw Current Rank": "4(ai-4)"
      }
    },
    {
      "id": "india-live-15",
      "keyword": "affiliate fraud",
      "currentPosition": 11,
      "previousPosition": 3,
      "positionChange": -8,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "3",
        "Raw Current Rank": "11(ai-6)"
      }
    },
    {
      "id": "india-live-16",
      "keyword": "affiliate marketing fraud",
      "currentPosition": 31,
      "previousPosition": 7,
      "positionChange": -24,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "7(AI-overview)",
        "Raw Current Rank": "31"
      }
    },
    {
      "id": "india-live-17",
      "keyword": "detect and prevent ad frauds",
      "currentPosition": 28,
      "previousPosition": 36,
      "positionChange": 8,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "36",
        "Raw Current Rank": "28(ai-6)(ai-overview)"
      }
    },
    {
      "id": "india-live-18",
      "keyword": "detecting ad fraud in mobile apps",
      "currentPosition": 36,
      "previousPosition": 12,
      "positionChange": -24,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "12",
        "Raw Current Rank": "36"
      }
    },
    {
      "id": "india-live-19",
      "keyword": "how to prevent ad fraud",
      "currentPosition": 36,
      "previousPosition": 32,
      "positionChange": -4,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "32(AI-Overview)(AI-6)",
        "Raw Current Rank": "36"
      }
    },
    {
      "id": "india-live-20",
      "keyword": "invalid traffic detection",
      "currentPosition": 7,
      "previousPosition": 5,
      "positionChange": -2,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "5",
        "Raw Current Rank": "7(ai-5)"
      }
    },
    {
      "id": "india-live-21",
      "keyword": "fraud advertisement",
      "currentPosition": 15,
      "previousPosition": 7,
      "positionChange": -8,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 500,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "7",
        "Raw Current Rank": "15"
      }
    },
    {
      "id": "india-live-22",
      "keyword": "fraudulent ads",
      "currentPosition": 21,
      "previousPosition": 27,
      "positionChange": 6,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 500,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "27",
        "Raw Current Rank": "21"
      }
    },
    {
      "id": "india-live-23",
      "keyword": "fraudulent traffic",
      "currentPosition": 7,
      "previousPosition": 16,
      "positionChange": 9,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "16",
        "Raw Current Rank": "7(ai-4)"
      }
    },
    {
      "id": "india-live-24",
      "keyword": "digital advertising fraud",
      "currentPosition": 12,
      "previousPosition": 10,
      "positionChange": -2,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "10",
        "Raw Current Rank": "12"
      }
    },
    {
      "id": "india-live-25",
      "keyword": "install fraud",
      "currentPosition": 7,
      "previousPosition": 13,
      "positionChange": 6,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "13",
        "Raw Current Rank": "7(ai-3)"
      }
    },
    {
      "id": "india-live-26",
      "keyword": "install hijacking",
      "currentPosition": 16,
      "movement": "NEWLY RANKING",
      "rankingTrend": "New",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "100+",
        "Raw Current Rank": "16(ai-5)"
      }
    },
    {
      "id": "india-live-27",
      "keyword": "ad fraud solutions",
      "currentPosition": 8,
      "previousPosition": 9,
      "positionChange": 1,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "9(AI-1)(AI-Overview)",
        "Raw Current Rank": "8(ai-13)(ai-overview)"
      }
    },
    {
      "id": "india-live-28",
      "keyword": "click fraud protection software",
      "previousPosition": 27,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "27",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "india-live-29",
      "keyword": "click fraud",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "100+",
        "Raw Current Rank": "100+"
      }
    },
    {
      "id": "india-live-30",
      "keyword": "click fraud software",
      "previousPosition": 24,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "24",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "india-live-31",
      "keyword": "click fraud detection",
      "previousPosition": 14,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "14",
        "Raw Current Rank": "100+"
      }
    },
    {
      "id": "india-live-32",
      "keyword": "ppc fraud protection",
      "currentPosition": 45,
      "previousPosition": 53,
      "positionChange": 8,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "53",
        "Raw Current Rank": "45"
      }
    },
    {
      "id": "india-live-33",
      "keyword": "click fraud protection",
      "currentPosition": 5,
      "previousPosition": 10,
      "positionChange": 5,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "10",
        "Raw Current Rank": "5"
      }
    },
    {
      "id": "india-live-34",
      "keyword": "ad fraud protection",
      "currentPosition": 5,
      "previousPosition": 11,
      "positionChange": 6,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "11",
        "Raw Current Rank": "5"
      }
    },
    {
      "id": "india-live-35",
      "keyword": "ppc fraud",
      "currentPosition": 6,
      "previousPosition": 7,
      "positionChange": 1,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "7",
        "Raw Current Rank": "6(ai-1)"
      }
    },
    {
      "id": "india-live-36",
      "keyword": "ad click fraud",
      "currentPosition": 5,
      "previousPosition": 7,
      "positionChange": 2,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "7",
        "Raw Current Rank": "5"
      }
    },
    {
      "id": "india-live-37",
      "keyword": "ppc click fraud",
      "currentPosition": 46,
      "previousPosition": 50,
      "positionChange": 4,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "50",
        "Raw Current Rank": "46"
      }
    },
    {
      "id": "india-live-38",
      "keyword": "click fraud tools",
      "currentPosition": 8,
      "previousPosition": 7,
      "positionChange": -1,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "7(AI-overview)(AI-3)",
        "Raw Current Rank": "8"
      }
    },
    {
      "id": "india-live-39",
      "keyword": "fraud traffic detection",
      "currentPosition": 15,
      "previousPosition": 17,
      "positionChange": 2,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "17",
        "Raw Current Rank": "15"
      }
    },
    {
      "id": "india-live-40",
      "keyword": "ad fraud software",
      "currentPosition": 24,
      "previousPosition": 27,
      "positionChange": 3,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "27",
        "Raw Current Rank": "24"
      }
    },
    {
      "id": "india-live-41",
      "keyword": "ad fraud bots",
      "currentPosition": 8,
      "previousPosition": 6,
      "positionChange": -2,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "6(AI-2)(ai-overview)",
        "Raw Current Rank": "8(ai-7)"
      }
    },
    {
      "id": "india-live-42",
      "keyword": "pay per click fraud",
      "currentPosition": 50,
      "previousPosition": 64,
      "positionChange": 14,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "64",
        "Raw Current Rank": "50"
      }
    },
    {
      "id": "india-live-43",
      "keyword": "click fraud prevention tools",
      "currentPosition": 1,
      "previousPosition": 6,
      "positionChange": 5,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "6(AI-2) ( AI-Overview)",
        "Raw Current Rank": "1(ai-1)(AI-Overview)"
      }
    },
    {
      "id": "india-live-44",
      "keyword": "click fraud solutions",
      "currentPosition": 4,
      "previousPosition": 6,
      "positionChange": 2,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "6(AI-7)",
        "Raw Current Rank": "4(ai-2)"
      }
    },
    {
      "id": "india-live-45",
      "keyword": "types of ad fraud",
      "currentPosition": 35,
      "previousPosition": 23,
      "positionChange": -12,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "23(ai-overview)(ai-10)",
        "Raw Current Rank": "35(ai-10)(ai-overview)"
      }
    },
    {
      "id": "india-live-46",
      "keyword": "ad fraud tools",
      "currentPosition": 4,
      "previousPosition": 16,
      "positionChange": 12,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "16",
        "Raw Current Rank": "4(ai-8)(ai-overview)"
      }
    },
    {
      "id": "india-live-47",
      "keyword": "advertising fraud detection",
      "currentPosition": 6,
      "previousPosition": 13,
      "positionChange": 7,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "13",
        "Raw Current Rank": "6"
      }
    },
    {
      "id": "india-live-48",
      "keyword": "mobile fraud prevention",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "100+",
        "Raw Current Rank": "100+"
      }
    },
    {
      "id": "india-live-49",
      "keyword": "ad fraud detection tool",
      "currentPosition": 11,
      "previousPosition": 26,
      "positionChange": 15,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "26",
        "Raw Current Rank": "11"
      }
    },
    {
      "id": "india-live-50",
      "keyword": "ad stacking fraud",
      "currentPosition": 3,
      "previousPosition": 4,
      "positionChange": 1,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "4(AI-1)(AI-Overview)",
        "Raw Current Rank": "3(AI-3)(AI-Overview)"
      }
    },
    {
      "id": "india-live-51",
      "keyword": "click scam",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "100+",
        "Raw Current Rank": "100+"
      }
    },
    {
      "id": "india-live-52",
      "keyword": "mobile ad fraud detection",
      "currentPosition": 5,
      "previousPosition": 6,
      "positionChange": 1,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "6(ai-3)",
        "Raw Current Rank": "5"
      }
    },
    {
      "id": "india-live-53",
      "keyword": "mobile fraud prevention solution",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "100+",
        "Raw Current Rank": "100+"
      }
    },
    {
      "id": "india-live-54",
      "keyword": "affiliate marketing software",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "100+",
        "Raw Current Rank": "100+"
      }
    },
    {
      "id": "india-live-55",
      "keyword": "brand safety",
      "currentPosition": 3,
      "previousPosition": 3,
      "positionChange": 0,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 500,
        "Section": "Pace (Brand Safety)",
        "Raw Previous Rank": "3(AI-overview)(Ai-1)",
        "Raw Current Rank": "3"
      }
    },
    {
      "id": "india-live-56",
      "keyword": "brand safety in advertising",
      "currentPosition": 3,
      "previousPosition": 3,
      "positionChange": 0,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Pace (Brand Safety)",
        "Raw Previous Rank": "3(AI-overview)(Ai-1)",
        "Raw Current Rank": "3(AI-overview)(Ai-1)"
      }
    },
    {
      "id": "india-live-57",
      "keyword": "brand safety solutions",
      "currentPosition": 4,
      "previousPosition": 17,
      "positionChange": 13,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Pace (Brand Safety)",
        "Raw Previous Rank": "17(ai-7)(ai-overview)",
        "Raw Current Rank": "4(ai-6)(ai-overview)"
      }
    },
    {
      "id": "india-live-58",
      "keyword": "brand safety tools",
      "currentPosition": 8,
      "previousPosition": 17,
      "positionChange": 9,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Pace (Brand Safety)",
        "Raw Previous Rank": "17",
        "Raw Current Rank": "8"
      }
    },
    {
      "id": "india-live-59",
      "keyword": "brand infringement",
      "currentPosition": 2,
      "previousPosition": 2,
      "positionChange": 0,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 500,
        "Section": "Sentinel+ (Brand Protection)",
        "Raw Previous Rank": "2(AI-4)(ai-overview)",
        "Raw Current Rank": "2(AI-4)(ai-overview)"
      }
    },
    {
      "id": "india-live-60",
      "keyword": "brand protection",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 500,
        "Section": "Sentinel+ (Brand Protection)",
        "Raw Previous Rank": "100+",
        "Raw Current Rank": "100+"
      }
    },
    {
      "id": "india-live-61",
      "keyword": "brand protection solutions",
      "previousPosition": 94,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Sentinel+ (Brand Protection)",
        "Raw Previous Rank": "94",
        "Raw Current Rank": "100+"
      }
    },
    {
      "id": "india-live-62",
      "keyword": "brand impersonation",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Sentinel+ (Brand Protection)",
        "Raw Previous Rank": "100+",
        "Raw Current Rank": "100+"
      }
    },
    {
      "id": "india-live-63",
      "keyword": "brand protection tools",
      "previousPosition": 72,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Sentinel+ (Brand Protection)",
        "Raw Previous Rank": "72",
        "Raw Current Rank": "100+"
      }
    },
    {
      "id": "india-live-64",
      "keyword": "digital shelf monitoring",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "mScanIt (ecommerce intelligence solution)",
        "Raw Previous Rank": "100+",
        "Raw Current Rank": "100+"
      }
    },
    {
      "id": "india-live-65",
      "keyword": "digital shelf analytics",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 500,
        "Section": "mScanIt (ecommerce intelligence solution)",
        "Raw Previous Rank": "100+",
        "Raw Current Rank": "100+"
      }
    },
    {
      "id": "india-live-66",
      "keyword": "digital shelf analytics software",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "mScanIt (ecommerce intelligence solution)",
        "Raw Previous Rank": "100+",
        "Raw Current Rank": "100+"
      }
    },
    {
      "id": "india-live-67",
      "keyword": "ecommerce analytics",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "mScanIt (ecommerce intelligence solution)",
        "Raw Previous Rank": "100+",
        "Raw Current Rank": "100+"
      }
    },
    {
      "id": "india-live-68",
      "keyword": "ecommerce analytics software",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "mScanIt (ecommerce intelligence solution)",
        "Raw Previous Rank": "100+",
        "Raw Current Rank": "100+"
      }
    },
    {
      "id": "india-live-69",
      "keyword": "digital ecommerce solution",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "mScanIt (ecommerce intelligence solution)",
        "Raw Previous Rank": "100+",
        "Raw Current Rank": "100+"
      }
    },
    {
      "id": "india-live-70",
      "keyword": "digital shelf optimization",
      "currentPosition": 70,
      "previousPosition": 19,
      "positionChange": -51,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "mScanIt (ecommerce intelligence solution)",
        "Raw Previous Rank": "19",
        "Raw Current Rank": "70"
      }
    },
    {
      "id": "india-live-71",
      "keyword": "digital commerce analytics",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "mScanIt (ecommerce intelligence solution)",
        "Raw Previous Rank": "100+",
        "Raw Current Rank": "100+"
      }
    },
    {
      "id": "india-live-72",
      "keyword": "brand bidding",
      "currentPosition": 2,
      "previousPosition": 3,
      "positionChange": 1,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "EffCent ( Affiliate Monitoring Tool)",
        "Raw Previous Rank": "3(AI-overview)(Ai-3)",
        "Raw Current Rank": "2(ai-overview)(ai-2)"
      }
    },
    {
      "id": "india-live-73",
      "keyword": "affiliate monitoring",
      "currentPosition": 3,
      "previousPosition": 5,
      "positionChange": 2,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "EffCent ( Affiliate Monitoring Tool)",
        "Raw Previous Rank": "5",
        "Raw Current Rank": "3"
      }
    },
    {
      "id": "india-live-74",
      "keyword": "affiliate brand bidding",
      "currentPosition": 1,
      "previousPosition": 1,
      "positionChange": 0,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "EffCent ( Affiliate Monitoring Tool)",
        "Raw Previous Rank": "1(AI-1)(AI-Overview)",
        "Raw Current Rank": "1(AI-1)(AI-Overview)"
      }
    },
    {
      "id": "india-live-75",
      "keyword": "brand bidding affiliate marketing",
      "currentPosition": 1,
      "previousPosition": 1,
      "positionChange": 0,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "EffCent ( Affiliate Monitoring Tool)",
        "Raw Previous Rank": "1(AI-1)(AI-Overview)",
        "Raw Current Rank": "1(AI-1)(AI-Overview)"
      }
    },
    {
      "id": "india-live-76",
      "keyword": "affiliate fraud detection",
      "currentPosition": 1,
      "previousPosition": 11,
      "positionChange": 10,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "EffCent ( Affiliate Monitoring Tool)",
        "Raw Previous Rank": "11",
        "Raw Current Rank": "1(ai-4)(ai-overview)"
      }
    },
    {
      "id": "india-live-77",
      "keyword": "affiliate fraud",
      "currentPosition": 4,
      "previousPosition": 3,
      "positionChange": -1,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "EffCent ( Affiliate Monitoring Tool)",
        "Raw Previous Rank": "3(ai-8)(ai-overview)",
        "Raw Current Rank": "4(ai-5)"
      }
    },
    {
      "id": "india-live-78",
      "keyword": "affiliate fraud prevention",
      "currentPosition": 3,
      "previousPosition": 3,
      "positionChange": 0,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "EffCent ( Affiliate Monitoring Tool)",
        "Raw Previous Rank": "3(AI-10)",
        "Raw Current Rank": "3"
      }
    },
    {
      "id": "india-live-79",
      "keyword": "affiliate marketing fraud",
      "currentPosition": 3,
      "previousPosition": 24,
      "positionChange": 21,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "EffCent ( Affiliate Monitoring Tool)",
        "Raw Previous Rank": "24",
        "Raw Current Rank": "3(ai-overview)(ai-3)"
      }
    },
    {
      "id": "india-live-80",
      "keyword": "affiliate marketing solutions",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "EffCent ( Affiliate Monitoring Tool)",
        "Raw Previous Rank": "100+",
        "Raw Current Rank": "100+"
      }
    },
    {
      "id": "india-live-81",
      "keyword": "contextual brand safety",
      "currentPosition": 6,
      "previousPosition": 8,
      "positionChange": 2,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "INDIA",
      "date": "Thrusday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "TickR (creative compliance software solution)",
        "Raw Previous Rank": "8(ai-overview)",
        "Raw Current Rank": "6(ai-2)"
      }
    }
  ],
  "USA": [
    {
      "id": "usa-live-1",
      "keyword": "ad fraud detection",
      "currentPosition": 50,
      "previousPosition": 35,
      "positionChange": -15,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "35",
        "Raw Current Rank": "50"
      }
    },
    {
      "id": "usa-live-2",
      "keyword": "ad spoofing",
      "currentPosition": 20,
      "previousPosition": 20,
      "positionChange": 0,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "20",
        "Raw Current Rank": "20"
      }
    },
    {
      "id": "usa-live-3",
      "keyword": "programmatic fraud",
      "currentPosition": 13,
      "previousPosition": 47,
      "positionChange": 34,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "47 (AI-7)",
        "Raw Current Rank": "13 (AI-13)"
      }
    },
    {
      "id": "usa-live-4",
      "keyword": "ad fraud protection",
      "currentPosition": 100,
      "previousPosition": 26,
      "positionChange": -74,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "26",
        "Raw Current Rank": "100"
      }
    },
    {
      "id": "usa-live-5",
      "keyword": "ad fraud solution",
      "currentPosition": 26,
      "previousPosition": 24,
      "positionChange": -2,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "24",
        "Raw Current Rank": "26"
      }
    },
    {
      "id": "usa-live-6",
      "keyword": "mobile ad fraud",
      "currentPosition": 37,
      "previousPosition": 30,
      "positionChange": -7,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "30",
        "Raw Current Rank": "37"
      }
    },
    {
      "id": "usa-live-7",
      "keyword": "programmatic ad fraud",
      "currentPosition": 15,
      "previousPosition": 14,
      "positionChange": -1,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "14",
        "Raw Current Rank": "15"
      }
    },
    {
      "id": "usa-live-8",
      "keyword": "impression fraud",
      "currentPosition": 12,
      "previousPosition": 8,
      "positionChange": -4,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "8 (AI-7)",
        "Raw Current Rank": "12"
      }
    },
    {
      "id": "usa-live-9",
      "keyword": "ctv ad fraud",
      "currentPosition": 23,
      "previousPosition": 11,
      "positionChange": -12,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "11 (AI-4)",
        "Raw Current Rank": "23 (AI-7)"
      }
    },
    {
      "id": "usa-live-10",
      "keyword": "click injection",
      "currentPosition": 18,
      "previousPosition": 13,
      "positionChange": -5,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "13 (AI-11)",
        "Raw Current Rank": "18"
      }
    },
    {
      "id": "usa-live-11",
      "keyword": "click injection fraud",
      "currentPosition": 17,
      "previousPosition": 15,
      "positionChange": -2,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "15",
        "Raw Current Rank": "17"
      }
    },
    {
      "id": "usa-live-12",
      "keyword": "attribution fraud",
      "currentPosition": 36,
      "previousPosition": 36,
      "positionChange": 0,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "36",
        "Raw Current Rank": "36"
      }
    },
    {
      "id": "usa-live-13",
      "keyword": "click spamming",
      "currentPosition": 13,
      "previousPosition": 12,
      "positionChange": -1,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "12",
        "Raw Current Rank": "13"
      }
    },
    {
      "id": "usa-live-14",
      "keyword": "fraudulent impressions",
      "currentPosition": 24,
      "previousPosition": 9,
      "positionChange": -15,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "9",
        "Raw Current Rank": "24"
      }
    },
    {
      "id": "usa-live-15",
      "keyword": "advertising fraud",
      "currentPosition": 55,
      "previousPosition": 50,
      "positionChange": -5,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "50",
        "Raw Current Rank": "55"
      }
    },
    {
      "id": "usa-live-16",
      "keyword": "app advertising fraud",
      "currentPosition": 48,
      "previousPosition": 32,
      "positionChange": -16,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "32",
        "Raw Current Rank": "48"
      }
    },
    {
      "id": "usa-live-17",
      "keyword": "ad fraud detection tools",
      "currentPosition": 19,
      "previousPosition": 100,
      "positionChange": 81,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "100",
        "Raw Current Rank": "19"
      }
    },
    {
      "id": "usa-live-18",
      "keyword": "types of mobile ad fraud",
      "currentPosition": 19,
      "previousPosition": 17,
      "positionChange": -2,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "17 (AI-9)",
        "Raw Current Rank": "19 (AI-9)"
      }
    },
    {
      "id": "usa-live-19",
      "keyword": "ad fraud detection solution",
      "currentPosition": 33,
      "previousPosition": 33,
      "positionChange": 0,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "33",
        "Raw Current Rank": "33"
      }
    },
    {
      "id": "usa-live-20",
      "keyword": "ad fraud detection software",
      "currentPosition": 29,
      "previousPosition": 18,
      "positionChange": -11,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "18",
        "Raw Current Rank": "29"
      }
    },
    {
      "id": "usa-live-21",
      "keyword": "ad fraud tool",
      "currentPosition": 25,
      "previousPosition": 58,
      "positionChange": 33,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "58",
        "Raw Current Rank": "25"
      }
    },
    {
      "id": "usa-live-22",
      "keyword": "ad fraud software",
      "currentPosition": 15,
      "previousPosition": 26,
      "positionChange": 11,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "26",
        "Raw Current Rank": "15"
      }
    },
    {
      "id": "usa-live-23",
      "keyword": "device spoofing",
      "currentPosition": 26,
      "previousPosition": 22,
      "positionChange": -4,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "22",
        "Raw Current Rank": "26"
      }
    },
    {
      "id": "usa-live-24",
      "keyword": "advertising fraud detection software",
      "currentPosition": 26,
      "previousPosition": 26,
      "positionChange": 0,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "26",
        "Raw Current Rank": "26"
      }
    },
    {
      "id": "usa-live-25",
      "keyword": "advertising fraud detection",
      "currentPosition": 100,
      "previousPosition": 33,
      "positionChange": -67,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "33",
        "Raw Current Rank": "100"
      }
    },
    {
      "id": "usa-live-26",
      "keyword": "fraud traffic detection",
      "currentPosition": 16,
      "previousPosition": 50,
      "positionChange": 34,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "50",
        "Raw Current Rank": "16"
      }
    },
    {
      "id": "usa-live-27",
      "keyword": "mobile marketing fraud",
      "currentPosition": 21,
      "previousPosition": 20,
      "positionChange": -1,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "20",
        "Raw Current Rank": "21"
      }
    },
    {
      "id": "usa-live-28",
      "keyword": "what is mobile ad fraud",
      "currentPosition": 28,
      "previousPosition": 24,
      "positionChange": -4,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "24",
        "Raw Current Rank": "28"
      }
    },
    {
      "id": "usa-live-29",
      "keyword": "ad fraud protection",
      "currentPosition": 78,
      "previousPosition": 100,
      "positionChange": 22,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "100",
        "Raw Current Rank": "78"
      }
    },
    {
      "id": "usa-live-30",
      "keyword": "best ad fraud protection tool",
      "currentPosition": 89,
      "previousPosition": 100,
      "positionChange": 11,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "100",
        "Raw Current Rank": "89"
      }
    },
    {
      "id": "usa-live-31",
      "keyword": "fraud in programmatic advertising",
      "currentPosition": 17,
      "previousPosition": 12,
      "positionChange": -5,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "12",
        "Raw Current Rank": "17"
      }
    },
    {
      "id": "usa-live-32",
      "keyword": "click fraud detection software",
      "currentPosition": 100,
      "previousPosition": 14,
      "positionChange": -86,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "14",
        "Raw Current Rank": "100"
      }
    },
    {
      "id": "usa-live-33",
      "keyword": "ad fraud",
      "currentPosition": 41,
      "previousPosition": 100,
      "positionChange": 59,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "100",
        "Raw Current Rank": "41"
      }
    },
    {
      "id": "usa-live-34",
      "keyword": "advertising fraud",
      "currentPosition": 54,
      "previousPosition": 100,
      "positionChange": 46,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "100",
        "Raw Current Rank": "54"
      }
    },
    {
      "id": "usa-live-35",
      "keyword": "ad fraud detection tools",
      "currentPosition": 19,
      "previousPosition": 51,
      "positionChange": 32,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "51",
        "Raw Current Rank": "19"
      }
    },
    {
      "id": "usa-live-36",
      "keyword": "click fraud solutions",
      "currentPosition": 100,
      "previousPosition": 11,
      "positionChange": -89,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "11",
        "Raw Current Rank": "100"
      }
    },
    {
      "id": "usa-live-37",
      "keyword": "ad fraud detection software",
      "currentPosition": 15,
      "previousPosition": 17,
      "positionChange": 2,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "17",
        "Raw Current Rank": "15"
      }
    },
    {
      "id": "usa-live-38",
      "keyword": "digital advertising fraud",
      "currentPosition": 23,
      "previousPosition": 100,
      "positionChange": 77,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "100",
        "Raw Current Rank": "23"
      }
    },
    {
      "id": "usa-live-39",
      "keyword": "ad fraud tools",
      "currentPosition": 100,
      "previousPosition": 17,
      "positionChange": -83,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "17",
        "Raw Current Rank": "100"
      }
    },
    {
      "id": "usa-live-40",
      "keyword": "online ad fraud",
      "currentPosition": 34,
      "previousPosition": 34,
      "positionChange": 0,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "34",
        "Raw Current Rank": "34"
      }
    },
    {
      "id": "usa-live-41",
      "keyword": "click fraud detection",
      "currentPosition": 100,
      "previousPosition": 12,
      "positionChange": -88,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "12",
        "Raw Current Rank": "100"
      }
    },
    {
      "id": "usa-live-42",
      "keyword": "click fraud prevention software",
      "currentPosition": 100,
      "previousPosition": 100,
      "positionChange": 0,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "100",
        "Raw Current Rank": "100"
      }
    },
    {
      "id": "usa-live-43",
      "keyword": "invalid traffic detection",
      "currentPosition": 9,
      "previousPosition": 9,
      "positionChange": 0,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "9",
        "Raw Current Rank": "9 (AI-7)"
      }
    },
    {
      "id": "usa-live-44",
      "keyword": "mobile fraud detection",
      "currentPosition": 88,
      "previousPosition": 86,
      "positionChange": -2,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "86",
        "Raw Current Rank": "88"
      }
    },
    {
      "id": "usa-live-45",
      "keyword": "ppc fraud",
      "currentPosition": 19,
      "previousPosition": 15,
      "positionChange": -4,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "15",
        "Raw Current Rank": "19"
      }
    },
    {
      "id": "usa-live-46",
      "keyword": "click protection",
      "currentPosition": 100,
      "previousPosition": 100,
      "positionChange": 0,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "100",
        "Raw Current Rank": "100"
      }
    },
    {
      "id": "usa-live-47",
      "keyword": "ad hijacking",
      "currentPosition": 37,
      "previousPosition": 100,
      "positionChange": 63,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "100",
        "Raw Current Rank": "37"
      }
    },
    {
      "id": "usa-live-48",
      "keyword": "programmatic advertising",
      "currentPosition": 100,
      "previousPosition": 100,
      "positionChange": 0,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "100",
        "Raw Current Rank": "100"
      }
    },
    {
      "id": "usa-live-49",
      "keyword": "click fraud",
      "currentPosition": 100,
      "previousPosition": 100,
      "positionChange": 0,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "100",
        "Raw Current Rank": "100"
      }
    },
    {
      "id": "usa-live-50",
      "keyword": "bot traffic",
      "currentPosition": 100,
      "previousPosition": 52,
      "positionChange": -48,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "52",
        "Raw Current Rank": "100"
      }
    },
    {
      "id": "usa-live-51",
      "keyword": "mobile fraud prevention",
      "currentPosition": 100,
      "previousPosition": 100,
      "positionChange": 0,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "100",
        "Raw Current Rank": "100"
      }
    },
    {
      "id": "usa-live-52",
      "keyword": "install fraud",
      "currentPosition": 8,
      "previousPosition": 22,
      "positionChange": 14,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "22",
        "Raw Current Rank": "8 (AI-9)"
      }
    },
    {
      "id": "usa-live-53",
      "keyword": "invalid traffic",
      "currentPosition": 12,
      "previousPosition": 10,
      "positionChange": -2,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Valid8 (Ad Fraud)",
        "Raw Previous Rank": "10",
        "Raw Current Rank": "12"
      }
    },
    {
      "id": "usa-live-54",
      "keyword": "brand safety solutions",
      "currentPosition": 13,
      "previousPosition": 11,
      "positionChange": -2,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Pace (Brand Safety)",
        "Raw Previous Rank": "11",
        "Raw Current Rank": "13"
      }
    },
    {
      "id": "usa-live-55",
      "keyword": "brand safety tool",
      "currentPosition": 100,
      "previousPosition": 100,
      "positionChange": 0,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Pace (Brand Safety)",
        "Raw Previous Rank": "100",
        "Raw Current Rank": "100"
      }
    },
    {
      "id": "usa-live-56",
      "keyword": "contextual ads",
      "currentPosition": 100,
      "previousPosition": 100,
      "positionChange": 0,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Pace (Brand Safety)",
        "Raw Previous Rank": "100",
        "Raw Current Rank": "100"
      }
    },
    {
      "id": "usa-live-57",
      "keyword": "brand infringement",
      "currentPosition": 100,
      "previousPosition": 18,
      "positionChange": -82,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Sentinel+ (Brand Protection)",
        "Raw Previous Rank": "18",
        "Raw Current Rank": "100"
      }
    },
    {
      "id": "usa-live-58",
      "keyword": "share of shelf analysis",
      "currentPosition": 100,
      "previousPosition": 100,
      "positionChange": 0,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "mScanIt (ecommerce intelligence solution)",
        "Raw Previous Rank": "100",
        "Raw Current Rank": "100"
      }
    },
    {
      "id": "usa-live-59",
      "keyword": "ecommerce intelligence",
      "currentPosition": 16,
      "previousPosition": 66,
      "positionChange": 50,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "mScanIt (ecommerce intelligence solution)",
        "Raw Previous Rank": "66",
        "Raw Current Rank": "16"
      }
    },
    {
      "id": "usa-live-60",
      "keyword": "affiliate monitoring tool",
      "currentPosition": 100,
      "previousPosition": 100,
      "positionChange": 0,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "EffCent ( Affiliate Monitoring Tool)",
        "Raw Previous Rank": "100",
        "Raw Current Rank": "100"
      }
    },
    {
      "id": "usa-live-61",
      "keyword": "affiliate monitoring",
      "currentPosition": 16,
      "previousPosition": 8,
      "positionChange": -8,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "EffCent ( Affiliate Monitoring Tool)",
        "Raw Previous Rank": "8",
        "Raw Current Rank": "16"
      }
    },
    {
      "id": "usa-live-62",
      "keyword": "affiliate fraud detection",
      "currentPosition": 100,
      "previousPosition": 81,
      "positionChange": -19,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "EffCent ( Affiliate Monitoring Tool)",
        "Raw Previous Rank": "81 (AI-8)",
        "Raw Current Rank": "100"
      }
    },
    {
      "id": "usa-live-63",
      "keyword": "affiliate marketing fraud detection",
      "currentPosition": 8,
      "previousPosition": 54,
      "positionChange": 46,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "EffCent ( Affiliate Monitoring Tool)",
        "Raw Previous Rank": "54",
        "Raw Current Rank": "8 (AI-8)"
      }
    },
    {
      "id": "usa-live-64",
      "keyword": "affiliate fraud prevention",
      "currentPosition": 13,
      "previousPosition": 15,
      "positionChange": 2,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "EffCent ( Affiliate Monitoring Tool)",
        "Raw Previous Rank": "15",
        "Raw Current Rank": "13"
      }
    },
    {
      "id": "usa-live-65",
      "keyword": "affiliate marketing fraud",
      "currentPosition": 59,
      "previousPosition": 26,
      "positionChange": -33,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "EffCent ( Affiliate Monitoring Tool)",
        "Raw Previous Rank": "26",
        "Raw Current Rank": "59"
      }
    },
    {
      "id": "usa-live-66",
      "keyword": "affiliate fraud",
      "currentPosition": 58,
      "previousPosition": 12,
      "positionChange": -46,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "USA",
      "date": "Thursday, 22 October 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "EffCent ( Affiliate Monitoring Tool)",
        "Raw Previous Rank": "12",
        "Raw Current Rank": "58"
      }
    }
  ],
  "MENA": [
    {
      "id": "mena-live-1",
      "keyword": "Click Injection",
      "currentPosition": 18,
      "previousPosition": 17,
      "positionChange": -1,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "17",
        "Raw Current Rank": "18"
      }
    },
    {
      "id": "mena-live-2",
      "keyword": "Ad Fraud Detection",
      "currentPosition": 38,
      "previousPosition": 34,
      "positionChange": -4,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "34",
        "Raw Current Rank": "38"
      }
    },
    {
      "id": "mena-live-3",
      "keyword": "Mobile Ad Fraud",
      "currentPosition": 23,
      "previousPosition": 28,
      "positionChange": 5,
      "movement": "IMPROVING",
      "rankingTrend": "Rising",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "28",
        "Raw Current Rank": "23"
      }
    },
    {
      "id": "mena-live-4",
      "keyword": "Ad Fraud Protection",
      "currentPosition": 48,
      "previousPosition": 23,
      "positionChange": -25,
      "movement": "DECLINING",
      "rankingTrend": "Declining",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "23",
        "Raw Current Rank": "48"
      }
    },
    {
      "id": "mena-live-5",
      "keyword": "Click Fraud Tools",
      "previousPosition": 12,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "12",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-6",
      "keyword": "Click Injection Fraud",
      "previousPosition": 19,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "19",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-7",
      "keyword": "Impression Fraud",
      "previousPosition": 8,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "8 { Ai- Overview 11 }",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-8",
      "keyword": "Ad Fraud",
      "previousPosition": 46,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "46",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-9",
      "keyword": "Ad Fraud Solution",
      "previousPosition": 26,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "26",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-10",
      "keyword": "Ad Fraud Prevention",
      "previousPosition": 100,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "100",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-11",
      "keyword": "Ad Spoofing",
      "previousPosition": 22,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "22",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-12",
      "keyword": "ctv ad fraud",
      "previousPosition": 2,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "2",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-13",
      "keyword": "Programmatic Ad Fraud",
      "previousPosition": 11,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "11",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-14",
      "keyword": "Programmatic Fraud",
      "previousPosition": 22,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "22 { AI Overview- 9 } ",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-15",
      "keyword": "Affiliate Marketing Fraud",
      "previousPosition": 79,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "79",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-16",
      "keyword": "Digital Advertising Fraud",
      "previousPosition": 31,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "31",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-17",
      "keyword": "Fraud Detection App",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "100<",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-18",
      "keyword": "Fraud Detection",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 500,
        "Section": "VALID 8",
        "Raw Previous Rank": "100<",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-19",
      "keyword": "Click Fraud",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "100<",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-20",
      "keyword": "Click Fraud Protection",
      "previousPosition": 12,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "12",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-21",
      "keyword": "Ppc Fraud",
      "previousPosition": 14,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "14",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-22",
      "keyword": "Ad Click Fraud",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "100<",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-23",
      "keyword": "Programmatic Ad",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 500,
        "Section": "VALID 8",
        "Raw Previous Rank": "100<",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-24",
      "keyword": "Pay Per Click Fraud",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "100<",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-25",
      "keyword": "Digital Marketing Fraud",
      "previousPosition": 37,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "37",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-26",
      "keyword": "Ad Fraud Tools",
      "previousPosition": 15,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "15",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-27",
      "keyword": "Programmatic Ad Campaigns",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "100<",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-28",
      "keyword": "Programmatic Ad Spend",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "100<",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-29",
      "keyword": "Ctv Advertising",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "100<",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-30",
      "keyword": "Affiliate Marketing Tools",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "100<",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-31",
      "keyword": "Bot Traffic",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "100<",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-32",
      "keyword": "Affiliate Campaign",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "100<",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-33",
      "keyword": "Affiliate Marketing Scams",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "100<",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-34",
      "keyword": "Affiliate Fraud",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "100<",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-35",
      "keyword": "Advertising Fraud",
      "previousPosition": 34,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "34",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-36",
      "keyword": "Digital Fraud",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "100<",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-37",
      "keyword": "Fraud Solutions",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "VALID 8",
        "Raw Previous Rank": "100<",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-38",
      "keyword": "Fraud Prevention",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 500,
        "Section": "VALID 8",
        "Raw Previous Rank": "100<",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-39",
      "keyword": "Ad Fraud Detection Tool",
      "previousPosition": 46,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 10100,
        "Section": "VALID 8",
        "Raw Previous Rank": "46 { AI-9 }",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-40",
      "keyword": "Types Of Mobile Ad Fraud",
      "previousPosition": 9,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 10,
        "Section": "VALID 8",
        "Raw Previous Rank": "9 { AI- 6 }",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-41",
      "keyword": "Ad Fraud Detection Software",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 10100,
        "Section": "VALID 8",
        "Raw Previous Rank": "67< { Ai- 4 }",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-42",
      "keyword": "ad fraud tools",
      "previousPosition": 12,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 10100,
        "Section": "VALID 8",
        "Raw Previous Rank": "12",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-43",
      "keyword": "Programmatic Fraud",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 10100,
        "Section": "VALID 8",
        "Raw Previous Rank": "AI- 3",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-44",
      "keyword": "Click Fraud Detection Tools",
      "previousPosition": 10,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 10100,
        "Section": "VALID 8",
        "Raw Previous Rank": "10",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-45",
      "keyword": "Ad Fraud Software",
      "previousPosition": 17,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 10100,
        "Section": "VALID 8",
        "Raw Previous Rank": "17",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-46",
      "keyword": "Device Spoofing",
      "previousPosition": 100,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 10100,
        "Section": "VALID 8",
        "Raw Previous Rank": "100",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-47",
      "keyword": "Ad Fraud Detection Companies",
      "previousPosition": 100,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 12,
        "Section": "VALID 8",
        "Raw Previous Rank": "100",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-48",
      "keyword": "Contextual Ads",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Brand Safety",
        "Raw Previous Rank": "100<",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-49",
      "keyword": "Contextual Ad Targeting",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Brand Safety",
        "Raw Previous Rank": "100<",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-50",
      "keyword": "Brand Safety Advertising",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Brand Safety",
        "Raw Previous Rank": "100<",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-51",
      "keyword": "Contextual Programmatic Advertising",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "Brand Safety",
        "Raw Previous Rank": "100<",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-52",
      "keyword": "Digital Commerce Analytics",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "ECOM-mSCANIT",
        "Raw Previous Rank": "100<",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-53",
      "keyword": "Digital Shelf",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "ECOM-mSCANIT",
        "Raw Previous Rank": "100<",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-54",
      "keyword": "Ecommerce Solutions",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "ECOM-mSCANIT",
        "Raw Previous Rank": "100<",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-55",
      "keyword": "Ecommerce Analytics",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "ECOM-mSCANIT",
        "Raw Previous Rank": "100<",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-56",
      "keyword": "Digital Ecommerce",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "ECOM-mSCANIT",
        "Raw Previous Rank": "100<",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-57",
      "keyword": "Affiliate Monitoring",
      "previousPosition": 10,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "EFFCENT",
        "Raw Previous Rank": "10",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-58",
      "keyword": "Affiliate Brand Bidding",
      "previousPosition": 1,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "EFFCENT",
        "Raw Previous Rank": "1",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-59",
      "keyword": "Brand Bidding Affiliate Marketing",
      "previousPosition": 27,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "EFFCENT",
        "Raw Previous Rank": "27",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-60",
      "keyword": "Brand Bidding",
      "previousPosition": 45,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "EFFCENT",
        "Raw Previous Rank": "45",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-61",
      "keyword": "Affiliate Campaign",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "EFFCENT",
        "Raw Previous Rank": "100<",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-62",
      "keyword": "Ppc Brand Bidding",
      "previousPosition": 65,
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "EFFCENT",
        "Raw Previous Rank": "65",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-63",
      "keyword": "Digital brand protection",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 50,
        "Section": "SENTINEL+",
        "Raw Previous Rank": "100<",
        "Raw Current Rank": "NR"
      }
    },
    {
      "id": "mena-live-64",
      "keyword": "Brand protection",
      "movement": "STABLE",
      "rankingTrend": "Stable",
      "region": "MENA",
      "date": "Friday, 22 October, 2026",
      "additionalFields": {
        "Search Volume": 500,
        "Section": "SENTINEL+",
        "Raw Previous Rank": "100<",
        "Raw Current Rank": "NR"
      }
    }
  ]
};

export const INITIAL_LIVE_WORKBOOK: LiveRankingWorkbookInfo = {
  id: 'live-rankings-workbook',
  name: 'Weekly Keyword Ranking Sheet.xlsx',
  status: 'CONNECTED',
  currentWeekLabel: 'Thursday, 22 October 2026',
  tabs: {
    INDIA: {
      tabName: 'India Live Rankings',
      region: 'INDIA',
      rowCount: WEEKLY_RANKING_DATA.INDIA.length,
      detectedColumns: ['Keyword', 'Search Volume', 'Competition', 'Friday, 16 October 2026', 'Thrusday, 22 October 2026'],
      records: WEEKLY_RANKING_DATA.INDIA,
      validationWarnings: []
    },
    USA: {
      tabName: 'USA Live Rankings',
      region: 'USA',
      rowCount: WEEKLY_RANKING_DATA.USA.length,
      detectedColumns: ['Keyword', 'Search Volume', 'Competition', 'Friday, 16 October 2026', 'Thursday, 22 October 2026'],
      records: WEEKLY_RANKING_DATA.USA,
      validationWarnings: []
    },
    MENA: {
      tabName: 'MENA Live Rankings',
      region: 'MENA',
      rowCount: WEEKLY_RANKING_DATA.MENA.length,
      detectedColumns: ['VALID 8', 'VOLUME', 'COMPETITON', 'Friday, 16 October, 2026', 'Friday, 22 October, 2026'],
      records: WEEKLY_RANKING_DATA.MENA,
      validationWarnings: []
    }
  },
  validationWarnings: []
};
