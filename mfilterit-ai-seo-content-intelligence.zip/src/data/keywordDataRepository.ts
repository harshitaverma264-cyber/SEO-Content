import { KeywordWithVolume, ContentItem, mFilterItSolution, FunnelStage, TrustPillar } from '../types/seo';
import { getTrustPillarForItem } from '../utils/trustPillar';
import { getStyleGuideCta } from './editorialStyleGuide';

export interface EnrichedKeywordSet {
  primaryKeyword: string;
  primarySearchVolume: number;
  primaryVolumeType: 'Estimated' | 'Verified';
  primarySource: string;
  primaryLastUpdated: string;
  secondaryKeywords: KeywordWithVolume[];
  tertiaryKeywords: string[];
  competitorReferenceLinks: [string, string, string];
  // Architecture preparation for future Google Keyword Planner integration
  gkpIntegrationReady?: boolean;
}

/**
 * Architecture hook for future Google Keyword Planner API integration.
 * Prepared for future connection, but currently running on mFilterIt Estimated Intelligence.
 */
export async function fetchGoogleKeywordPlannerVolumesStub(keywords: string[]): Promise<KeywordWithVolume[]> {
  // Future implementation will call Google Keyword Planner API /proxy endpoint.
  // Currently returns un-connected stub structure.
  return keywords.map((kw) => ({
    keyword: kw,
    searchVolume: 1200,
    volumeType: 'Verified',
    source: 'Google Keyword Planner API (Pending Connection)',
    lastUpdated: new Date().toISOString().split('T')[0]
  }));
}

function getDefaultDiagnosticRationale(
  solution?: mFilterItSolution,
  funnel?: FunnelStage,
  pillar?: TrustPillar
): string {
  if (solution?.includes('Affiliate')) {
    return 'Diagnostic forensic: Up to 43% of affiliate traffic in competitive search campaigns suffers trademark poach-bidding or cookie stuffing. Closes attribution cannibalization and stops organic traffic theft.';
  }
  if (solution?.includes('Ad Fraud') || pillar === 'Media Trust') {
    return 'Data-backed forensic: Sophisticated bot networks, SSAI spoofing, and emulator farms drain up to 25% of media budgets. Establishes verified human delivery across programmatic, CTV, and mobile campaigns.';
  }
  if (solution?.includes('Digital Shelf')) {
    return 'Commercial margin defense: Unauthorized reseller discounting and Buy Box suppression reduce sales velocity. Enforces MAP adherence and automated pricing intelligence across regional marketplaces.';
  }
  if (solution?.includes('Brand Protection')) {
    return 'Asset protection focus: Lookalike domains and counterfeit listings erode consumer trust. Delivers continuous threat detection and rapid enforcement to preserve brand equity.';
  }
  if (solution?.includes('Brand Safety')) {
    return 'Risk avoidance focus: Balances campaign reach with brand suitability floors across regional video and social channels to prevent toxic content adjacency.';
  }
  if (solution?.includes('Creative Compliance')) {
    return 'Regulatory audit trail: Automates ASCI & regulatory ad disclosures to eliminate compliance fines and pre-screen creatives before publishing in regulated industries.';
  }
  if (solution?.includes('Mule Account') || solution?.includes('Digital Scam') || solution?.includes('Merchant Onboarding') || pillar === 'Financial Trust') {
    return 'Financial integrity focus: Mule accounts and transaction laundering expose digital lenders to central bank penalties. Establishes behavioral telemetry to block synthetic identities.';
  }
  return 'Diagnostic focus: Solves high-impact enterprise ad integrity vulnerabilities with data-backed verification benchmarks.';
}

/**
 * Advanced Methodology Keyword Engine:
 * Dynamically generates non-mechanical, highly relevant secondary and tertiary keywords
 * adhering strictly to the manual calendar methodology reference.
 * 
 * - Secondary keywords: Cover relevant semantic variations, related concepts, use cases,
 *   solutions, entities and adjacent search terms (NO mechanical repetition of focus keyword).
 * - Tertiary keywords: Cover diverse question-led (What, How, Why), comparison, process,
 *   benefits and use cases.
 */
export function getSemanticKeywordSet(
  primaryKeyword: string,
  topic: string = '',
  solution: string = '',
  baseVolume: number = 1200
): EnrichedKeywordSet {
  const pKw = (primaryKeyword || '').toLowerCase().trim();
  const topText = (topic || '').toLowerCase();
  const solText = (solution || '').toLowerCase();
  const combined = `${pKw} ${topText} ${solText}`;

  let primarySearchVol = baseVolume > 0 ? baseVolume : 1200;

  let secondaryList: string[] = [];
  let tertiaryList: string[] = [];
  let competitorLinks: [string, string, string] = [
    'https://cheq.ai/solutions/ad-fraud/',
    'https://www.appsflyer.com/solutions/fraud-protection/',
    'https://www.doubleverify.com/fraud-protection/'
  ];

  if (
    combined.includes('affiliate') ||
    combined.includes('bidding') ||
    combined.includes('cookie') ||
    combined.includes('coupon') ||
    combined.includes('poaching') ||
    combined.includes('hijacking') ||
    combined.includes('partner marketing')
  ) {
    competitorLinks = [
      'https://impact.com/affiliate-marketing/brand-bidding-protection/',
      'https://cheq.ai/brand-protection/affiliate-fraud/',
      'https://www.brandshield.com/solutions/affiliate-fraud/'
    ];
    if (primarySearchVol <= 50) primarySearchVol = 1600;

    secondaryList = [
      'paid search brand hijacking',
      'affiliate trademark violation software',
      'PPC ad poaching protection',
      'unauthorized google ads keyword bidding',
      'affiliate commission theft detection',
      'partner compliance monitoring platform',
      'search engine arbitrage prevention',
      'brand keyword protection software',
      'competitor ad monitoring tools',
      'affiliate link hijacking scanner'
    ];

    tertiaryList = [
      'what is brand bidding in affiliate marketing',
      'how to stop affiliates from bidding on company trademarks',
      'why are competitors bidding on my brand name in google ads',
      'brand bidding vs coupon code hijacking difference',
      'how to audit affiliate search campaign compliance',
      'what are the legal penalties for trademark ad hijacking',
      'how much search revenue is lost to rogue affiliate bidding',
      'best practices for writing affiliate PPC policy guidelines',
      'how automated brand protection tools detect PPC violations',
      'what is the ROI of affiliate brand bidding monitoring'
    ];
  } else if (
    combined.includes('app install') ||
    combined.includes('click injection') ||
    combined.includes('click spamming') ||
    combined.includes('sdk spoofing') ||
    combined.includes('attribution') ||
    combined.includes('cpi') ||
    combined.includes('mmp') ||
    combined.includes('mobile')
  ) {
    competitorLinks = [
      'https://www.appsflyer.com/solutions/fraud-protection/',
      'https://adjust.com/products/fraud-prevention/',
      'https://singular.net/fraud-prevention/'
    ];
    if (primarySearchVol <= 50) primarySearchVol = 2400;

    secondaryList = [
      'click injection fraud prevention',
      'click spamming attribution manipulation',
      'install attribution theft detection',
      'mobile ad network fraud audit',
      'MMP fraud protection SDK',
      'CPI campaign fake user filtering',
      'SDK spoofing prevention software',
      'device farm ad fraud blocker',
      'app acquisition budget protection',
      'cost per install fraud analytics'
    ];

    tertiaryList = [
      'what is click injection in mobile advertising',
      'how to identify bot traffic in mobile app campaigns',
      'why do app install campaigns have high churn rates',
      'click injection vs click spamming comparison',
      'how to negotiate refunds for fraudulent app installs',
      'what metrics indicate mobile ad attribution fraud',
      'how to configure MMP fraud rules in appsflyer',
      'why install fraud spikes during ecommerce sale events',
      'how SDK spoofing bypasses basic ad fraud checks',
      'what is the average app install fraud rate in MENA'
    ];
  } else if (
    combined.includes('map') ||
    combined.includes('amazon') ||
    combined.includes('buy box') ||
    combined.includes('digital shelf') ||
    combined.includes('marketplace') ||
    combined.includes('price scraping') ||
    combined.includes('unauthorized reseller') ||
    combined.includes('noon') ||
    combined.includes('flipkart') ||
    combined.includes('quick commerce')
  ) {
    competitorLinks = [
      'https://www.brand-sight.com/marketplace-monitoring/',
      'https://www.redpoints.com/marketplace-monitoring/',
      'https://corsearch.com/solutions/marketplace-monitoring/'
    ];
    if (primarySearchVol <= 50) primarySearchVol = 2100;

    secondaryList = [
      'unauthorized amazon reseller removal',
      'price scraping monitoring tool',
      'buy box suppression alerts',
      'minimum advertised price enforcement',
      'gray market seller identification',
      'marketplace brand gating software',
      'counterfeit listing takedown automation',
      'D2C margin protection platform',
      'e-commerce channel conflict management',
      'buy box win rate tracking'
    ];

    tertiaryList = [
      'how to enforce MAP pricing on amazon without legal battles',
      'what causes buy box loss for authorized brand sellers',
      'why unauthorized resellers undercut minimum advertised price',
      'automated MAP monitoring vs manual seller checks',
      'how to file amazon IP infringement complaints effectively',
      'what is price scraping in ecommerce marketplaces',
      'how to protect product margin during festive sale peaks',
      'why gray market sellers win buy box on noon and amazon',
      'how to set up automated buy box suppression alerts',
      'what are the best tools for marketplace seller compliance'
    ];
  } else if (
    combined.includes('brand safety') ||
    combined.includes('suitability') ||
    combined.includes('garm') ||
    combined.includes('creative compliance') ||
    combined.includes('contextual') ||
    combined.includes('asci') ||
    combined.includes('pre-bid') ||
    combined.includes('post-bid')
  ) {
    competitorLinks = [
      'https://www.doubleverify.com/brand-safety/',
      'https://integralads.com/solutions/brand-safety/',
      'https://www.sprinklr.com/products/brand-safety/'
    ];
    if (primarySearchVol <= 50) primarySearchVol = 1800;

    secondaryList = [
      'GARM brand safety framework compliance',
      'pre-bid programmatic ad filtering',
      'contextual ad placement vetting',
      'toxic content keyword exclusion lists',
      'CTV video ad environment verification',
      'ad placement brand reputation risk',
      'social media brand suitability controls',
      'ad verification tool comparison',
      'programmatic inventory brand safety',
      'post-bid ad verification software'
    ];

    tertiaryList = [
      'what is the difference between brand safety and brand suitability',
      'how does pre bid programmatic filtering protect brand reputation',
      'why traditional keyword blocklists harm ad campaign reach',
      'GARM brand suitability framework explained for advertisers',
      'how to verify CTV ad inventory safety before buying',
      'what happens when ads appear next to harmful content',
      'how to audit programmatic ad spend for brand safety',
      'why contextual targeting is replacing third party cookies',
      'how to measure brand suitability risk score in video ads',
      'what are the top brand safety verification platforms'
    ];
  } else if (
    combined.includes('trademark') ||
    combined.includes('phishing') ||
    combined.includes('counterfeit') ||
    combined.includes('impersonation') ||
    combined.includes('spoofing') ||
    combined.includes('domain') ||
    combined.includes('brand protection') ||
    combined.includes('fake website')
  ) {
    competitorLinks = [
      'https://www.redpoints.com/brand-protection/',
      'https://corsearch.com/solutions/brand-protection/',
      'https://www.brandshield.com/solutions/'
    ];
    if (primarySearchVol <= 50) primarySearchVol = 3100;

    secondaryList = [
      'anti phishing brand monitoring',
      'counterfeit product listing removal',
      'domain spoofing detection platform',
      'executive social media impersonation protection',
      'trademark infringement takedown automation',
      'rogue website brand hijacking protection',
      'fake app store listing scanner',
      'social media brand impersonation alerts',
      'VIP digital identity protection',
      'brand risk monitoring dashboard'
    ];

    tertiaryList = [
      'what is brand infringement in digital marketing',
      'how to report fake website domains impersonating your brand',
      'why social media impersonation harms customer trust',
      'counterfeit detection tools vs manual IP enforcement',
      'how to automate trademark violation takedown notices',
      'what is the cost of online brand counterfeiting for retail',
      'how domain spoofing is used in targeted phishing attacks',
      'why brand protection is critical for ecommerce DTC growth',
      'how to monitor unauthorized app clones in Google Play',
      'what metrics track brand protection program effectiveness'
    ];
  } else if (
    combined.includes('mule') ||
    combined.includes('bank') ||
    combined.includes('transaction') ||
    combined.includes('laundering') ||
    combined.includes('bfsi') ||
    combined.includes('aml') ||
    combined.includes('financial')
  ) {
    competitorLinks = [
      'https://www.appsflyer.com/solutions/fraud-protection/',
      'https://cheq.ai/solutions/ad-fraud/',
      'https://www.doubleverify.com/fraud-protection/'
    ];
    if (primarySearchVol <= 50) primarySearchVol = 5000;

    secondaryList = [
      'banking fraud detection algorithms',
      'money laundering transaction monitoring',
      'synthetic identity fraud prevention',
      'account takeover risk scoring',
      'BFSI compliance fraud detection',
      'suspicious account behavior analytics',
      'payment gateway transaction laundering',
      'financial crime compliance software',
      'digital banking fraud prevention',
      'AML transaction screening tool'
    ];

    tertiaryList = [
      'what is a money mule account in digital banking',
      'how do banks detect transaction laundering on payment portals',
      'why synthetic identity fraud is rising in BFSI apps',
      'mule account detection vs traditional transaction monitoring',
      'how machine learning identifies suspicious bank account activity',
      'what are regulatory compliance requirements for money laundering',
      'how to prevent mule accounts during digital onboarding',
      'why transactional laundering bypasses standard merchant checks',
      'how fast can automated fraud detection flag suspicious transfers',
      'what is the financial impact of money mule networks on banks'
    ];
  } else {
    // Default Ad Fraud / IVT / CTV / Programmatic
    competitorLinks = [
      'https://www.appsflyer.com/solutions/fraud-protection/',
      'https://cheq.ai/solutions/ad-fraud/',
      'https://www.doubleverify.com/fraud-protection/'
    ];
    if (primarySearchVol <= 50) primarySearchVol = 3200;

    secondaryList = [
      'invalid traffic ivt filtering software',
      'programmatic ad fraud audit tool',
      'botnet click fraud detection system',
      'CTV video ad fraud verification',
      'DSP ad spend wastage prevention',
      'domain spoofing advertising verification',
      'impression laundering detection scanner',
      'real-time ad verification API',
      'media buying fraud audit report',
      'ad integrity threat intelligence'
    ];

    tertiaryList = [
      'what is sophisticated invalid traffic SIVT in digital advertising',
      'how to audit programmatic ad campaigns for bot traffic',
      'why ad fraud increases during holiday shopping surges',
      'general IVT vs sophisticated IVT key differences',
      'how to claim ad network refunds for fraudulent impressions',
      'what KPIs measure ad fraud mitigation success',
      'how CTV ad fraud exploits server side ad insertion SSAI',
      'why performance marketers need independent ad verification',
      'how to set up automated invalid traffic alerts in Google Ads',
      'what is the estimated global cost of digital ad fraud'
    ];
  }

  // Calculate realistic search volumes for secondary keywords
  const ratios = [0.80, 0.65, 0.52, 0.40, 0.32, 0.25, 0.18, 0.12, 0.08, 0.05];
  const secondaryKeywords: KeywordWithVolume[] = secondaryList.map((kw, i) => {
    const vol = Math.max(50, Math.round(primarySearchVol * (ratios[i] || 0.1)));
    return {
      keyword: kw,
      searchVolume: vol,
      volumeType: 'Estimated',
      source: 'mFilterIt Estimated Engine',
      lastUpdated: '2026-10-12'
    };
  });

  return {
    primaryKeyword: pKw || 'ad fraud detection software',
    primarySearchVolume: primarySearchVol,
    primaryVolumeType: 'Estimated',
    primarySource: 'mFilterIt Estimated Engine',
    primaryLastUpdated: '2026-10-12',
    secondaryKeywords,
    tertiaryKeywords: tertiaryList,
    competitorReferenceLinks: competitorLinks,
    gkpIntegrationReady: true
  };
}

/**
 * Backwards-compatible map for keyword lookup by item ID or query.
 */
export const CONTENT_ITEM_KEYWORD_DATA: Record<string, EnrichedKeywordSet> = new Proxy({}, {
  get(target, prop: string) {
    if (typeof prop === 'string' && prop.trim() !== '') {
      return getSemanticKeywordSet(prop, '', '', 1200);
    }
    return getSemanticKeywordSet('ad fraud detection software', '', '', 1200);
  }
});

/**
 * Enriches a content item with:
 * - 1 Primary Keyword + Search Volume
 * - 10 Secondary Keywords + Search Volume (semantic variations, entities, use cases, solutions)
 * - 10 Tertiary Keywords without Search Volume (diverse question-led, comparison, process, benefits)
 * - Exactly 3 Competitor Reference Links
 * - Dynamic Trust Pillar assignment
 */
export function enrichContentItemWithRealKeywords(item: ContentItem): ContentItem {
  const pKw = item.primaryKeyword || item.focusKeyword || item.topic || 'ad fraud detection software';
  const vol = item.primarySearchVolume || item.searchVolume || 1200;

  const semanticSet = getSemanticKeywordSet(pKw, item.topic, item.productMapping, vol);

  const pillar = item.trustPillar || getTrustPillarForItem({
    productMapping: item.productMapping,
    topic: item.topic,
    focusKeyword: semanticSet.primaryKeyword,
    primaryKeyword: semanticSet.primaryKeyword,
  });

  const secondaryObjs = semanticSet.secondaryKeywords;
  const secondaryStrings = secondaryObjs.map((sk) => `${sk.keyword} (Vol: ${sk.searchVolume})`);

  const cta = item.recommendedCta || (item.productMapping ? getStyleGuideCta(item.productMapping) : 'Request Free Enterprise Digital Trust Audit with mFilterIt');
  const rationale = item.leadRationale || getDefaultDiagnosticRationale(item.productMapping, item.funnelStage, pillar);

  return {
    ...item,
    trustPillar: pillar,
    primaryKeyword: semanticSet.primaryKeyword,
    primarySearchVolume: semanticSet.primarySearchVolume,
    searchVolume: semanticSet.primarySearchVolume,
    primaryVolumeType: item.primaryVolumeType || semanticSet.primaryVolumeType || 'Estimated',
    primarySource: item.primarySource || semanticSet.primarySource || 'mFilterIt Estimated Engine',
    primaryLastUpdated: item.primaryLastUpdated || semanticSet.primaryLastUpdated || '2026-10-12',
    focusKeyword: semanticSet.primaryKeyword,
    secondaryKeywords: secondaryStrings,
    secondaryKeywordsWithVolume: secondaryObjs,
    tertiaryKeywords: semanticSet.tertiaryKeywords,
    competitorReferenceLinks: semanticSet.competitorReferenceLinks,
    recommendedCta: cta,
    leadRationale: rationale,
  };
}
