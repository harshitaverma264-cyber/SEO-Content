import {
  mFilterItSolution,
  IcpPersona,
  ContentType,
  FunnelStage,
  ContentAction,
  Region,
  ConnectorStatus
} from '../types/seo';

export const mFilterItSolutions: mFilterItSolution[] = [
  // Media Trust: Ad Traffic Validation, Brand Safety & Suitability, Measurement
  'Ad Fraud Detection',
  'Brand Safety & Suitability Monitoring',
  'Brand Safety',
  'Affiliate Monitoring / Affiliate Fraud Detection',
  'Digital Shelf / Marketplace Monitoring',
  'Digital Commerce Intelligence',

  // Brand Trust: Brand Protection & Counterfeit Detection
  'Brand Protection',
  'Counterfeit Detection',
  'Creative Compliance',

  // Financial Trust: Digital Scams, Merchant Risk & Mule Accounts
  'Digital Scam Monitoring & Detection',
  'Merchant Onboarding Screening & Risk Verification',
  'Mule Account & Transaction Laundering Monitoring'
];

export const ICP_PERSONAS: IcpPersona[] = [
  'CMO',
  'Marketing Head',
  'Performance Marketing Head',
  'Digital Marketing Head',
  'Media Buyer',
  'Affiliate Manager',
  'Affiliate Marketing Head',
  'Brand Protection Head',
  'Brand Safety Head',
  'E-commerce Head',
  'Advertising/Media Decision Maker',
];

export const CONTENT_TYPES: ContentType[] = [
  'Website Blog',
  'SEO / Guest Post',
  'Infographic',
  'Glossary',
];

export const FUNNEL_STAGES: { stage: FunnelStage; label: string; desc: string }[] = [
  { stage: 'TOFU', label: 'Top of Funnel (TOFU)', desc: 'Educational & problem awareness (e.g., What is ad fraud?)' },
  { stage: 'MOFU', label: 'Middle of Funnel (MOFU)', desc: 'Solution consideration & methodology (e.g., How to prevent ad fraud)' },
  { stage: 'BOFU', label: 'Bottom of Funnel (BOFU)', desc: 'Commercial intent & vendor evaluation (e.g., Best ad fraud detection software)' },
];

export const CONTENT_ACTIONS: { action: ContentAction; label: string; desc: string }[] = [
  { action: 'NEW', label: 'NEW', desc: 'No suitable existing content exists on mFilterIt.com' },
  { action: 'REVAMP', label: 'REVAMP', desc: 'Existing content exists but requires deep updates for modern intent & rankings' },
  { action: 'EXPAND', label: 'EXPAND', desc: 'Existing page can be extended to cover secondary intent & keyword clusters' },
  { action: 'MERGE', label: 'MERGE', desc: 'Multiple thin/competing pages overlap and should be consolidated into one authority asset' },
  { action: 'SUPPORTING', label: 'SUPPORTING', desc: 'Supporting article needed to reinforce a core topic pillar and pass link equity' },
];

export const REGIONS: Region[] = ['INDIA', 'USA', 'MENA', 'OVERALL'];

export const DATA_CONNECTORS: ConnectorStatus[] = [
  {
    id: 'mfilterit_site',
    name: 'mFilterIt Website Crawler (mFilterIt.com)',
    status: 'Awaiting connection',
    description: 'Crawls existing blog URLs, solutions, and internal link architecture.',
    dataNote: 'Architecture ready. Awaiting production sitemap & API connection.'
  },
  {
    id: 'gsc',
    name: 'Google Search Console (GSC)',
    status: 'Awaiting connection',
    description: 'Retrieves live impressions, clicks, CTR, and positions 4–20 opportunity queries.',
    dataNote: 'No fake GSC metrics displayed. OAuth handshake interface ready.'
  },
  {
    id: 'ga4',
    name: 'Google Analytics 4 (GA4)',
    status: 'Awaiting connection',
    description: 'Measures organic user sessions, engagement time, and lead conversions.',
    dataNote: 'Awaiting GA4 property measurement ID connection.'
  },
  {
    id: 'weekly_rankings',
    name: 'Weekly Keyword Ranking Sheets',
    status: 'Ready for Upload',
    description: 'Ingests regional rank tracker sheets for India, USA, and MENA.',
    dataNote: 'Supports CSV / Excel ranking import.'
  },
  {
    id: 'competitor_intel',
    name: 'Competitor Gap Engine',
    status: 'Awaiting connection',
    description: 'Analyzes AdTech/MarTech competitor content clusters and SERP coverage.',
    dataNote: 'Awaiting competitor domain list synchronization.'
  }
];
