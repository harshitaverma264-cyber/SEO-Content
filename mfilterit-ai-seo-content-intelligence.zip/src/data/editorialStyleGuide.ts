import { mFilterItSolution, TrustPillar, ContentType, FunnelStage, IcpPersona } from '../types/seo';

export interface TitlePattern {
  id: string;
  name: string;
  formula: string;
  description: string;
  realWorldExamples: string[];
  recommendedFunnel: FunnelStage;
}

export interface EditorialStyleGuide {
  brandVoice: {
    archetype: string;
    tone: string[];
    corePrinciples: {
      title: string;
      description: string;
      rule: string;
    }[];
  };
  trustPillars: {
    pillar: TrustPillar;
    color: string;
    focusAreas: string[];
    diagnosticQuestions: string[];
    targetSolutions: mFilterItSolution[];
  }[];
  titlePatterns: TitlePattern[];
  contentStructureRules: {
    section: string;
    guideline: string;
    checklist: string[];
  }[];
  ctaCatalog: Partial<Record<mFilterItSolution, {
    primaryCta: string;
    rationale: string;
    landingPath: string;
  }>>;
}

export const mFilterItEditorialStyleGuide: EditorialStyleGuide = {
  brandVoice: {
    archetype: 'Enterprise Digital Trust & Ad Integrity Diagnostic Authority',
    tone: [
      'Diagnostic & Inquisitive (uncovers hidden systemic waste and fraud vectors)',
      'Data-Backed & Forensic (references specific attack mechanics, telemetry, benchmarks)',
      'Solutions-Oriented & Consultative (provides concrete playbooks, not alarmist commentary)',
      'Enterprise & C-Suite Relevant (speaks directly to P&L, ROAS preservation, margin defense)'
    ],
    corePrinciples: [
      {
        title: 'Diagnostic Over Descriptive',
        description: 'Never write generic "10 Tips" or basic definitional overviews. Formulate topics around the underlying vulnerabilities, attribution theft mechanisms, and operational blindspots.',
        rule: 'Ask: "Why does this leakage occur?" and "What does the attacker exploit that traditional attribution tools miss?"'
      },
      {
        title: 'Concrete Technical Mechanics',
        description: 'Ground every recommendation in technical realities: SDK spoofing, click injection, SSAI spoofing, cookie stuffing, Buy Box suppression algorithms, MAP scraping bots, GARM brand suitability floors, ASCI/regulatory mandates.',
        rule: 'Avoid vague assertions like "fraud is bad"; quantify the impact (e.g., "18-35% attribution poaching in high-intent campaigns").'
      },
      {
        title: 'Commercial Intent & Consultative Next Step',
        description: 'Every piece of content must naturally guide enterprise decision-makers toward an actionable diagnostic audit or platform assessment.',
        rule: 'Conclude with a high-trust, low-friction consultative offer (Free Ad Spend Audit, Buy Box Health Check, Brand Infringement Scan).'
      }
    ]
  },
  trustPillars: [
    {
      pillar: 'Media Trust',
      color: '#530093',
      focusAreas: [
        'Ad Traffic Validation (Full Funnel Ad Traffic Validation, Branding & Performance Campaign Validation)',
        'Web Traffic Validation for Performance Campaigns & App Ad Traffic Validation',
        'Affiliate Fraud Detection & Monitoring (Brand Bidding, Cookie Stuffing & Attribution Theft)',
        'Direct Carrier Billing Fraud Detection (DCB / VAS Integrity)',
        'Brand Safety & Suitability Monitoring (GARM Framework Alignment, Contextual Vetting)',
        'Measurement: Digital Commerce Intelligence (Digital Shelf, Buy Box & Pricing Protection)',
        'Agentic AI: mPulse Ecommerce & mPulse Branding'
      ],
      diagnosticQuestions: [
        'Are you paying for verified human impressions or bot-driven non-human traffic?',
        'Are rogue affiliates poach-bidding on your branded trademark search queries?',
        'Are your display and video ad placements appearing alongside toxic or polarizing content?',
        'How does unauthorized seller discounting trigger Amazon Buy Box suppression algorithms?'
      ],
      targetSolutions: [
        'Ad Fraud Detection',
        'Brand Safety',
        'Brand Safety & Suitability Monitoring',
        'Affiliate Monitoring / Affiliate Fraud Detection',
        'Digital Shelf / Marketplace Monitoring',
        'Digital Commerce Intelligence'
      ]
    },
    {
      pillar: 'Brand Trust',
      color: '#059669',
      focusAreas: [
        'Brand Protection (OSINT Trademark Monitoring, Domain Spoofing & Phishing Defense)',
        'Counterfeit Detection (Marketplace IP Infringement, Fake Social Shops & Rogue Resellers)',
        'Automated Hybrid AI-and-Human Legal Takedowns'
      ],
      diagnosticQuestions: [
        'How do counterfeit products siphon organic traffic and brand equity across social shops?',
        'How many phishing domains and lookalike websites are targeting your customer base?',
        'What automated mechanisms are in place to remove infringing marketplace listings?'
      ],
      targetSolutions: [
        'Brand Protection',
        'Counterfeit Detection',
        'Creative Compliance'
      ]
    },
    {
      pillar: 'Financial Trust',
      color: '#d97706',
      focusAreas: [
        'Digital Scam Monitoring & Detection (Loan App Scams, Fake Investment Schemes)',
        'Merchant Onboarding Screening & Risk Verification (Underwriting Integrity & KYB Checks)',
        'Mule Account & Transaction Laundering Monitoring (Synthetic Identity & Money Laundering)'
      ],
      diagnosticQuestions: [
        'Are synthetic identities and mule accounts exploiting mobile banking sign-up incentives?',
        'How quickly does your compliance team identify rogue merchants laundering transactions?',
        'What telemetry detects coordinated digital scam networks targeting digital wallets?'
      ],
      targetSolutions: [
        'Digital Scam Monitoring & Detection',
        'Merchant Onboarding Screening & Risk Verification',
        'Mule Account & Transaction Laundering Monitoring'
      ]
    }
  ],
  titlePatterns: [
    {
      id: 'pattern-diagnostic-question',
      name: 'Diagnostic Inquiry + Root-Cause Forensic',
      formula: '[Provocative Diagnostic Question]? Why [Fraud/Leakage Vector] [Business Consequence]',
      description: 'Challenges conventional marketing assumptions and exposes the hidden technical mechanism draining performance.',
      realWorldExamples: [
        'Are You Paying for Clicks, or Paying for Users? Why App Install Fraud Begins Before the Install',
        'Incent Fraud Detection: Why High-Volume Acquisition Never Becomes Quality Growth',
        'Is Your Attribution Platform Catching Click Injection or Simply Claiming Credit?'
      ],
      recommendedFunnel: 'MOFU'
    },
    {
      id: 'pattern-threat-defense',
      name: 'Sector Threat Forensic + Enterprise Defense Playbook',
      formula: '[Threat Vector] in [Industry/Vertical]: How [Rogue Actor] Targets [Asset] and How to Protect It',
      description: 'Pinpoints specific vertical vulnerabilities (Banking, Retail, Gaming, Travel) with a tactical blueprint for enterprise defense.',
      realWorldExamples: [
        'Brand Infringement in Banking: How Fakes Target Your Customers and How to Protect Them',
        'Affiliate Growth vs Brand Infringement: How BFSI Brands in MENA Can Stay Protected',
        'Social Commerce Brand Protection: Takedown Strategies for TikTok Shop & Instagram Fakes'
      ],
      recommendedFunnel: 'BOFU'
    },
    {
      id: 'pattern-audit-checklist',
      name: 'Strategic Milestone Audit Checklist',
      formula: '[Strategic Milestone/Season] Checklist: Are You Auditing [Leakage Area] Before [Trigger]?',
      description: 'Capitalizes on seasonal budget resets, fiscal milestones, or mega-shopping peaks (Diwali, DSF, BFCM, Prime Day).',
      realWorldExamples: [
        'FY Closing Checklist: Are You Auditing Ad Fraud Media Waste Before Budget Reset?',
        'Q4 Holiday Readiness: 7 Red Flags of Affiliate Brand Bidding & Attribution Cannibalization',
        'Ramadan Campaign Brand Safety: Contextual AI Vetting Across Arabic Video & Social Channels'
      ],
      recommendedFunnel: 'BOFU'
    },
    {
      id: 'pattern-technical-contrast',
      name: 'Technical Contrast / Mechanism Deep-Dive',
      formula: '[Mechanism A] vs. [Mechanism B]: Why [Legacy Metric] Misses SIVT & How to Audit It',
      description: 'Contrasts superficial vanity metrics with deep-packet forensic verification to educate senior media buyers.',
      realWorldExamples: [
        'Pre-Bid Avoidance vs. Post-Bid Verification: Why Viewability Isn\'t Catching Sophisticated Invalid Traffic',
        'Click Injection vs Click Spamming Architecture in Mobile Campaigns',
        'Brand Safety Floors vs. Brand Suitability Frameworks: Applying GARM Standards in Programmatic Buying'
      ],
      recommendedFunnel: 'MOFU'
    },
    {
      id: 'pattern-marketplace-defense',
      name: 'Marketplace Buy Box & Margin Defense',
      formula: '[Marketplace/Channel] Buy Box Defense: [N] Warning Signals of Price Scraping & MAP Undercutting',
      description: 'Directly speaks to e-commerce P&L leaders losing organic share and Buy Box revenue to gray-market sellers.',
      realWorldExamples: [
        'Amazon Buy Box Defense: 4 Early Warning Signals of Price Scraping & MAP Undercutting',
        'Noon & Amazon AE Buy-Box Strategy: Stopping Price Scraping Bots in UAE & KSA',
        'Quick Commerce Buy Box Defense: Stopping Out-of-Stock Suppression on Blinkit, Zepto, and Instamart'
      ],
      recommendedFunnel: 'BOFU'
    },
    {
      id: 'pattern-comparative-evaluation',
      name: 'Enterprise Evaluation & Buying Guide',
      formula: 'Enterprise [Category] Software: [N] Critical Questions to Ask Before Choosing a Verification Partner',
      description: 'Targets high-intent buyers evaluating verification and compliance vendors.',
      realWorldExamples: [
        'How to Choose the Right Brand Protection Solution: 8 Key Questions',
        'Enterprise Ad Fraud Detection Software: Comparing Valid8 vs Legacy Verification Tools',
        'Everything You Need to Know About Mobile Ad Fraud in 2026'
      ],
      recommendedFunnel: 'BOFU'
    }
  ],
  contentStructureRules: [
    {
      section: 'Title & Meta Framing',
      guideline: 'Must adhere to one of the 6 core title patterns. Never exceed 70 characters without a clear colon separator. Include primary commercial keyword in the first 45 characters.',
      checklist: [
        'Contains diagnostic hook or vertical context',
        'Includes verified focus keyword with search intent alignment',
        'Clear separation between the threat and the solution'
      ]
    },
    {
      section: 'Introduction: The Diagnostic Hook',
      guideline: 'Open with the hidden operational tension or financial leakage figure rather than general background facts. Establish high-stakes empathy with the ICP.',
      checklist: [
        'Quantifies the cost of inaction (e.g., 15-30% spend dilution)',
        'Diagnoses why traditional monitoring or native platform metrics fail',
        'States the specific objective of the article clearly'
      ]
    },
    {
      section: 'Body: Technical Forensics & Attack Anatomy',
      guideline: 'Break down the attack vector step-by-step with technical mechanics (user flow, script injection, attribution timestamp manipulation, scraper proxies).',
      checklist: [
        'Diagrams or visualizes the exploitation lifecycle',
        'Explains how malicious actors bypass basic detection',
        'Contrasts symptoms vs. root cause'
      ]
    },
    {
      section: 'Resolution: Actionable Enterprise Blueprint',
      guideline: 'Provide an actionable 4 to 6-step mitigation roadmap, policy enforcement checklist, or automated verification workflow.',
      checklist: [
        'Gives concrete parameters (e.g., time-to-install thresholds, Buy Box margin delta)',
        'Includes governance or vendor SLA benchmarks',
        'Outlines immediate containment actions'
      ]
    },
    {
      section: 'Conclusion & Consultative CTA',
      guideline: 'End with an unambiguous invitation to run a diagnostic health check or audit using mFilterIt technology.',
      checklist: [
        'Direct link to relevant commercial solution landing page',
        'Low friction offer (no sales pressure, focused on discovery)',
        'Reinforces the primary Trust Pillar (Media Trust, Brand Trust, Financial Trust)'
      ]
    }
  ],
  ctaCatalog: {
    'Ad Fraud Detection': {
      primaryCta: 'Request Free Enterprise Ad Fraud & IVT Audit with mFilterIt',
      rationale: 'Uncovers invalid traffic and SSAI manipulation across programmatic and app campaigns with zero upfront integration.',
      landingPath: 'https://www.mfilterit.com/ad-fraud-audit/'
    },
    'Affiliate Monitoring / Affiliate Fraud Detection': {
      primaryCta: 'Request Free Affiliate Traffic & Brand Bidding Poaching Audit',
      rationale: 'Detects unauthorized partner brand bidding and attribution theft across Google Ads and search engines.',
      landingPath: 'https://www.mfilterit.com/affiliate-audit/'
    },
    'Brand Protection': {
      primaryCta: 'Run a Complimentary Brand Infringement & Counterfeit Scan',
      rationale: 'Scans marketplaces and web domains to locate rogue resellers, phishing portals, and trademark violations.',
      landingPath: 'https://www.mfilterit.com/brand-protection/'
    },
    'Digital Shelf / Marketplace Monitoring': {
      primaryCta: 'Request Digital Shelf & Buy Box Health Check',
      rationale: 'Audits price scraping, MAP compliance, and out-of-stock suppression across Amazon, Flipkart, and Noon.',
      landingPath: 'https://www.mfilterit.com/digital-shelf-demo/'
    },
    'Brand Safety': {
      primaryCta: 'Schedule Contextual Brand Safety & Suitability Audit',
      rationale: 'Assesses media placements against GARM brand suitability floors across Arabic, English, and regional inventory.',
      landingPath: 'https://www.mfilterit.com/brand-safety-demo/'
    },
    'Creative Compliance': {
      primaryCta: 'Schedule Automated Ad Creative Compliance Demo',
      rationale: 'Demonstrates automated AI pre-screening against ASCI, RBI, and regional advertising regulatory standards.',
      landingPath: 'https://www.mfilterit.com/creative-compliance-audit/'
    },
    'Brand Safety & Suitability Monitoring': {
      primaryCta: 'Schedule Contextual Brand Safety & Suitability Audit',
      rationale: 'Assesses media placements against GARM brand suitability floors across Arabic, English, and regional inventory.',
      landingPath: 'https://www.mfilterit.com/brand-safety-demo/'
    },
    'Digital Commerce Intelligence': {
      primaryCta: 'Request Digital Commerce Intelligence & Buy Box Audit',
      rationale: 'Audits marketplace price fluctuations, MAP violations, and buy box suppression across quick commerce and e-commerce.',
      landingPath: 'https://www.mfilterit.com/digital-shelf-demo/'
    },
    'Counterfeit Detection': {
      primaryCta: 'Run a Complimentary Counterfeit Detection & IP Enforcement Scan',
      rationale: 'Scans regional marketplaces and unauthorized sellers to eliminate counterfeit goods and trademark theft.',
      landingPath: 'https://www.mfilterit.com/brand-protection/'
    },
    'Digital Scam Monitoring & Detection': {
      primaryCta: 'Request Digital Scam Defense & Impersonation Audit',
      rationale: 'Monitors rogue domain registrations, phishing scams, and fraudulent social profiles targeting consumer trust.',
      landingPath: 'https://www.mfilterit.com/scam-defense-assessment/'
    },
    'Merchant Onboarding Screening & Risk Verification': {
      primaryCta: 'Schedule Merchant Risk Screening & Compliance Assessment',
      rationale: 'Automates merchant background verification and transaction risk scoring to prevent regulatory non-compliance.',
      landingPath: 'https://www.mfilterit.com/merchant-risk-screening/'
    },
    'Mule Account & Transaction Laundering Monitoring': {
      primaryCta: 'Schedule Mule Account Detection & Anti-Laundering Demo',
      rationale: 'Identifies money mule networks and covert transaction laundering across digital banking and payment aggregators.',
      landingPath: 'https://www.mfilterit.com/transaction-laundering-demo/'
    }
  }
};

/**
 * Validates a title against mFilterIt Editorial Style Guide patterns.
 */
export function analyzeTitleEditorialStyle(title: string): {
  matchedPattern: TitlePattern | null;
  isDiagnostic: boolean;
  hasRootCause: boolean;
  score: number; // 0 - 100
  suggestions: string[];
} {
  const lower = title.toLowerCase();
  const hasQuestion = title.includes('?');
  const hasColon = title.includes(':');
  const hasDiagnosticWords = lower.includes('why') || lower.includes('signs') || lower.includes('red flags') || lower.includes('signals') || lower.includes('vs') || lower.includes('checklist') || lower.includes('audit');
  const hasForensicMechanisms = lower.includes('ssai') || lower.includes('sdk') || lower.includes('ivt') || lower.includes('cookie') || lower.includes('buy box') || lower.includes('poaching') || lower.includes('hijacking') || lower.includes('infringement') || lower.includes('scraping') || lower.includes('bidding');

  let score = 60;
  if (hasColon || hasQuestion) score += 15;
  if (hasDiagnosticWords) score += 15;
  if (hasForensicMechanisms) score += 10;

  const patterns = mFilterItEditorialStyleGuide.titlePatterns;
  let matched: TitlePattern | null = null;

  if (hasQuestion && lower.includes('why')) {
    matched = patterns.find(p => p.id === 'pattern-diagnostic-question') || patterns[0];
  } else if (lower.includes('vs')) {
    matched = patterns.find(p => p.id === 'pattern-technical-contrast') || patterns[3];
  } else if (lower.includes('checklist') || lower.includes('audit') || lower.includes('red flags')) {
    matched = patterns.find(p => p.id === 'pattern-audit-checklist') || patterns[2];
  } else if (lower.includes('buy box') || lower.includes('map') || lower.includes('shelf')) {
    matched = patterns.find(p => p.id === 'pattern-marketplace-defense') || patterns[4];
  } else if (lower.includes('how fakes') || lower.includes('how rogue') || lower.includes('how to protect')) {
    matched = patterns.find(p => p.id === 'pattern-threat-defense') || patterns[1];
  } else {
    matched = patterns.find(p => p.id === 'pattern-comparative-evaluation') || patterns[5];
  }

  const suggestions: string[] = [];
  if (!hasColon && !hasQuestion) {
    suggestions.push('Add a two-part colon structure [Diagnostic Hook]: [Enterprise Defense Playbook].');
  }
  if (!hasDiagnosticWords) {
    suggestions.push('Incorporate diagnostic terminology (e.g., "5 Early Warning Signs", "Why App Install Fraud Begins Before the Install").');
  }

  return {
    matchedPattern: matched,
    isDiagnostic: hasQuestion || hasDiagnosticWords,
    hasRootCause: hasForensicMechanisms,
    score: Math.min(100, score),
    suggestions
  };
}

/**
 * Returns consultative CTA for any solution according to the style guide.
 */
export function getStyleGuideCta(solution: mFilterItSolution): string {
  const item = mFilterItEditorialStyleGuide.ctaCatalog[solution];
  return item ? item.primaryCta : 'Request Free Enterprise Digital Trust Audit with mFilterIt';
}
