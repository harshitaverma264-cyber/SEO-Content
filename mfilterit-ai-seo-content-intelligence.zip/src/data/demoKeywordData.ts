import {
  MasterKeywordRecord,
  LiveRankingRecord,
  MasterDataSourceInfo,
  LiveRankingWorkbookInfo,
} from '../types/keywordIntelligence';

export const INITIAL_EMPTY_DATA_SOURCES: {
  masterSources: Record<'INDIA' | 'USA' | 'MENA', MasterDataSourceInfo>;
  liveRankingWorkbook: LiveRankingWorkbookInfo;
} = {
  masterSources: {
    INDIA: {
      id: 'india-master',
      region: 'INDIA',
      name: 'India — All Keywords',
      status: 'NOT CONNECTED',
      rowCount: 0,
      keywordCount: 0,
      detectedColumns: [],
      validationWarnings: [],
      records: [],
    },
    USA: {
      id: 'usa-master',
      region: 'USA',
      name: 'USA — All Keywords',
      status: 'NOT CONNECTED',
      rowCount: 0,
      keywordCount: 0,
      detectedColumns: [],
      validationWarnings: [],
      records: [],
    },
    MENA: {
      id: 'mena-master',
      region: 'MENA',
      name: 'MENA — All Keywords',
      status: 'NOT CONNECTED',
      rowCount: 0,
      keywordCount: 0,
      detectedColumns: [],
      validationWarnings: [],
      records: [],
    },
  },
  liveRankingWorkbook: {
    id: 'live-rankings-workbook',
    name: 'Live Ranking Workbook',
    status: 'NOT CONNECTED',
    currentWeekLabel: 'Week 40 - 2026',
    tabs: {
      INDIA: {
        tabName: 'India Live Rankings',
        region: 'INDIA',
        rowCount: 0,
        detectedColumns: [],
        records: [],
        validationWarnings: [],
      },
      USA: {
        tabName: 'USA Live Rankings',
        region: 'USA',
        rowCount: 0,
        detectedColumns: [],
        records: [],
        validationWarnings: [],
      },
      MENA: {
        tabName: 'MENA Live Rankings',
        region: 'MENA',
        rowCount: 0,
        detectedColumns: [],
        records: [],
        validationWarnings: [],
      },
    },
    validationWarnings: [],
  },
};

/**
 * Curated Demo Dataset clearly labeled DEMO DATA for architecture inspection
 */
export const DEMO_MASTER_KEYWORDS: Record<'INDIA' | 'USA' | 'MENA', MasterKeywordRecord[]> = {
  INDIA: [
    { id: 'in-kw-1', keyword: 'brand bidding affiliate fraud', searchVolume: 1600, keywordDifficulty: 42, cpc: 4.80, searchIntent: 'Commercial Investigation', region: 'INDIA', additionalFields: { 'Source': 'SEMrush India' } },
    { id: 'in-kw-2', keyword: 'app install fraud detection india', searchVolume: 2400, keywordDifficulty: 58, cpc: 7.20, searchIntent: 'Commercial Investigation', region: 'INDIA', additionalFields: { 'Source': 'SEMrush India' } },
    { id: 'in-kw-3', keyword: 'ad fraud detection software', searchVolume: 3200, keywordDifficulty: 65, cpc: 8.50, searchIntent: 'Commercial Investigation', region: 'INDIA', additionalFields: { 'Source': 'SEMrush India' } },
    { id: 'in-kw-4', keyword: 'creative compliance automation bfsi', searchVolume: 880, keywordDifficulty: 35, cpc: 6.10, searchIntent: 'Commercial Investigation', region: 'INDIA', additionalFields: { 'Source': 'SEMrush India' } },
    { id: 'in-kw-5', keyword: 'click injection vs click spamming', searchVolume: 1200, keywordDifficulty: 48, cpc: 3.20, searchIntent: 'Informational', region: 'INDIA', additionalFields: { 'Source': 'SEMrush India' } },
    { id: 'in-kw-6', keyword: 'quick commerce buy box monitoring', searchVolume: 1400, keywordDifficulty: 38, cpc: 5.50, searchIntent: 'Commercial Investigation', region: 'INDIA', additionalFields: { 'Source': 'SEMrush India' } },
    { id: 'in-kw-7', keyword: 'affiliate fraud audit', searchVolume: 950, keywordDifficulty: 45, cpc: 4.20, searchIntent: 'Commercial Investigation', region: 'INDIA', additionalFields: { 'Source': 'SEMrush India' } },
    { id: 'in-kw-8', keyword: 'what is ad fraud', searchVolume: 8100, keywordDifficulty: 72, cpc: 2.10, searchIntent: 'Informational', region: 'INDIA', additionalFields: { 'Source': 'SEMrush India' } },
  ],
  USA: [
    { id: 'us-kw-1', keyword: 'best ad fraud detection software', searchVolume: 4400, keywordDifficulty: 74, cpc: 18.50, searchIntent: 'Commercial Investigation', region: 'USA', additionalFields: { 'Source': 'Ahrefs USA' } },
    { id: 'us-kw-2', keyword: 'map violation monitoring amazon', searchVolume: 2900, keywordDifficulty: 52, cpc: 12.00, searchIntent: 'Commercial Investigation', region: 'USA', additionalFields: { 'Source': 'Ahrefs USA' } },
    { id: 'us-kw-3', keyword: 'ctv ad fraud prevention', searchVolume: 1900, keywordDifficulty: 61, cpc: 15.20, searchIntent: 'Commercial Investigation', region: 'USA', additionalFields: { 'Source': 'Ahrefs USA' } },
    { id: 'us-kw-4', keyword: 'digital shelf share of voice sov', searchVolume: 1600, keywordDifficulty: 46, cpc: 9.80, searchIntent: 'Commercial Investigation', region: 'USA', additionalFields: { 'Source': 'Ahrefs USA' } },
    { id: 'us-kw-5', keyword: 'enterprise ad fraud tool roi', searchVolume: 720, keywordDifficulty: 38, cpc: 14.10, searchIntent: 'Commercial Investigation', region: 'USA', additionalFields: { 'Source': 'Ahrefs USA' } },
    { id: 'us-kw-6', keyword: 'ad fraud detection rfp template', searchVolume: 480, keywordDifficulty: 29, cpc: 11.50, searchIntent: 'Commercial Investigation', region: 'USA', additionalFields: { 'Source': 'Ahrefs USA' } },
    { id: 'us-kw-7', keyword: 'brand safety vs brand suitability', searchVolume: 3200, keywordDifficulty: 55, cpc: 6.40, searchIntent: 'Informational', region: 'USA', additionalFields: { 'Source': 'Ahrefs USA' } },
  ],
  MENA: [
    { id: 'me-kw-1', keyword: 'cookie stuffing affiliate fraud mena', searchVolume: 850, keywordDifficulty: 36, cpc: 7.90, searchIntent: 'Commercial Investigation', region: 'MENA', additionalFields: { 'Source': 'SEMrush UAE' } },
    { id: 'me-kw-2', keyword: 'ramadan ad fraud prevention mena', searchVolume: 1200, keywordDifficulty: 32, cpc: 6.50, searchIntent: 'Commercial Investigation', region: 'MENA', additionalFields: { 'Source': 'SEMrush UAE' } },
    { id: 'me-kw-3', keyword: 'affiliate compliance monitoring dubai', searchVolume: 920, keywordDifficulty: 41, cpc: 8.20, searchIntent: 'Commercial Investigation', region: 'MENA', additionalFields: { 'Source': 'SEMrush UAE' } },
    { id: 'me-kw-4', keyword: 'ecommerce ad spend leakage uae', searchVolume: 640, keywordDifficulty: 30, cpc: 5.70, searchIntent: 'Commercial Investigation', region: 'MENA', additionalFields: { 'Source': 'SEMrush UAE' } },
    { id: 'me-kw-5', keyword: 'brand safety monitoring saudi arabia', searchVolume: 510, keywordDifficulty: 28, cpc: 6.10, searchIntent: 'Commercial Investigation', region: 'MENA', additionalFields: { 'Source': 'SEMrush UAE' } },
  ],
};

export const DEMO_LIVE_RANKINGS: Record<'INDIA' | 'USA' | 'MENA', LiveRankingRecord[]> = {
  INDIA: [
    { id: 'in-live-1', keyword: 'brand bidding affiliate fraud', currentPosition: 12, previousPosition: 16, positionChange: 4, movement: 'IMPROVING', rankingTrend: 'Rising', url: 'https://www.mfilterit.com/blog/brand-bidding-protection/', region: 'INDIA', additionalFields: {} },
    { id: 'in-live-2', keyword: 'ad fraud detection software', currentPosition: 14, previousPosition: 11, positionChange: -3, movement: 'DECLINING', rankingTrend: 'Declining', url: 'https://www.mfilterit.com/solutions/ad-fraud-detection/', region: 'INDIA', additionalFields: {} },
    { id: 'in-live-3', keyword: 'what is ad fraud', currentPosition: 7, previousPosition: 7, positionChange: 0, movement: 'STABLE', rankingTrend: 'Stable', url: 'https://www.mfilterit.com/blog/what-is-ad-fraud/', region: 'INDIA', additionalFields: {} },
    { id: 'in-live-4', keyword: 'affiliate fraud audit', currentPosition: 18, previousPosition: 22, positionChange: 4, movement: 'IMPROVING', rankingTrend: 'Rising', url: 'https://www.mfilterit.com/blog/affiliate-monitoring-guide-2021/', region: 'INDIA', additionalFields: {} },
    { id: 'in-live-5', keyword: 'click injection vs click spamming', currentPosition: 26, previousPosition: undefined, positionChange: undefined, movement: 'NEWLY RANKING', rankingTrend: 'New', url: 'https://www.mfilterit.com/blog/mobile-attribution-fraud/', region: 'INDIA', additionalFields: {} },
  ],
  USA: [
    { id: 'us-live-1', keyword: 'best ad fraud detection software', currentPosition: 15, previousPosition: 19, positionChange: 4, movement: 'IMPROVING', rankingTrend: 'Rising', url: 'https://www.mfilterit.com/solutions/ad-fraud-detection/', region: 'USA', additionalFields: {} },
    { id: 'us-live-2', keyword: 'map violation monitoring amazon', currentPosition: 9, previousPosition: 8, positionChange: -1, movement: 'DECLINING', rankingTrend: 'Declining', url: 'https://www.mfilterit.com/solutions/digital-shelf-monitoring/', region: 'USA', additionalFields: {} },
    { id: 'us-live-3', keyword: 'brand safety vs brand suitability', currentPosition: 6, previousPosition: 6, positionChange: 0, movement: 'STABLE', rankingTrend: 'Stable', url: 'https://www.mfilterit.com/blog/brand-safety-suitability/', region: 'USA', additionalFields: {} },
    { id: 'us-live-4', keyword: 'enterprise ad fraud tool roi', currentPosition: 22, previousPosition: 28, positionChange: 6, movement: 'IMPROVING', rankingTrend: 'Rising', url: 'https://www.mfilterit.com/roi-calculator/', region: 'USA', additionalFields: {} },
  ],
  MENA: [
    { id: 'me-live-1', keyword: 'cookie stuffing affiliate fraud mena', currentPosition: 13, previousPosition: 17, positionChange: 4, movement: 'IMPROVING', rankingTrend: 'Rising', url: 'https://www.mfilterit.com/solutions/affiliate-monitoring/', region: 'MENA', additionalFields: {} },
    { id: 'me-live-2', keyword: 'affiliate compliance monitoring dubai', currentPosition: 8, previousPosition: 8, positionChange: 0, movement: 'STABLE', rankingTrend: 'Stable', url: 'https://www.mfilterit.com/mena/', region: 'MENA', additionalFields: {} },
    { id: 'me-live-3', keyword: 'ramadan ad fraud prevention mena', currentPosition: 24, previousPosition: undefined, positionChange: undefined, movement: 'NEWLY RANKING', rankingTrend: 'New', url: 'https://www.mfilterit.com/mena/', region: 'MENA', additionalFields: {} },
  ],
};
