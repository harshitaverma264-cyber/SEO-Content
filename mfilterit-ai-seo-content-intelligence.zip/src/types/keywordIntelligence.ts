import { Region, mFilterItSolution, FunnelStage, ContentAction, PotentialLevel, IcpPersona } from './seo';

export type RankingMovement = 'IMPROVING' | 'DECLINING' | 'STABLE' | 'NEWLY RANKING' | 'LOST RANKING';

export type KeywordOpportunityCategory =
  | 'QUICK WINS'
  | 'STRIKING DISTANCE'
  | 'DECLINING'
  | 'RISING'
  | 'NEWLY RANKING'
  | 'LOST'
  | 'CONTENT GAPS'
  | 'COMMERCIAL OPPORTUNITIES';

export type DataSourceStatus =
  | 'CONNECTED'
  | 'NOT CONNECTED'
  | 'SYNCING'
  | 'ERROR'
  | 'DATA VALIDATION REQUIRED';

export interface MasterKeywordRecord {
  id: string;
  keyword: string;
  searchVolume?: number;
  volumeType?: 'Estimated' | 'Verified';
  source?: string;
  lastUpdated?: string;
  keywordDifficulty?: number;
  cpc?: number;
  competition?: string;
  searchIntent?: 'Informational' | 'Commercial Investigation' | 'Transactional' | 'Navigational';
  category?: string;
  product?: string;
  topic?: string;
  region: 'INDIA' | 'USA' | 'MENA';
  additionalFields: Record<string, any>;
}

export interface LiveRankingRecord {
  id: string;
  keyword: string;
  currentPosition?: number | null;
  previousPosition?: number | null;
  positionChange?: number | null;
  movement: RankingMovement;
  rankingTrend: 'Rising' | 'Declining' | 'Stable' | 'New' | 'Lost';
  url?: string;
  date?: string;
  region: 'INDIA' | 'USA' | 'MENA';
  additionalFields: Record<string, any>;
}

export interface CombinedKeywordOpportunity {
  id: string;
  keyword: string;
  region: 'INDIA' | 'USA' | 'MENA';
  category: KeywordOpportunityCategory;
  currentPosition?: number;
  previousPosition?: number;
  positionChange?: number;
  movement?: RankingMovement;
  searchVolume?: number;
  volumeType?: 'Estimated' | 'Verified';
  source?: string;
  lastUpdated?: string;
  keywordDifficulty?: number;
  searchIntent: 'Informational' | 'Commercial Investigation' | 'Transactional' | 'Navigational';
  funnelStage: FunnelStage;
  productMapping: mFilterItSolution;
  icpPersona: IcpPersona;
  leadPotential: PotentialLevel;
  conversionPotential: PotentialLevel;
  recommendedAction: ContentAction;
  existingUrl?: string;
  actionRationale: string;
  cannibalizationRisk: 'High' | 'Medium' | 'Low' | 'None';
  priority: 'High' | 'Medium' | 'Low';
  serpsCheckDate?: string;
  serpsSourceUrl?: string;
  isDemoData?: boolean;
}

export interface MasterDataSourceInfo {
  id: 'india-master' | 'usa-master' | 'mena-master';
  region: 'INDIA' | 'USA' | 'MENA';
  name: string;
  fileName?: string;
  status: DataSourceStatus;
  lastUpdated?: string;
  rowCount: number;
  keywordCount: number;
  detectedColumns: string[];
  validationWarnings: string[];
  records: MasterKeywordRecord[];
  isDemoData?: boolean;
}

export interface LiveRankingTabInfo {
  tabName: 'India Live Rankings' | 'USA Live Rankings' | 'MENA Live Rankings';
  region: 'INDIA' | 'USA' | 'MENA';
  rowCount: number;
  detectedColumns: string[];
  records: LiveRankingRecord[];
  validationWarnings: string[];
}

export interface LiveRankingWorkbookInfo {
  id: 'live-rankings-workbook';
  name: string;
  fileName?: string;
  status: DataSourceStatus;
  lastUpdated?: string;
  currentWeekLabel?: string;
  tabs: {
    INDIA: LiveRankingTabInfo;
    USA: LiveRankingTabInfo;
    MENA: LiveRankingTabInfo;
  };
  validationWarnings: string[];
  isDemoData?: boolean;
}
