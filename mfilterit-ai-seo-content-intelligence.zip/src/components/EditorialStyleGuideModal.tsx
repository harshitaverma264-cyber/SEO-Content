import React, { useState } from 'react';
import {
  X,
  BookOpen,
  ShieldCheck,
  CheckCircle2,
  Sparkles,
  Search,
  Target,
  ArrowRight,
  ExternalLink,
  Layers,
  FileCheck
} from 'lucide-react';
import {
  mFilterItEditorialStyleGuide,
  analyzeTitleEditorialStyle
} from '../data/editorialStyleGuide';
import { ALL_TRUST_PILLARS } from '../utils/trustPillar';

interface EditorialStyleGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const EditorialStyleGuideModal: React.FC<EditorialStyleGuideModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [testTitle, setTestTitle] = useState('');
  const [activeTab, setActiveTab] = useState<'voice' | 'pillars' | 'patterns' | 'structure' | 'tester'>('patterns');

  if (!isOpen) return null;

  const testAnalysis = testTitle.trim() ? analyzeTitleEditorialStyle(testTitle) : null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl shadow-2xl border border-neutral-200 w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden my-auto">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-200 bg-linear-to-r from-purple-50 via-white to-purple-50/30 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#530093] text-white flex items-center justify-center shadow-xs">
              <BookOpen className="w-5 h-5 text-[#FFCC29]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-bold tracking-wider text-[#530093] uppercase">
                  Internal Standards
                </span>
                <span className="text-neutral-300">·</span>
                <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.2 rounded border border-emerald-200">
                  Grounded in Live mFilterIt.com/blog/
                </span>
              </div>
              <h2 className="text-base font-extrabold text-neutral-900 tracking-tight">
                mFilterIt Internal Editorial Style Guide
              </h2>
            </div>
          </div>
          
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-neutral-700 p-1.5 rounded-lg hover:bg-neutral-100 transition-colors cursor-pointer"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center px-6 border-b border-neutral-200 bg-neutral-50/60 overflow-x-auto gap-2 py-2 shrink-0">
          <button
            onClick={() => setActiveTab('patterns')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'patterns'
                ? 'bg-white text-[#530093] shadow-xs border border-neutral-200'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-[#530093]" />
            <span>Title Patterns & Formulae</span>
          </button>

          <button
            onClick={() => setActiveTab('pillars')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'pillars'
                ? 'bg-white text-[#530093] shadow-xs border border-neutral-200'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>3 Trust Pillars</span>
          </button>

          <button
            onClick={() => setActiveTab('voice')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'voice'
                ? 'bg-white text-[#530093] shadow-xs border border-neutral-200'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            <Target className="w-3.5 h-3.5 text-[#530093]" />
            <span>Brand Voice & Positioning</span>
          </button>

          <button
            onClick={() => setActiveTab('structure')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'structure'
                ? 'bg-white text-[#530093] shadow-xs border border-neutral-200'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            <Layers className="w-3.5 h-3.5 text-neutral-600" />
            <span>Article Structure & CTAs</span>
          </button>

          <button
            onClick={() => setActiveTab('tester')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'tester'
                ? 'bg-white text-[#530093] shadow-xs border border-neutral-200'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            <FileCheck className="w-3.5 h-3.5 text-amber-600" />
            <span>Title Diagnostic Tester</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          
          {/* TAB 1: TITLE PATTERNS */}
          {activeTab === 'patterns' && (
            <div className="space-y-4">
              <div className="p-3.5 bg-purple-50/80 border border-purple-200 rounded-xl">
                <h4 className="text-xs font-bold text-[#530093] uppercase tracking-wide">
                  The mFilterIt Title Constitution
                </h4>
                <p className="text-xs text-neutral-700 mt-1 leading-relaxed">
                  Every mFilterIt title must be <strong>diagnostic, data-backed, and solutions-oriented</strong>. Avoid generic tutorials ("How to do X"). Instead, frame the hidden vulnerability, contrast broken legacy practices with deep verification, and establish concrete technical root causes.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {mFilterItEditorialStyleGuide.titlePatterns.map((pat) => (
                  <div key={pat.id} className="p-4 bg-white border border-neutral-200 rounded-xl space-y-2.5 shadow-2xs hover:border-[#530093]/40 transition-all">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-purple-100 text-[#530093]">
                        {pat.recommendedFunnel}
                      </span>
                      <span className="text-[11px] font-mono text-neutral-400">
                        {pat.id}
                      </span>
                    </div>

                    <h4 className="text-sm font-bold text-neutral-900">
                      {pat.name}
                    </h4>

                    <div className="p-2 bg-neutral-50 rounded border border-neutral-200 font-mono text-[11px] text-purple-900 leading-snug">
                      {pat.formula}
                    </div>

                    <p className="text-xs text-neutral-600 leading-relaxed">
                      {pat.description}
                    </p>

                    <div className="pt-2 border-t border-neutral-100 space-y-1">
                      <span className="text-[10px] text-neutral-400 uppercase font-bold block">
                        Live Published Examples:
                      </span>
                      {pat.realWorldExamples.map((ex, idx) => (
                        <div key={idx} className="flex items-start gap-1.5 text-xs text-neutral-800">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                          <span className="italic">{ex}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: 3 TRUST PILLARS */}
          {activeTab === 'pillars' && (
            <div className="space-y-4">
              <div className="p-3.5 bg-neutral-50 border border-neutral-200 rounded-xl">
                <h4 className="text-xs font-bold text-neutral-900 uppercase tracking-wide">
                  mFilterIt 3 Trust Pillars Architecture
                </h4>
                <p className="text-xs text-neutral-600 mt-1">
                  Every piece of content must clearly map to one of the three enterprise Trust Pillars to ensure strategic messaging alignment.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {mFilterItEditorialStyleGuide.trustPillars.map((tp) => (
                  <div key={tp.pillar} className="p-4 bg-white border border-neutral-200 rounded-xl space-y-3 shadow-2xs">
                    <div className="flex items-center gap-2">
                      <ShieldCheck className="w-5 h-5" style={{ color: tp.color }} />
                      <h4 className="text-sm font-bold text-neutral-900">{tp.pillar}</h4>
                    </div>

                    <div className="space-y-1.5">
                      <span className="text-[10px] text-neutral-400 uppercase font-bold block">Focus Areas &amp; Architecture:</span>
                      <ul className="text-xs text-neutral-700 space-y-1">
                        {tp.focusAreas.map((fa, i) => (
                          <li key={i} className="flex items-start gap-1.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-neutral-300 mt-1.5 shrink-0" />
                            <span>{fa}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="pt-2 border-t border-neutral-100 space-y-1">
                      <span className="text-[10px] text-neutral-400 uppercase font-bold block">Authoritative Solutions:</span>
                      <div className="flex flex-wrap gap-1">
                        {tp.targetSolutions.map((sol, i) => (
                          <span key={i} className="px-1.5 py-0.5 rounded text-[10px] font-medium bg-neutral-100 text-neutral-800 border border-neutral-200">
                            {sol}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="pt-2 border-t border-neutral-100 space-y-1">
                      <span className="text-[10px] text-neutral-400 uppercase font-bold block">Diagnostic Questions:</span>
                      {tp.diagnosticQuestions.map((dq, i) => (
                        <p key={i} className="text-[11px] text-neutral-600 italic bg-neutral-50 p-1.5 rounded border border-neutral-200">
                          "{dq}"
                        </p>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: BRAND VOICE */}
          {activeTab === 'voice' && (
            <div className="space-y-5">
              <div className="p-4 bg-purple-50 rounded-xl border border-purple-200 space-y-1.5">
                <span className="text-[10px] font-bold text-[#530093] uppercase tracking-wide">Core Archetype</span>
                <h3 className="text-sm font-bold text-neutral-900">
                  {mFilterItEditorialStyleGuide.brandVoice.archetype}
                </h3>
                <div className="flex flex-wrap gap-2 pt-2">
                  {mFilterItEditorialStyleGuide.brandVoice.tone.map((t, idx) => (
                    <span key={idx} className="text-xs px-2.5 py-1 bg-white rounded-md border border-purple-200 text-purple-900 font-medium">
                      {t}
                    </span>
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                <h4 className="text-xs font-bold text-neutral-900 uppercase tracking-wider">
                  Core Writing Principles
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {mFilterItEditorialStyleGuide.brandVoice.corePrinciples.map((cp, idx) => (
                    <div key={idx} className="p-4 bg-white border border-neutral-200 rounded-xl space-y-2">
                      <h5 className="text-sm font-bold text-neutral-900">{cp.title}</h5>
                      <p className="text-xs text-neutral-600 leading-relaxed">{cp.description}</p>
                      <div className="p-2 bg-neutral-50 rounded text-[11px] text-purple-900 font-mono">
                        Rule: {cp.rule}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: ARTICLE STRUCTURE & CTAS */}
          {activeTab === 'structure' && (
            <div className="space-y-6">
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-neutral-900 uppercase tracking-wider">
                  Anatomy of a High-Converting mFilterIt Article
                </h4>
                <div className="space-y-3">
                  {mFilterItEditorialStyleGuide.contentStructureRules.map((sr, idx) => (
                    <div key={idx} className="p-3.5 bg-white border border-neutral-200 rounded-xl space-y-2">
                      <div className="flex items-center justify-between">
                        <h5 className="text-xs font-bold text-neutral-900">{sr.section}</h5>
                        <span className="text-[10px] text-neutral-400">Step {idx + 1} of 5</span>
                      </div>
                      <p className="text-xs text-neutral-700 leading-relaxed">{sr.guideline}</p>
                      <div className="flex flex-wrap gap-2 pt-1">
                        {sr.checklist.map((chk, i) => (
                          <span key={i} className="inline-flex items-center gap-1 text-[11px] text-neutral-600 bg-neutral-50 px-2 py-0.5 rounded border border-neutral-200">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            {chk}
                          </span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                <h4 className="text-xs font-bold text-neutral-900 uppercase tracking-wider">
                  Verified Consultative Commercial CTAs Catalog
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {Object.entries(mFilterItEditorialStyleGuide.ctaCatalog).map(([sol, cta]) => (
                    <div key={sol} className="p-3.5 bg-neutral-50 border border-neutral-200 rounded-xl space-y-1.5">
                      <span className="text-[10px] font-bold text-[#530093] uppercase block">{sol}</span>
                      <strong className="text-xs text-neutral-900 block">{cta.primaryCta}</strong>
                      <p className="text-[11px] text-neutral-500">{cta.rationale}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: TITLE DIAGNOSTIC TESTER */}
          {activeTab === 'tester' && (
            <div className="space-y-5">
              <div className="p-4 bg-purple-50/70 border border-purple-200 rounded-xl space-y-2">
                <h4 className="text-xs font-bold text-[#530093] uppercase tracking-wide">
                  Live Title &amp; Topic Diagnostic Tester
                </h4>
                <p className="text-xs text-neutral-700">
                  Type or paste any candidate title to test it against the mFilterIt Editorial Style Guide formulas.
                </p>

                <div className="pt-2">
                  <input
                    type="text"
                    value={testTitle}
                    onChange={(e) => setTestTitle(e.target.value)}
                    placeholder="e.g., Are You Paying for Clicks, or Paying for Users? Why App Install Fraud Begins Before the Install"
                    className="w-full px-3.5 py-2.5 text-xs bg-white border border-neutral-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#530093] focus:border-[#530093]"
                  />
                </div>

                <div className="flex flex-wrap gap-1.5 pt-1">
                  <span className="text-[10px] text-neutral-400">Quick test presets:</span>
                  {[
                    'Are You Paying for Clicks, or Paying for Users? Why App Install Fraud Begins Before the Install',
                    'Amazon Buy Box Defense: 4 Early Warning Signals of Price Scraping & MAP Undercutting',
                    'FY Closing Checklist: Are You Auditing Ad Fraud Media Waste Before Budget Reset?',
                    'Affiliate Growth vs Brand Infringement: How BFSI Brands in MENA Can Stay Protected',
                    'How to prevent ad fraud in 2026'
                  ].map((preset, idx) => (
                    <button
                      key={idx}
                      onClick={() => setTestTitle(preset)}
                      className="text-[10px] bg-white hover:bg-neutral-100 text-neutral-700 px-2 py-0.5 rounded border border-neutral-200 cursor-pointer"
                    >
                      Preset {idx + 1}
                    </button>
                  ))}
                </div>
              </div>

              {testAnalysis && (
                <div className="p-4 bg-white border border-neutral-200 rounded-xl space-y-4 shadow-sm animate-in fade-in duration-150">
                  <div className="flex items-center justify-between pb-3 border-b border-neutral-100">
                    <div>
                      <span className="text-[10px] text-neutral-400 uppercase font-bold block">Editorial Compliance Score</span>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className={`text-2xl font-black ${
                          testAnalysis.score >= 80 ? 'text-emerald-600' : testAnalysis.score >= 60 ? 'text-amber-600' : 'text-red-600'
                        }`}>
                          {testAnalysis.score}%
                        </span>
                        <span className="text-xs font-semibold text-neutral-600">
                          {testAnalysis.score >= 80 ? 'Exceptional mFilterIt Brand Voice Alignment' : 'Needs Diagnostic & Forensic Polish'}
                        </span>
                      </div>
                    </div>

                    {testAnalysis.matchedPattern && (
                      <div className="text-right">
                        <span className="text-[10px] text-neutral-400 uppercase font-bold block">Matched Pattern</span>
                        <span className="text-xs font-bold text-[#530093]">
                          {testAnalysis.matchedPattern.name}
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div className="p-2.5 bg-neutral-50 rounded-lg border border-neutral-200">
                      <span className="text-neutral-500 block text-[10px] uppercase font-semibold">Diagnostic Inquiry / Hook</span>
                      <span className={`font-bold mt-0.5 inline-block ${testAnalysis.isDiagnostic ? 'text-emerald-700' : 'text-amber-700'}`}>
                        {testAnalysis.isDiagnostic ? '✓ Valid Diagnostic Framing' : '✗ Lacks Diagnostic Question / Tension'}
                      </span>
                    </div>

                    <div className="p-2.5 bg-neutral-50 rounded-lg border border-neutral-200">
                      <span className="text-neutral-500 block text-[10px] uppercase font-semibold">Technical Root-Cause Mechanism</span>
                      <span className={`font-bold mt-0.5 inline-block ${testAnalysis.hasRootCause ? 'text-emerald-700' : 'text-amber-700'}`}>
                        {testAnalysis.hasRootCause ? '✓ Includes Forensic Mechanics' : '✗ Generic wording (no attack mechanism)'}
                      </span>
                    </div>
                  </div>

                  {testAnalysis.suggestions.length > 0 && (
                    <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-lg text-xs space-y-1">
                      <strong className="text-amber-900 block font-bold">Optimization Recommendations:</strong>
                      {testAnalysis.suggestions.map((sug, i) => (
                        <p key={i} className="text-amber-800 flex items-start gap-1">
                          <span>•</span>
                          <span>{sug}</span>
                        </p>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-neutral-200 bg-neutral-50 flex items-center justify-between shrink-0">
          <span className="text-[11px] text-neutral-500">
            Validated against real live mFilterIt.com articles &amp; enterprise conversion pathways.
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-bold text-neutral-800 hover:text-neutral-900 bg-white hover:bg-neutral-100 border border-neutral-300 rounded-lg transition-colors cursor-pointer"
          >
            Close Guide
          </button>
        </div>

      </div>
    </div>
  );
};
