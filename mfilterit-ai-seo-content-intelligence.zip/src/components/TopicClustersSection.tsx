import React, { useState } from 'react';
import { Network, Link2, ExternalLink, ArrowRight, Layers, CheckCircle2, Tag, AlertTriangle, ShieldCheck, HelpCircle } from 'lucide-react';
import { TOPIC_CLUSTERS } from '../data/initialMonthlyData';
import { getTrustPillarForItem } from '../utils/trustPillar';

export const TopicClustersSection: React.FC = () => {
  const [selectedClusterId, setSelectedClusterId] = useState<string>(TOPIC_CLUSTERS[0].id);

  const selectedCluster = TOPIC_CLUSTERS.find((c) => c.id === selectedClusterId) || TOPIC_CLUSTERS[0];
  const activeClusterPillar = selectedCluster.trustPillar || getTrustPillarForItem({ productMapping: selectedCluster.solution });

  return (
    <div className="bg-white border border-neutral-200 rounded-lg p-5 space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-3 border-b border-neutral-200 gap-2">
        <div>
          <div className="flex items-center gap-2">
            <Network className="w-4 h-4 text-[#530093]" />
            <h2 className="text-base font-bold text-neutral-900">
              Topical Authority Clusters &amp; Internal Linking Topology
            </h2>
          </div>
          <p className="text-xs text-neutral-500">
            Never create standalone orphan posts. Every monthly piece anchors to a high-equity pillar and drives traffic to a commercial conversion page.
          </p>
        </div>

        <div className="text-xs text-neutral-500">
          <strong className="text-neutral-900">{TOPIC_CLUSTERS.length} Core Solution Clusters</strong> across 3 Trust Pillars
        </div>
      </div>

      {/* Trust Pillar Grouped Cluster Selector */}
      <div className="space-y-3">
        {(['Media Trust', 'Brand Trust', 'Financial Trust'] as const).map((pillar) => {
          const clustersInPillar = TOPIC_CLUSTERS.filter(
            (c) => (c.trustPillar || getTrustPillarForItem({ productMapping: c.solution })) === pillar
          );
          if (clustersInPillar.length === 0) return null;

          return (
            <div key={pillar} className="p-3 bg-neutral-50/80 rounded-lg border border-neutral-200/80 space-y-2">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <span
                  className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded border inline-flex items-center gap-1 ${
                    pillar === 'Media Trust'
                      ? 'bg-purple-100 text-[#530093] border-purple-200'
                      : pillar === 'Brand Trust'
                      ? 'bg-emerald-100 text-emerald-800 border-emerald-200'
                      : 'bg-amber-100 text-amber-800 border-amber-200'
                  }`}
                >
                  <ShieldCheck className="w-3 h-3" />
                  <span>{pillar}</span>
                </span>
                <span className="text-[11px] text-neutral-500 font-medium">
                  {pillar === 'Media Trust'
                    ? 'Ad Traffic Validation · Brand Safety & Suitability · Measurement · Agentic AI'
                    : pillar === 'Brand Trust'
                    ? 'Brand Protection · Counterfeit Detection'
                    : 'Digital Scam Defense · Merchant Risk · Mule Accounts & Laundering'}
                </span>
              </div>

              <div className="flex flex-wrap gap-2 pt-1">
                {clustersInPillar.map((cluster) => {
                  const isSelected = cluster.id === selectedClusterId;
                  return (
                    <button
                      key={cluster.id}
                      onClick={() => setSelectedClusterId(cluster.id)}
                      className={`px-3 py-1.5 text-xs font-semibold rounded-md border transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-[#530093] text-white border-[#530093] shadow-xs'
                          : 'bg-white text-neutral-700 border-neutral-200 hover:bg-neutral-100'
                      }`}
                    >
                      {cluster.clusterName}
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {/* Cluster Map Detail */}
      <div className="bg-neutral-50 border border-neutral-200 rounded-lg p-4 space-y-4">
        
        {/* Pillar & Conversion Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          
          {/* Pillar Definition */}
          <div className="bg-white border border-neutral-200 rounded-md p-3.5 space-y-1.5">
            <div className="flex items-center justify-between text-[11px] text-neutral-500">
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="font-bold text-[#530093] uppercase tracking-wider">Topical Pillar Page</span>
                <span className="text-neutral-300">·</span>
                <span
                  className={`text-[9.5px] font-extrabold uppercase px-1.5 py-0.5 rounded border inline-flex items-center gap-1 ${
                    activeClusterPillar === 'Media Trust'
                      ? 'bg-purple-100 text-[#530093] border-purple-200'
                      : activeClusterPillar === 'Brand Trust'
                      ? 'bg-emerald-100 text-emerald-800 border-emerald-200'
                      : 'bg-amber-100 text-amber-800 border-amber-200'
                  }`}
                >
                  <ShieldCheck className="w-2.5 h-2.5" />
                  <span>{activeClusterPillar}</span>
                </span>
              </div>
              <span className="font-mono text-[10px] bg-neutral-100 px-1.5 py-0.5 rounded">High Equity Core</span>
            </div>
            <div className="text-sm font-bold text-neutral-900">{selectedCluster.pillarTopic}</div>
            <a
              href={selectedCluster.pillarUrl}
              target="_blank"
              rel="noreferrer"
              className="text-[#530093] hover:underline text-xs font-mono flex items-center gap-1 truncate"
            >
              <span>{selectedCluster.pillarUrl}</span>
              <ExternalLink className="w-3 h-3 shrink-0" />
            </a>
          </div>

          {/* Commercial Conversion Destination */}
          <div className="bg-white border border-neutral-200 rounded-md p-3.5 space-y-1.5">
            <div className="flex items-center justify-between text-[11px] text-neutral-500">
              <span className="font-bold text-emerald-800 uppercase tracking-wider">Commercial Conversion Goal</span>
              <span className="font-semibold text-neutral-900 bg-[#FFCC29] px-2 py-0.5 rounded text-[10px]">
                {selectedCluster.primaryCta}
              </span>
            </div>
            <div className="text-sm font-bold text-neutral-900">
              Landing Page: <span className="font-normal text-neutral-600">{selectedCluster.solution}</span>
            </div>
            <a
              href={selectedCluster.commercialLandingPage}
              target="_blank"
              rel="noreferrer"
              className="text-neutral-700 hover:text-[#530093] hover:underline text-xs font-mono flex items-center gap-1 truncate"
            >
              <span>{selectedCluster.commercialLandingPage}</span>
              <ExternalLink className="w-3 h-3 shrink-0" />
            </a>
          </div>

        </div>

        {/* Grouped Target Ranking Queries & Keywords */}
        {selectedCluster.targetKeywords && selectedCluster.targetKeywords.length > 0 && (
          <div className="bg-white border border-neutral-200 rounded-md p-3.5 space-y-2">
            <div className="flex items-center gap-1.5 text-xs font-bold text-neutral-800">
              <Tag className="w-3.5 h-3.5 text-[#530093]" />
              <span>Grouped Cluster Keywords & Ranking Queries ({selectedCluster.targetKeywords.length})</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {selectedCluster.targetKeywords.map((kw, i) => (
                <span key={i} className="px-2 py-1 bg-purple-50 text-[#530093] border border-purple-200 rounded text-[11px] font-mono font-medium">
                  {kw}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Topical Authority Gap Analysis & Missing Supporting Content */}
        {selectedCluster.missingTopics && selectedCluster.missingTopics.length > 0 && (
          <div className="bg-amber-50/70 border border-amber-200 rounded-md p-3.5 space-y-2">
            <div className="flex items-center justify-between text-xs font-bold text-amber-900">
              <div className="flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-amber-600" />
                <span>Topical Authority Gap Analysis (Missing Supporting Content Needed)</span>
              </div>
              <span className="text-[10px] bg-amber-200/80 px-2 py-0.5 rounded text-amber-900 font-bold uppercase">
                {selectedCluster.missingTopics.length} Content Gaps Identified
              </span>
            </div>
            <div className="space-y-2">
              {selectedCluster.missingTopics.map((gap, i) => (
                <div key={i} className="p-2.5 bg-white rounded border border-amber-200/80 text-xs space-y-1">
                  <div className="flex items-center justify-between font-bold text-neutral-900">
                    <span>{gap.title}</span>
                    <div className="flex items-center gap-1.5 text-[10px]">
                      <span className="px-1.5 py-0.5 bg-neutral-100 text-neutral-700 font-mono rounded">{gap.suggestedFunnel}</span>
                      <span className="px-1.5 py-0.5 bg-red-100 text-red-800 font-bold rounded">{gap.priority} Priority Gap</span>
                    </div>
                  </div>
                  <p className="text-[11.5px] text-neutral-600">{gap.gapRationale}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Cannibalization Avoidance Rules */}
        {selectedCluster.cannibalizationRules && selectedCluster.cannibalizationRules.length > 0 && (
          <div className="bg-emerald-50/70 border border-emerald-200 rounded-md p-3.5 space-y-1.5 text-xs text-emerald-900">
            <div className="flex items-center gap-1.5 font-bold text-emerald-950">
              <ShieldCheck className="w-4 h-4 text-emerald-700" />
              <span>Cannibalization Avoidance & Intent Separation Rules</span>
            </div>
            <ul className="list-disc list-inside space-y-0.5 text-[11.5px] text-emerald-800">
              {selectedCluster.cannibalizationRules.map((rule, i) => (
                <li key={i}>{rule}</li>
              ))}
            </ul>
          </div>
        )}

        {/* Supporting Cluster Nodes */}
        <div className="bg-white border border-neutral-200 rounded-md p-4 space-y-3">
          <div className="flex items-center justify-between text-xs font-semibold text-neutral-800 border-b border-neutral-100 pb-2">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-[#530093]" />
              <span>Supporting Cluster Content (Internal Link Sources)</span>
            </div>
            <span className="text-[11px] text-neutral-500">
              {selectedCluster.supportingTopics.length} Articles passing link equity to Pillar
            </span>
          </div>

          <div className="divide-y divide-neutral-100">
            {selectedCluster.supportingTopics.map((node, idx) => {
              return (
                <div
                  key={idx}
                  className="py-2.5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 text-xs"
                >
                  <div className="flex items-center gap-2.5">
                    <span className="text-neutral-400 font-mono text-[11px]">0{idx + 1}.</span>
                    <span className="font-medium text-neutral-900">{node.title}</span>
                  </div>

                  <div className="flex items-center gap-3 text-[11px]">
                    <span className="font-mono text-neutral-600">{node.contentType}</span>
                    <span className="text-neutral-300">·</span>
                    <span className="font-semibold text-[#530093]">{node.funnel}</span>
                    <span className="text-neutral-300">·</span>
                    <span className="font-medium text-neutral-700">{node.action}</span>
                    <span className="text-neutral-300">·</span>
                    <span
                      className={`font-semibold ${
                        node.status === 'Published'
                          ? 'text-emerald-700'
                          : node.status === 'In Progress'
                          ? 'text-amber-700'
                          : 'text-neutral-500'
                      }`}
                    >
                      {node.status}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Internal Linking Path Diagram */}
          <div className="mt-2 pt-3 border-t border-neutral-100 bg-neutral-50 p-2.5 rounded text-xs text-neutral-600 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-[11.5px]">
              <Link2 className="w-3.5 h-3.5 text-[#530093]" />
              <span>Conversion Link Flow:</span>
              <strong className="text-neutral-800">Supporting Article</strong>
              <ArrowRight className="w-3 h-3 text-neutral-400" />
              <strong className="text-neutral-800">Cluster Pillar</strong>
              <ArrowRight className="w-3 h-3 text-neutral-400" />
              <strong className="text-emerald-700">Commercial Audit / Demo CTA</strong>
            </div>
            <div className="text-[11px] text-neutral-500 italic">
              Contextual anchors enforced in drafts
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
