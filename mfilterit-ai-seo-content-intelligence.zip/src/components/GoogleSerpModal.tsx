import React, { useState, useEffect } from 'react';
import {
  Search,
  X,
  ExternalLink,
  Globe,
  Sparkles,
  BookOpen,
  CheckCircle2,
  ListOrdered,
  Plus,
  Loader2,
  FileText,
  Tag,
  TrendingUp,
  ShieldCheck,
  Building2
} from 'lucide-react';
import { ContentItem } from '../types/seo';

export interface SerpResultItem {
  rank: number;
  title: string;
  domain: string;
  url: string;
  snippet: string;
}

export interface TopBlogItem {
  rank: number;
  title: string;
  domain: string;
  url: string;
  snippet: string;
  keyTakeaways: string[];
}

export interface SerpResponseData {
  keyword: string;
  region?: string;
  searchIntent: string;
  dominantFormat: string;
  aiOverviewAppears: boolean;
  aiOverviewSummary?: string;
  serpFeatures: string[];
  serpResults: SerpResultItem[];
  topBlogs: TopBlogItem[];
}

interface GoogleSerpModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialKeyword: string;
  initialRegion?: 'INDIA' | 'USA' | 'MENA' | 'GLOBAL';
  onSendToCalendar?: (title: string, keyword: string, targetUrl?: string) => void;
}

export const GoogleSerpModal: React.FC<GoogleSerpModalProps> = ({
  isOpen,
  onClose,
  initialKeyword,
  initialRegion = 'INDIA',
  onSendToCalendar,
}) => {
  const [searchTerm, setSearchTerm] = useState(initialKeyword);
  const [region, setRegion] = useState<'INDIA' | 'USA' | 'MENA' | 'GLOBAL'>(initialRegion);
  const [loading, setLoading] = useState(false);
  const [serpData, setSerpData] = useState<SerpResponseData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [addedItems, setAddedItems] = useState<Record<string, boolean>>({});

  const fetchSerp = async (kw: string, selectedReg: string = region) => {
    if (!kw || !kw.trim()) return;
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/search-serp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ keyword: kw.trim(), region: selectedReg }),
      });
      if (!res.ok) {
        throw new Error(`Server returned ${res.status}`);
      }
      const data: SerpResponseData = await res.json();
      setSerpData(data);
    } catch (err: any) {
      console.warn('Notice fetching SERP:', err);
      setError('Unable to fetch live Google SERP. Displaying cached Google search grounded data.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen && initialKeyword) {
      setSearchTerm(initialKeyword);
      setRegion(initialRegion);
      fetchSerp(initialKeyword, initialRegion);
    }
  }, [isOpen, initialKeyword, initialRegion]);

  if (!isOpen) return null;

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      fetchSerp(searchTerm, region);
    }
  };

  const handleAdd = (itemKey: string, title: string, keyword: string, url?: string) => {
    if (onSendToCalendar) {
      onSendToCalendar(title, keyword, url);
      setAddedItems((prev) => ({ ...prev, [itemKey]: true }));
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-neutral-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-neutral-200 w-full max-w-5xl max-h-[92vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header Bar */}
        <div className="bg-gradient-to-r from-[#530093] to-[#3a0068] text-white p-5 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20">
              <Globe className="w-5 h-5 text-[#FFCC29]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-extrabold uppercase tracking-widest text-[#FFCC29]">
                  Live Google SERP Intelligence
                </span>
                <span className="px-2 py-0.5 text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 rounded-full flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  Live Google Search
                </span>
              </div>
              <h2 className="text-lg font-extrabold tracking-tight text-white mt-0.5">
                Google Search Results & Top Blogs
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
            title="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Search Input Bar */}
        <div className="bg-neutral-50 p-4 border-b border-neutral-200 shrink-0">
          <form onSubmit={handleSearchSubmit} className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            
            {/* Region Selector */}
            <div className="flex items-center bg-white border border-neutral-300 rounded-xl px-3 py-2 shrink-0">
              <Globe className="w-4 h-4 text-[#530093] mr-2 shrink-0" />
              <label htmlFor="modal-region-select" className="sr-only">Select Region</label>
              <select
                id="modal-region-select"
                value={region}
                onChange={(e) => {
                  const newReg = e.target.value as 'INDIA' | 'USA' | 'MENA' | 'GLOBAL';
                  setRegion(newReg);
                  if (searchTerm.trim()) {
                    fetchSerp(searchTerm, newReg);
                  }
                }}
                className="bg-transparent text-xs font-bold text-neutral-800 focus:outline-none cursor-pointer pr-1"
              >
                <option value="INDIA">🇮🇳 India (IN)</option>
                <option value="USA">🇺🇸 USA (US)</option>
                <option value="MENA">🇦🇪 MENA (UAE/SA)</option>
                <option value="GLOBAL">🌐 Global</option>
              </select>
            </div>

            <div className="relative flex-1">
              <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search any keyword on Google SERP (e.g. brand safety, ad fraud detection, affiliate fraud)..."
                className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm bg-white border border-neutral-300 rounded-xl font-medium focus:outline-none focus:ring-2 focus:ring-[#530093] focus:border-transparent shadow-xs"
              />
            </div>
            
            <button
              type="submit"
              disabled={loading || !searchTerm.trim()}
              className="px-5 py-2.5 text-xs sm:text-sm font-bold text-neutral-900 bg-[#FFCC29] hover:bg-[#ebd505] rounded-xl transition-all shadow-xs flex items-center gap-2 disabled:opacity-50 cursor-pointer shrink-0"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
              <span>Search Google</span>
            </button>
          </form>

          <p className="text-[11px] text-neutral-500 mt-2.5 flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            <span>
              Regional Google SERP Grounding for <strong>{region}</strong>. Displays regional rankings (e.g. <strong>mFilterIt ranks #3 in India</strong> for "brand safety").
            </span>
          </p>
        </div>

        {/* Body Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 bg-neutral-100/50">
          
          {loading && (
            <div className="py-20 text-center space-y-3">
              <div className="inline-flex p-4 rounded-2xl bg-[#530093]/10 text-[#530093] mb-2 animate-bounce">
                <Globe className="w-8 h-8" />
              </div>
              <h3 className="text-base font-bold text-neutral-800">Querying Google Search Grounding...</h3>
              <p className="text-xs text-neutral-500 max-w-sm mx-auto">
                Fetching current Google SERP positions, real ranking domains, and top 3 blogs for "{searchTerm}".
              </p>
            </div>
          )}

          {error && (
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl text-amber-800 text-xs font-medium flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-600 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {!loading && serpData && (
            <>
              {/* SERP Summary & AI Overview Card */}
              <div className="bg-white rounded-xl p-5 border border-neutral-200 shadow-xs space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-neutral-150 pb-3">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400">
                      Query Grounding Term
                    </span>
                    <h3 className="text-lg font-black font-mono text-[#530093]">
                      "{serpData.keyword}"
                    </h3>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-1 text-xs font-bold rounded-lg bg-[#530093]/10 text-[#530093] border border-[#530093]/20">
                      Intent: {serpData.searchIntent}
                    </span>
                    <span className="px-2.5 py-1 text-xs font-bold rounded-lg bg-[#FFCC29]/30 text-neutral-900 border border-[#FFCC29]/50">
                      Format: {serpData.dominantFormat}
                    </span>
                  </div>
                </div>

                {/* AI Overview Box */}
                {serpData.aiOverviewAppears && (
                  <div className="bg-gradient-to-r from-purple-50 via-indigo-50 to-purple-50 rounded-xl p-4 border border-purple-200/80 space-y-2">
                    <div className="flex items-center gap-2 text-xs font-bold text-[#530093]">
                      <Sparkles className="w-4 h-4 text-[#530093]" />
                      <span>Google AI Overview (Live SERP Feature)</span>
                    </div>
                    <p className="text-xs text-neutral-700 leading-relaxed font-sans">
                      {serpData.aiOverviewSummary || `Google generates a structured AI Overview summary at the top of the organic search results for "${serpData.keyword}".`}
                    </p>
                  </div>
                )}

                {/* Grounded Content Gap & Action Intelligence Box */}
                {(() => {
                  const mFilterItResult = serpData.serpResults.find((r) => r.domain?.includes('mfilterit'));
                  let recommendedAction = 'NEW';
                  let actionBadgeClass = 'bg-blue-100 text-blue-900 border-blue-300';
                  let rationale = `Significant content gap detected on Google for "${serpData.keyword}". Action set to NEW.`;

                  if (mFilterItResult) {
                    recommendedAction = 'REVAMP';
                    actionBadgeClass = 'bg-amber-100 text-amber-900 border-amber-300';
                    rationale = `mFilterIt ranks at position #${mFilterItResult.rank} on Google for "${serpData.keyword}". Recommended action: REVAMP existing page to capture top 3 rankings.`;
                  } else if (serpData.topBlogs && serpData.topBlogs.length >= 3) {
                    recommendedAction = 'EXPAND';
                    actionBadgeClass = 'bg-purple-100 text-purple-900 border-purple-300';
                    rationale = `Competitors (${serpData.topBlogs.map(b => b.domain).slice(0, 2).join(', ')}) cover basic guides. Recommended action: EXPAND into a broader enterprise framework.`;
                  }

                  return (
                    <div className="p-4 bg-white border border-neutral-200 rounded-xl space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 text-xs font-bold text-neutral-900">
                          <Tag className="w-4 h-4 text-[#530093]" />
                          <span>Grounded SERP Gap & Content Action Decision</span>
                        </div>
                        <span className={`px-2.5 py-0.5 text-xs font-extrabold rounded border ${actionBadgeClass}`}>
                          ACTION: {recommendedAction}
                        </span>
                      </div>
                      <p className="text-xs text-neutral-600 leading-normal">
                        {rationale}
                      </p>
                      {mFilterItResult && (
                        <div className="text-[11px] font-mono text-emerald-800 bg-emerald-50 p-2 rounded border border-emerald-200 flex items-center justify-between">
                          <span>Live Brand Rank: Position #{mFilterItResult.rank} ({mFilterItResult.domain})</span>
                          <a href={mFilterItResult.url} target="_blank" rel="noreferrer" className="underline hover:text-[#530093]">View Page</a>
                        </div>
                      )}
                    </div>
                  );
                })()}

                {/* SERP Feature Pills */}
                <div className="flex items-center gap-2 flex-wrap text-xs pt-1">
                  <span className="text-neutral-500 font-semibold text-[11px]">Active SERP Features:</span>
                  {serpData.serpFeatures.map((feat, idx) => (
                    <span key={idx} className="px-2 py-0.5 bg-neutral-100 border border-neutral-200 rounded text-[11px] font-medium text-neutral-700">
                      {feat}
                    </span>
                  ))}
                </div>
              </div>

              {/* TOP 3 BLOGS IN GOOGLE (Highlight Section requested by user) */}
              <div className="bg-gradient-to-br from-amber-500/10 via-amber-500/5 to-purple-500/10 rounded-2xl p-5 border-2 border-[#FFCC29] shadow-xs space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-lg bg-[#FFCC29] text-neutral-900 shadow-xs">
                      <BookOpen className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-base font-extrabold text-neutral-900 tracking-tight">
                        Top 3 Blogs Ranking in Google
                      </h3>
                      <p className="text-xs text-neutral-600">
                        Top three highest-ranking blog articles on Google SERP for "{serpData.keyword}".
                      </p>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 text-[11px] font-bold rounded-full bg-[#530093] text-white">
                    Google Rank #1–#3 Blogs
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-1">
                  {serpData.topBlogs.map((blog, idx) => {
                    const itemKey = `blog-${idx}-${blog.url}`;
                    const isAdded = addedItems[itemKey];

                    return (
                      <div
                        key={idx}
                        className="bg-white rounded-xl p-4 border border-neutral-200 shadow-xs flex flex-col justify-between space-y-3 hover:border-[#530093]/40 transition-all relative overflow-hidden"
                      >
                        <div className="absolute top-0 right-0 px-2.5 py-1 text-[10px] font-extrabold font-mono bg-[#FFCC29] text-neutral-900 rounded-bl-lg">
                          Blog #{blog.rank || idx + 1}
                        </div>

                        <div className="space-y-2 pr-12">
                          <div className="flex items-center gap-1.5 text-[11px] text-[#530093] font-bold">
                            <Building2 className="w-3 h-3 shrink-0" />
                            <span className="truncate">{blog.domain}</span>
                          </div>

                          <a
                            href={blog.url}
                            target="_blank"
                            rel="noreferrer"
                            className="font-bold text-xs sm:text-sm text-neutral-900 hover:text-[#530093] hover:underline line-clamp-2 leading-snug block"
                          >
                            {blog.title}
                          </a>

                          <p className="text-[11.5px] text-neutral-600 leading-relaxed line-clamp-3">
                            {blog.snippet}
                          </p>

                          {blog.keyTakeaways && blog.keyTakeaways.length > 0 && (
                            <div className="pt-2 border-t border-neutral-100 space-y-1">
                              <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400">
                                Key Takeaways
                              </span>
                              <ul className="space-y-1">
                                {blog.keyTakeaways.map((t, tidx) => (
                                  <li key={tidx} className="text-[10.5px] text-neutral-700 flex items-start gap-1">
                                    <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0 mt-0.5" />
                                    <span>{t}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </div>

                        <div className="pt-3 border-t border-neutral-150 flex items-center justify-between gap-2">
                          <a
                            href={blog.url}
                            target="_blank"
                            rel="noreferrer"
                            className="inline-flex items-center gap-1 text-[11px] font-semibold text-neutral-500 hover:text-[#530093]"
                          >
                            <span>Open URL</span>
                            <ExternalLink className="w-3 h-3" />
                          </a>

                          <button
                            onClick={() => handleAdd(itemKey, blog.title, serpData.keyword, blog.url)}
                            disabled={isAdded}
                            className={`px-2.5 py-1 text-[11px] font-bold rounded-lg transition-colors flex items-center gap-1 cursor-pointer ${
                              isAdded
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-[#530093] text-white hover:bg-[#400072]'
                            }`}
                          >
                            {isAdded ? (
                              <>
                                <CheckCircle2 className="w-3 h-3" />
                                <span>Added</span>
                              </>
                            ) : (
                              <>
                                <Plus className="w-3 h-3 text-[#FFCC29]" />
                                <span>Add to Plan</span>
                              </>
                            )}
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* REAL GOOGLE SERP ORGANIC RESULTS TABLE */}
              <div className="bg-white rounded-xl border border-neutral-200 shadow-xs overflow-hidden space-y-0">
                <div className="p-4 border-b border-neutral-200 bg-neutral-50 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <ListOrdered className="w-4 h-4 text-[#530093]" />
                    <h3 className="text-sm font-bold text-neutral-900">
                      Live Google Organic Search Results
                    </h3>
                  </div>
                  <span className="text-xs text-neutral-500 font-mono">
                    Top {serpData.serpResults.length} Organic Results
                  </span>
                </div>

                <div className="divide-y divide-neutral-200">
                  {serpData.serpResults.map((resItem) => {
                    const itemKey = `serp-${resItem.rank}-${resItem.url}`;
                    const isAdded = addedItems[itemKey];

                    return (
                      <div key={resItem.rank} className="p-4 hover:bg-neutral-50/80 transition-colors space-y-1.5">
                        <div className="flex items-center justify-between gap-3">
                          <div className="flex items-center gap-2">
                            <span className="w-6 h-6 rounded-md bg-[#530093]/10 text-[#530093] font-bold font-mono text-xs flex items-center justify-center shrink-0">
                              #{resItem.rank}
                            </span>
                            <span className="text-xs font-mono font-bold text-neutral-500">
                              {resItem.domain}
                            </span>
                          </div>

                          <div className="flex items-center gap-2">
                            <a
                              href={resItem.url}
                              target="_blank"
                              rel="noreferrer"
                              className="text-[11px] text-neutral-500 hover:text-[#530093] hover:underline font-mono inline-flex items-center gap-1"
                            >
                              <span>{resItem.url}</span>
                              <ExternalLink className="w-3 h-3" />
                            </a>

                            <button
                              onClick={() => handleAdd(itemKey, resItem.title, serpData.keyword, resItem.url)}
                              disabled={isAdded}
                              className={`px-2 py-0.5 text-[10.5px] font-bold rounded transition-colors flex items-center gap-1 cursor-pointer ${
                                isAdded
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : 'bg-[#FFCC29] text-neutral-900 hover:bg-[#ebd505]'
                              }`}
                            >
                              {isAdded ? 'Added' : '+ Calendar'}
                            </button>
                          </div>
                        </div>

                        <a
                          href={resItem.url}
                          target="_blank"
                          rel="noreferrer"
                          className="font-bold text-sm text-neutral-900 hover:text-[#530093] hover:underline block leading-snug"
                        >
                          {resItem.title}
                        </a>

                        <p className="text-xs text-neutral-600 leading-relaxed">
                          {resItem.snippet}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>
            </>
          )}

        </div>

        {/* Footer */}
        <div className="p-4 bg-white border-t border-neutral-200 flex items-center justify-between shrink-0">
          <div className="text-xs text-neutral-500 flex items-center gap-1.5">
            <Globe className="w-3.5 h-3.5 text-[#530093]" />
            <span>Google Search Grounded Engine · Real SERP & Blog Data</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-xl transition-colors cursor-pointer"
          >
            Close Results
          </button>
        </div>

      </div>
    </div>
  );
};
