import React, { useEffect } from 'react';
import {
  X,
  FileText,
  Search,
  Compass,
  ExternalLink,
  Target,
  Sparkles,
  Link,
  ShieldCheck,
  BookOpen,
  CheckCircle2
} from 'lucide-react';
import { ContentItem, ContentStatus } from '../types/seo';
import { calculateOpportunityPriority, classifySearchIntentAndFunnel } from '../utils/prioritization';
import { getTrustPillarForItem } from '../utils/trustPillar';
import { analyzeTitleEditorialStyle } from '../data/editorialStyleGuide';

interface ContentDetailModalProps {
  item: ContentItem | null;
  onClose: () => void;
  onUpdateStatus: (itemId: string, newStatus: ContentStatus) => void;
}

/**
 * Extracts a recognizable competitor brand name from a URL,
 * falling back to the hostname if not in the brand dictionary.
 */
function getCompetitorLabel(url: string): string {
  try {
    const parsed = new URL(url.startsWith('http') ? url : `https://${url}`);
    const host = parsed.hostname.replace(/^www\./, '');
    const domain = host.split('.')[0].toLowerCase();

    const knownBrands: Record<string, string> = {
      cheq: 'CHEQ',
      appsflyer: 'AppsFlyer',
      impact: 'Impact',
      adjust: 'Adjust',
      kochava: 'Kochava',
      anura: 'Anura',
      fraudlogix: 'Fraudlogix',
      trafficguard: 'TrafficGuard',
      humansecurity: 'HUMAN Security',
      doubleverify: 'DoubleVerify',
      ias: 'Integral Ad Science (IAS)',
      brandshield: 'BrandShield',
      redpoints: 'Red Points',
      corsearch: 'Corsearch',
      opsec: 'OpSec Security',
      semrush: 'Semrush',
      ahrefs: 'Ahrefs',
    };

    if (knownBrands[domain]) {
      return knownBrands[domain];
    }
    return domain.charAt(0).toUpperCase() + domain.slice(1);
  } catch {
    return url;
  }
}

export const ContentDetailModal: React.FC<ContentDetailModalProps> = ({
  item,
  onClose,
  onUpdateStatus,
}) => {
  useEffect(() => {
    if (!item) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = originalOverflow;
    };
  }, [item, onClose]);

  if (!item) return null;

  const priorityAnalysis = calculateOpportunityPriority(item);
  const primaryKeyword = item.primaryKeyword || item.focusKeyword || 'Not available';
  const primarySearchVolume = item.primarySearchVolume || item.searchVolume;

  const secondaryKeywordsWithVolList = Array.isArray(item.secondaryKeywordsWithVolume) && item.secondaryKeywordsWithVolume.length > 0
    ? item.secondaryKeywordsWithVolume
    : Array.isArray(item.secondaryKeywords)
    ? item.secondaryKeywords.map((k) => {
        const match = k.match(/^(.*?)(?:\s*\((?:Vol|Volume):\s*(\d+)\))?$/i);
        if (match && match[2]) {
          return { keyword: match[1].trim(), searchVolume: parseInt(match[2], 10), volumeType: 'Estimated' as const, source: 'mFilterIt Estimated Engine', lastUpdated: '2026-10-12' };
        }
        return { keyword: k.trim(), searchVolume: undefined, volumeType: 'Estimated' as const, source: 'mFilterIt Estimated Engine', lastUpdated: '2026-10-12' };
      })
    : [];

  const tertiaryKeywordsList = Array.isArray(item.tertiaryKeywords)
    ? item.tertiaryKeywords.filter((k) => k && k.trim().length > 0)
    : [];

  const competitorLinks = Array.isArray(item.competitorReferenceLinks)
    ? item.competitorReferenceLinks.filter((l) => l && l.trim().length > 0)
    : [];

  const isHighPriority = priorityAnalysis.priorityLevel === 'HIGH';
  const isMedPriority = priorityAnalysis.priorityLevel === 'MEDIUM';

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/40 backdrop-blur-[1px] transition-opacity duration-300"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Right-side Drawer panel (widened for full keyword visibility & responsive scannability) */}
      <div className="fixed inset-y-0 right-0 max-w-full flex pl-2 sm:pl-6 md:pl-10">
        <div className="w-screen w-full sm:max-w-2xl md:max-w-3xl lg:max-w-4xl bg-white shadow-2xl border-l border-neutral-200 flex flex-col h-full animate-in slide-in-from-right duration-300">
          
          {/* Header */}
          <div className="p-4 sm:p-5 border-b border-neutral-200 shrink-0 bg-white">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs font-bold text-[#530093] uppercase tracking-wider">
                    Content Details
                  </span>
                  <span className="text-neutral-300">·</span>
                  <span
                    className={`font-bold px-2 py-0.5 rounded text-[10px] uppercase tracking-wider ${
                      isHighPriority
                        ? 'bg-[#530093] text-white'
                        : isMedPriority
                        ? 'bg-[#FFCC29] text-neutral-900 font-semibold'
                        : 'bg-neutral-100 text-neutral-600'
                    }`}
                  >
                    {priorityAnalysis.priorityLevel} PRIORITY
                  </span>
                  <span className="text-neutral-300">·</span>
                  <span
                    className={`font-semibold px-2 py-0.5 rounded text-[10px] uppercase ${
                      priorityAnalysis.leadPotentialLevel === 'HIGH'
                        ? 'bg-[#530093]/10 text-[#530093]'
                        : priorityAnalysis.leadPotentialLevel === 'MEDIUM'
                        ? 'bg-amber-50 text-amber-900'
                        : 'bg-neutral-100 text-neutral-600'
                    }`}
                  >
                    LEAD: {priorityAnalysis.leadPotentialLevel}
                  </span>
                  <span className="text-neutral-300">·</span>
                  <span className="font-mono font-bold px-2 py-0.5 rounded text-[10px] bg-[#FFCC29]/20 text-neutral-900 border border-[#FFCC29]">
                    Score: {priorityAnalysis.leadConversionScore}/100
                  </span>
                </div>
                <h2 className="text-base sm:text-lg font-bold text-neutral-900 mt-2 leading-snug break-words">
                  {item.topic}
                </h2>
              </div>
              <button
                onClick={onClose}
                className="text-neutral-400 hover:text-neutral-700 p-1.5 rounded-md shrink-0 cursor-pointer hover:bg-neutral-100 transition-colors"
                aria-label="Close drawer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Scrollable Content Body */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4 text-xs">
          
          {/* SECTION 1: CONTENT */}
          <div className="bg-neutral-50 rounded-lg p-4 border border-neutral-200 space-y-3">
            <h3 className="font-bold text-neutral-900 uppercase tracking-wider text-[11px] flex items-center gap-1.5 text-[#530093]">
              <FileText className="w-3.5 h-3.5" />
              <span>CONTENT</span>
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div>
                <span className="text-[10px] text-neutral-500 uppercase font-semibold block">Content Type</span>
                <span className="font-semibold text-neutral-900">{item.contentType || 'Not available'}</span>
              </div>
              <div>
                <span className="text-[10px] text-neutral-500 uppercase font-semibold block">Trust Pillar</span>
                {(() => {
                  const pillar = getTrustPillarForItem(item);
                  return (
                    <span
                      className={`inline-flex items-center gap-1 font-bold text-xs ${
                        pillar === 'Media Trust'
                          ? 'text-[#530093]'
                          : pillar === 'Brand Trust'
                          ? 'text-emerald-700'
                          : 'text-amber-700'
                      }`}
                    >
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>{pillar}</span>
                    </span>
                  );
                })()}
              </div>
              <div>
                <span className="text-[10px] text-neutral-500 uppercase font-semibold block">Region</span>
                <span className="font-medium text-neutral-800">
                  {item.region === 'INDIA'
                    ? 'India'
                    : item.region === 'USA'
                    ? 'USA'
                    : item.region === 'MENA'
                    ? 'MENA'
                    : 'Overall'}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-neutral-500 uppercase font-semibold block">Status</span>
                <select
                  value={item.status}
                  onChange={(e) => onUpdateStatus(item.id, e.target.value as ContentStatus)}
                  className="mt-0.5 text-xs font-semibold rounded px-2 py-0.5 bg-white border border-neutral-300 text-neutral-800 cursor-pointer focus:outline-none focus:border-[#530093]"
                >
                  <option value="Planned">Planned</option>
                  <option value="In Progress">In Progress</option>
                  <option value="Needs Review">Needs Review</option>
                  <option value="Published">Published</option>
                </select>
              </div>
            </div>
          </div>

          {/* SECTION 2: SEO */}
          <div className="bg-white rounded-lg p-4 border border-neutral-200 space-y-4">
            <h3 className="font-bold text-neutral-900 uppercase tracking-wider text-[11px] flex items-center gap-1.5 text-[#530093]">
              <Search className="w-3.5 h-3.5" />
              <span>SEO KEYWORDS &amp; SEARCH VOLUMES</span>
            </h3>

            <div className="space-y-4">
              {/* Primary Keyword + Search Volume */}
              <div className="p-3.5 bg-neutral-50/70 rounded-lg border border-neutral-200/90 space-y-2">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                  <span className="text-[10px] text-neutral-500 uppercase font-bold tracking-wider">
                    Primary Target Keyword
                  </span>
                  <span className="text-[10px] text-neutral-400">
                    Main search query being targeted
                  </span>
                </div>
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-2.5">
                  <div className="font-mono font-bold text-xs sm:text-sm text-[#530093] bg-[#530093]/10 px-3 py-1.5 rounded border border-[#530093]/20 break-words whitespace-normal leading-relaxed">
                    {primaryKeyword}
                  </div>
                  {primarySearchVolume ? (
                    <div className="flex items-center gap-1.5 flex-wrap shrink-0">
                      <span className="font-mono text-xs font-bold text-neutral-900 bg-[#FFCC29]/25 border border-[#FFCC29] px-2.5 py-1 rounded inline-flex items-center gap-1.5 shadow-2xs">
                        <span className="text-neutral-500 text-[10px] uppercase font-bold font-sans">Vol:</span>
                        <span className="tabular-nums">{primarySearchVolume.toLocaleString()}</span>
                      </span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                        (item.primaryVolumeType || 'Estimated') === 'Verified'
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                          : 'bg-amber-100 text-amber-900 border border-amber-300'
                      }`}>
                        {item.primaryVolumeType || 'Estimated'}
                      </span>
                      <span className="text-[10px] text-neutral-500 bg-white border border-neutral-200 px-2 py-0.5 rounded" title={`Source: ${item.primarySource || 'mFilterIt Estimated Engine'} | Last Updated: ${item.primaryLastUpdated || '2026-10-12'}`}>
                        {item.primarySource || 'mFilterIt Estimated Engine'} ({item.primaryLastUpdated || '2026-10-12'})
                      </span>
                    </div>
                  ) : null}
                </div>
              </div>

              {/* Secondary Keywords + Search Volume */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-neutral-500 uppercase font-bold tracking-wider">
                    Secondary Keywords ({secondaryKeywordsWithVolList.length})
                  </span>
                  <span className="text-[10px] text-neutral-400">
                    Target supporting queries with search volume &amp; validation status
                  </span>
                </div>
                {secondaryKeywordsWithVolList.length === 0 ? (
                  <span className="text-xs text-neutral-400 italic block py-2">Not available</span>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {secondaryKeywordsWithVolList.map((sk, i) => (
                      <div
                        key={i}
                        className="flex items-start justify-between gap-2.5 font-mono text-xs text-neutral-800 bg-neutral-50 border border-neutral-200/90 rounded-lg p-2.5 hover:bg-neutral-100/70 hover:border-purple-200 transition-colors"
                      >
                        <div className="flex items-start gap-1.5 min-w-0 flex-1">
                          <span className="text-neutral-400 text-[10px] font-bold shrink-0 mt-0.5 select-none">
                            {i + 1}.
                          </span>
                          <span className="font-mono text-[11.5px] font-medium text-neutral-900 break-words whitespace-normal leading-snug">
                            {sk.keyword}
                          </span>
                        </div>
                        {sk.searchVolume !== undefined ? (
                          <div className="shrink-0 flex items-center gap-1 mt-0.5">
                            <span className="text-[10px] font-bold font-mono text-[#530093] bg-[#530093]/10 border border-[#530093]/20 px-2 py-0.5 rounded tabular-nums whitespace-nowrap">
                              Vol: {sk.searchVolume.toLocaleString()}
                            </span>
                            <span
                              className={`text-[9px] font-bold px-1.5 py-0.5 rounded uppercase tracking-wider whitespace-nowrap ${
                                (sk.volumeType || 'Estimated') === 'Verified'
                                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                                  : 'bg-amber-100 text-amber-900 border border-amber-200'
                              }`}
                              title={`Source: ${sk.source || 'mFilterIt Estimated Engine'} | Updated: ${sk.lastUpdated || '2026-10-12'}`}
                            >
                              {sk.volumeType || 'Estimated'}
                            </span>
                          </div>
                        ) : null}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Tertiary Keywords (Without Search Volume) */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-neutral-500 uppercase font-bold tracking-wider">
                    Tertiary Keywords ({tertiaryKeywordsList.length})
                  </span>
                  <span className="text-[10px] text-neutral-400">
                    Long-tail intent variations (full phrasing displayed)
                  </span>
                </div>
                {tertiaryKeywordsList.length === 0 ? (
                  <span className="text-xs text-neutral-400 italic block py-2">Not available</span>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                    {tertiaryKeywordsList.map((kw, i) => (
                      <div
                        key={i}
                        className="flex items-start gap-1.5 font-mono text-[11px] text-neutral-700 bg-neutral-50 border border-neutral-200/80 rounded-lg p-2 hover:bg-neutral-100/70 transition-colors"
                      >
                        <span className="text-neutral-400 text-[10px] font-semibold shrink-0 mt-0.5 select-none">
                          {i + 1}.
                        </span>
                        <span className="break-words whitespace-normal leading-snug flex-1">
                          {kw}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* SECTION 3: STRATEGY */}
          <div className="bg-white rounded-lg p-4 border border-neutral-200 space-y-3">
            <h3 className="font-bold text-neutral-900 uppercase tracking-wider text-[11px] flex items-center gap-1.5 text-[#530093]">
              <Compass className="w-3.5 h-3.5" />
              <span>STRATEGY &amp; SEARCH INTENT ANALYSIS</span>
            </h3>

            {(() => {
              const intentAnalysis = classifySearchIntentAndFunnel(primaryKeyword);
              const searchIntentVal = item.searchIntent || intentAnalysis.intent;
              const funnelVal = item.funnelStage || intentAnalysis.funnelStage;

              return (
                <div className="space-y-3">
                  <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-5 gap-2.5 bg-neutral-50 p-3 rounded-lg border border-neutral-200 text-xs">
                    <div>
                      <span className="text-[10px] text-neutral-500 uppercase font-semibold block">Search Intent</span>
                      <span className="font-bold text-[#530093] mt-0.5 inline-block bg-purple-50 px-2 py-0.5 rounded border border-purple-200">
                        {searchIntentVal}
                      </span>
                    </div>

                    <div>
                      <span className="text-[10px] text-neutral-500 uppercase font-semibold block">Funnel Mapping</span>
                      <span className="font-bold text-neutral-900 mt-0.5 inline-block bg-[#FFCC29]/30 px-2 py-0.5 rounded border border-[#FFCC29]">
                        {funnelVal}
                      </span>
                    </div>

                    <div>
                      <span className="text-[10px] text-neutral-500 uppercase font-semibold block">Content Action</span>
                      <span
                        className={`mt-0.5 inline-block px-2 py-0.5 rounded text-[10px] font-bold tracking-wide uppercase ${
                          item.contentAction === 'NEW'
                            ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                            : item.contentAction === 'REVAMP'
                            ? 'bg-[#530093]/10 text-[#530093] border border-[#530093]/20'
                            : item.contentAction === 'EXPAND'
                            ? 'bg-amber-50 text-amber-900 border border-[#FFCC29]'
                            : item.contentAction === 'MERGE'
                            ? 'bg-red-50 text-red-800 border border-red-200'
                            : 'bg-neutral-100 text-neutral-700 border border-neutral-200'
                        }`}
                      >
                        {item.contentAction}
                      </span>
                    </div>

                    <div>
                      <span className="text-[10px] text-neutral-500 uppercase font-semibold block">mFilterIt Solution</span>
                      <span className="font-medium text-neutral-800 mt-0.5 inline-block break-words" title={item.productMapping}>
                        {item.productMapping || 'Not available'}
                      </span>
                    </div>

                    <div>
                      <span className="text-[10px] text-neutral-500 uppercase font-semibold block">ICP / Persona</span>
                      <span className="font-medium text-neutral-800 mt-0.5 inline-block break-words" title={item.icpPersona}>
                        {item.icpPersona || 'Not available'}
                      </span>
                    </div>
                  </div>

                  <div className="p-2.5 bg-purple-50/60 border border-purple-200/80 rounded-md text-[11.5px] text-purple-900">
                    <strong className="font-bold block mb-0.5">Search Intent Classification Rationale:</strong>
                    <span>{intentAnalysis.intentRationale} Target format: <strong>{intentAnalysis.recommendedFormat}</strong>.</span>
                  </div>
                </div>
              );
            })()}

            {/* Lead Rationale */}
            {item.leadRationale && (
              <div className="pt-2 border-t border-neutral-100 flex items-start gap-2 text-neutral-700">
                <Target className="w-4 h-4 text-[#530093] shrink-0 mt-0.5" />
                <div className="leading-relaxed">
                  <span className="text-[10px] text-neutral-500 uppercase font-semibold block">
                    Lead Rationale
                  </span>
                  <p className="text-xs text-neutral-700 mt-0.5">{item.leadRationale}</p>
                </div>
              </div>
            )}

            {/* Recommended Consultative CTA */}
            {item.recommendedCta && (
              <div className="pt-2 border-t border-neutral-100 flex items-start gap-2 bg-purple-50/50 p-2.5 rounded-lg border border-purple-100">
                <Sparkles className="w-4 h-4 text-[#530093] shrink-0 mt-0.5" />
                <div className="leading-relaxed">
                  <span className="text-[10px] text-[#530093] uppercase font-bold block">
                    Recommended Consultative CTA
                  </span>
                  <p className="text-xs font-bold text-neutral-900 mt-0.5">{item.recommendedCta}</p>
                </div>
              </div>
            )}

            {/* Editorial Style Guide Alignment */}
            {(() => {
              const styleAnalysis = analyzeTitleEditorialStyle(item.topic);
              return (
                <div className="pt-2 border-t border-neutral-100 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-neutral-500 uppercase font-semibold flex items-center gap-1">
                      <BookOpen className="w-3 h-3 text-[#530093]" />
                      <span>Editorial Style Guide Alignment</span>
                    </span>
                    <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                      {styleAnalysis.score}% Diagnostic Score
                    </span>
                  </div>

                  <div className="p-2.5 bg-neutral-50 rounded-lg border border-neutral-200 space-y-1.5 text-xs">
                    {styleAnalysis.matchedPattern && (
                      <div className="flex items-start gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-[#530093] shrink-0 mt-0.5" />
                        <div>
                          <span className="text-[10px] text-neutral-400 uppercase font-bold block">Pattern:</span>
                          <strong className="text-neutral-900">{styleAnalysis.matchedPattern.name}</strong>
                          <p className="text-[11px] text-neutral-500 mt-0.5">{styleAnalysis.matchedPattern.formula}</p>
                        </div>
                      </div>
                    )}
                    <div className="flex items-center gap-2 pt-1 border-t border-neutral-200/60 text-[11px] text-neutral-600">
                      <span>Voice: <strong>Diagnostic &amp; Data-Backed</strong></span>
                      <span>·</span>
                      <span>Format: <strong>Enterprise Playbook</strong></span>
                    </div>
                  </div>
                </div>
              );
            })()}

            {/* Why prioritize this? concise reasons */}
            <div className="pt-2 border-t border-neutral-100 space-y-1.5">
              <span className="text-[10px] text-neutral-500 uppercase font-semibold flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-[#530093]" />
                <span>Why prioritize this?</span>
              </span>
              <div className="space-y-1.5 pt-0.5">
                {priorityAnalysis.reasons.map((r, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-[11.5px] leading-relaxed">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#FFCC29] shrink-0 mt-1.5" />
                    <div>
                      <strong className="text-neutral-900 font-semibold">{r.title}: </strong>
                      <span className="text-neutral-600">{r.explanation}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* SECTION 4: COMPETITOR REFERENCES */}
          <div className="bg-neutral-50 rounded-lg p-4 border border-neutral-200 space-y-2">
            <h3 className="font-bold text-neutral-900 uppercase tracking-wider text-[11px] flex items-center gap-1.5 text-[#530093]">
              <ExternalLink className="w-3.5 h-3.5" />
              <span>COMPETITOR REFERENCES</span>
            </h3>

            {competitorLinks.length === 0 ? (
              <p className="text-xs text-neutral-500 italic py-1">
                No verified competitor references available.
              </p>
            ) : (
              <div className="space-y-2 pt-1">
                {competitorLinks.map((url, idx) => {
                  const label = getCompetitorLabel(url);
                  return (
                    <div
                      key={idx}
                      className="flex items-center justify-between p-2.5 bg-white border border-neutral-200 rounded-md hover:border-[#530093]/40 transition-colors"
                    >
                      <div className="flex items-center gap-2 min-w-0 pr-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#530093] shrink-0" />
                        <div className="min-w-0">
                          <span className="font-semibold text-neutral-900 block truncate">
                            {label}
                          </span>
                          <span className="font-mono text-[10.5px] text-neutral-500 block truncate">
                            {url}
                          </span>
                        </div>
                      </div>
                      <a
                        href={url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#530093] hover:underline bg-[#530093]/10 hover:bg-[#530093]/20 px-2.5 py-1 rounded shrink-0 cursor-pointer"
                        title={`Open ${label} reference in new tab`}
                      >
                        <span>Open Reference</span>
                        <ExternalLink className="w-3 h-3 ml-0.5" />
                      </a>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          </div>

          {/* Footer */}
          <div className="flex items-center justify-end px-5 py-3 border-t border-neutral-200 bg-neutral-50/70 shrink-0">
            <button
              onClick={onClose}
              className="px-4 py-1.5 text-xs font-semibold text-neutral-700 hover:bg-neutral-200/70 bg-white border border-neutral-300 rounded-md cursor-pointer transition-colors shadow-xs"
            >
              Close
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};
