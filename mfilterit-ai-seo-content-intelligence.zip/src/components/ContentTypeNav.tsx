import React from 'react';
import { ContentTypeFilter } from '../types/seo';

interface ContentTypeNavProps {
  activeType: ContentTypeFilter;
  onSelectType: (type: ContentTypeFilter) => void;
  counts: Record<ContentTypeFilter, number>;
}

const TABS: { id: ContentTypeFilter; label: string }[] = [
  { id: 'All Content', label: 'All Content' },
  { id: 'Website Blog', label: 'Website Blog' },
  { id: 'SEO / Guest Post', label: 'SEO / Guest Post' },
  { id: 'Infographic', label: 'Infographic' },
  { id: 'Glossary', label: 'Glossary' },
];

export const ContentTypeNav: React.FC<ContentTypeNavProps> = ({
  activeType,
  onSelectType,
  counts,
}) => {
  return (
    <div className="border-b border-neutral-200 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <nav
          aria-label="Content Type Tabs"
          className="flex space-x-1 sm:space-x-2 overflow-x-auto py-2.5 scrollbar-none"
        >
          {TABS.map((tab) => {
            const isActive = activeType === tab.id;
            const count = counts[tab.id] || 0;

            return (
              <button
                key={tab.id}
                onClick={() => onSelectType(tab.id)}
                className={`whitespace-nowrap px-3.5 py-2 text-xs font-semibold rounded-md transition-all flex items-center gap-2 cursor-pointer ${
                  isActive
                    ? 'bg-[#530093] text-white shadow-xs'
                    : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100'
                }`}
              >
                <span>{tab.label}</span>
                <span
                  className={`text-[11px] tabular-nums font-mono px-1.5 py-0.2 rounded ${
                    isActive
                      ? 'bg-white/20 text-white'
                      : 'bg-neutral-200/70 text-neutral-700'
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
};
