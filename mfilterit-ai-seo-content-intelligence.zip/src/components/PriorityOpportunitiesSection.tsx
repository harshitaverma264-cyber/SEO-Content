import React, { useMemo } from 'react';
import { Target, AlertCircle } from 'lucide-react';
import { ContentItem, ContentTypeFilter } from '../types/seo';
import { getPrioritizedOpportunities } from '../utils/prioritization';

interface PriorityOpportunitiesProps {
  items: ContentItem[];
  activeContentType: ContentTypeFilter;
  onSelectItem: (item: ContentItem) => void;
}

export const PriorityOpportunitiesSection: React.FC<PriorityOpportunitiesProps> = ({
  items,
  activeContentType,
  onSelectItem,
}) => {
  // Dynamically compute up to 5 priority opportunities based on selected month & tab
  const prioritized = useMemo(() => {
    return getPrioritizedOpportunities(items, activeContentType);
  }, [items, activeContentType]);

  return (
    <div className="bg-white border border-neutral-200/90 rounded-2xl p-6 space-y-4 shadow-xs">
      
      {/* Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-3 border-b border-neutral-200 gap-2">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 bg-[#FFCC29] rounded-full inline-block" />
            <h2 className="text-base font-bold text-neutral-900">
              Priority Opportunities
            </h2>
          </div>
          <p className="text-xs text-neutral-500 mt-0.5">
            Content opportunities to prioritize first to generate qualified leads and conversions.
          </p>
        </div>

        {prioritized.length > 0 && (
          <div className="text-xs font-semibold text-[#530093] bg-[#530093]/10 px-2.5 py-1 rounded-md self-start sm:self-auto border border-[#530093]/20">
            {prioritized.length} Priority {prioritized.length === 1 ? 'Recommendation' : 'Recommendations'}
          </div>
        )}
      </div>

      {/* Empty State */}
      {prioritized.length === 0 ? (
        <div className="py-8 px-4 text-center border border-dashed border-neutral-200 rounded-lg bg-neutral-50/50 space-y-2">
          <div className="w-9 h-9 rounded-full bg-neutral-100 flex items-center justify-center mx-auto text-neutral-400">
            <AlertCircle className="w-5 h-5 text-neutral-400" />
          </div>
          <h3 className="text-xs font-bold text-neutral-800 uppercase tracking-wider">
            Not enough data yet
          </h3>
          <p className="text-xs text-neutral-500 max-w-md mx-auto leading-relaxed">
            Connect or provide additional keyword, ranking, website, GSC, GA4 or competitor data to generate stronger opportunity recommendations.
          </p>
        </div>
      ) : (
        /* Up to 5 Priority Cards Grid */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {prioritized.map((opp) => {
            const isHigh = opp.priorityLevel === 'HIGH';
            const isMed = opp.priorityLevel === 'MEDIUM';

            return (
              <div
                key={opp.item.id}
                onClick={() => onSelectItem(opp.item)}
                className="bg-white border border-neutral-200 hover:border-[#530093] rounded-lg p-4 transition-all hover:shadow-2xs cursor-pointer flex flex-col justify-between group space-y-3"
              >
                {/* Topic and Why it matters */}
                <div className="space-y-2">
                  <h3 className="text-xs font-bold text-neutral-900 group-hover:text-[#530093] transition-colors leading-snug">
                    {opp.item.topic}
                  </h3>

                  <p className="text-[11.5px] leading-relaxed text-neutral-600">
                    {opp.whyItMatters}
                  </p>
                </div>

                {/* Metadata Pills: Priority | Lead Score | Action | Lead Potential */}
                <div className="pt-2 border-t border-neutral-100 flex items-center flex-wrap gap-1.5 text-[11px]">
                  {/* Priority Badge */}
                  <span
                    className={`font-bold px-2 py-0.5 rounded text-[10px] uppercase tracking-wider ${
                      isHigh
                        ? 'bg-[#530093] text-white'
                        : isMed
                        ? 'bg-[#FFCC29] text-neutral-900 font-semibold'
                        : 'bg-neutral-100 text-neutral-600'
                    }`}
                  >
                    {opp.priorityLevel} PRIORITY
                  </span>

                  {/* Lead Score Badge */}
                  <span className="font-mono font-bold px-2 py-0.5 rounded text-[10px] bg-[#FFCC29]/20 text-neutral-900 border border-[#FFCC29]">
                    Score: {opp.leadConversionScore}/100
                  </span>

                  {/* Action Badge */}
                  <span className="font-semibold px-2 py-0.5 rounded text-[10px] uppercase bg-neutral-100 text-neutral-700 border border-neutral-200">
                    {opp.action}
                  </span>

                  {/* Lead Potential Badge */}
                  <span
                    className={`font-semibold px-2 py-0.5 rounded text-[10px] uppercase ${
                      opp.leadPotentialLevel === 'HIGH'
                        ? 'bg-[#530093]/10 text-[#530093]'
                        : opp.leadPotentialLevel === 'MEDIUM'
                        ? 'bg-amber-50 text-amber-800'
                        : 'bg-neutral-100 text-neutral-600'
                    }`}
                  >
                    LEAD: {opp.leadPotentialLevel}
                  </span>
                </div>

              </div>
            );
          })}
        </div>
      )}

    </div>
  );
};
