import React, { useState } from 'react';
import {
  Layers,
  FileText,
  Globe,
  Image as ImageIcon,
  BookOpen,
  Swords,
  Target,
  ChevronDown,
  ChevronRight,
  ChevronLeft,
  Calendar,
  Database,
  Network,
  Flame,
  Wrench,
  Users
} from 'lucide-react';
import { ContentTypeFilter } from '../types/seo';
import { AppViewMode } from './Header';

interface SidebarProps {
  activeContentType: ContentTypeFilter;
  onSelectContentType: (type: ContentTypeFilter) => void;
  contentTypeCounts: Record<ContentTypeFilter, number>;
  currentView: AppViewMode;
  onSelectView: (view: AppViewMode) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeContentType,
  onSelectContentType,
  contentTypeCounts,
  currentView,
  onSelectView,
}) => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isCalendarOpen, setIsCalendarOpen] = useState(true);
  const [isToolsOpen, setIsToolsOpen] = useState(true);

  const contentTypeItems: { label: ContentTypeFilter; icon: React.ReactNode }[] = [
    { label: 'All Content', icon: <Layers className="w-4 h-4 shrink-0 text-white" /> },
    { label: 'Website Blog', icon: <FileText className="w-4 h-4 shrink-0 text-white" /> },
    { label: 'SEO / Guest Post', icon: <Globe className="w-4 h-4 shrink-0 text-white" /> },
    { label: 'Infographic', icon: <ImageIcon className="w-4 h-4 shrink-0 text-white" /> },
    { label: 'Glossary', icon: <BookOpen className="w-4 h-4 shrink-0 text-white" /> },
  ];

  return (
    <aside
      className={`bg-[#530093] text-white border-r border-[#430077] flex flex-col justify-between shrink-0 h-screen sticky top-0 z-40 select-none shadow-md transition-all duration-300 ease-in-out ${
        isCollapsed ? 'w-20' : 'w-64'
      }`}
    >
      
      {/* Top Section: Brand & Nav Items */}
      <div className="flex flex-col overflow-y-auto overflow-x-hidden">
        
        {/* Brand Header & Toggle Button */}
        <div className="p-4 pb-3 border-b border-white/20 flex items-center justify-between">
          {!isCollapsed ? (
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-white text-[#530093] flex items-center justify-center font-black text-sm tracking-tighter shrink-0 shadow-2xs">
                m
              </div>
              <div className="flex flex-col">
                <span className="text-lg font-black tracking-tight text-white leading-none">
                  mFilter<span className="text-[#ffcc29]">It</span>
                </span>
              </div>
            </div>
          ) : (
            <div className="mx-auto w-8 h-8 rounded-full bg-white text-[#530093] flex items-center justify-center font-black text-sm tracking-tighter shadow-2xs">
              m
            </div>
          )}

          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="p-1.5 rounded-lg text-white hover:bg-white/15 transition-colors cursor-pointer shrink-0"
            title={isCollapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
          >
            {isCollapsed ? (
              <ChevronRight className="w-4 h-4 text-white" />
            ) : (
              <ChevronLeft className="w-4 h-4 text-white" />
            )}
          </button>
        </div>

        {/* Navigation Section */}
        <div className="p-3 space-y-4">
          
          {/* Direct Items: Keyword Ranking Tracker & Competitor Content Gap Analysis */}
          <div className="space-y-1">
            {/* Keyword Ranking Tracker */}
            <button
              onClick={() => onSelectView('keyword-gap')}
              title={isCollapsed ? "Keyword Ranking Tracker" : undefined}
              className={`w-full flex items-center ${isCollapsed ? 'justify-center p-2.5' : 'justify-between px-3 py-2.5'} rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                currentView === 'keyword-gap'
                  ? 'bg-[#ffcc29]/25 text-[#ffcc29] border border-[#ffcc29]/50 shadow-2xs font-bold'
                  : 'text-white hover:bg-white/15 border border-transparent'
              }`}
            >
              <div className="flex items-center gap-2.5 flex-1 min-w-0 text-left">
                <span className={currentView === 'keyword-gap' ? 'text-[#ffcc29]' : 'text-white'}>
                  <Target className="w-4 h-4 shrink-0" />
                </span>
                {!isCollapsed && <span className="text-white leading-tight break-words">Keyword Ranking Tracker</span>}
              </div>
              {!isCollapsed && (
                <span
                  className={`shrink-0 ml-1.5 text-[10px] font-mono px-1.5 py-0.5 rounded-md ${
                    currentView === 'keyword-gap'
                      ? 'bg-[#ffcc29] text-[#530093] font-black'
                      : 'bg-white/20 text-white font-bold'
                  }`}
                >
                  Live 211
                </span>
              )}
            </button>

            {/* Competitor Content Gap Analysis */}
            <button
              onClick={() => onSelectView('competitor-gap')}
              title={isCollapsed ? "Competitor Content Gap Analysis" : undefined}
              className={`w-full flex items-center ${isCollapsed ? 'justify-center p-2.5' : 'justify-between px-3 py-2.5'} rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                currentView === 'competitor-gap'
                  ? 'bg-[#ffcc29]/25 text-[#ffcc29] border border-[#ffcc29]/50 shadow-2xs font-bold'
                  : 'text-white hover:bg-white/15 border border-transparent'
              }`}
            >
              <div className="flex items-center gap-2.5 flex-1 min-w-0 text-left">
                <span className={currentView === 'competitor-gap' ? 'text-[#ffcc29]' : 'text-white'}>
                  <Swords className="w-4 h-4 shrink-0" />
                </span>
                {!isCollapsed && <span className="text-white leading-tight break-words">Competitor Content Gap Analysis</span>}
              </div>
              {!isCollapsed && (
                <span
                  className={`shrink-0 ml-1.5 text-[10px] font-mono px-1.5 py-0.5 rounded-md ${
                    currentView === 'competitor-gap'
                      ? 'bg-[#ffcc29] text-[#530093] font-black'
                      : 'bg-white/20 text-white font-bold'
                  }`}
                >
                  Studio
                </span>
              )}
            </button>
          </div>

          {/* 2. Content Calendar */}
          <div className="space-y-1">
            {!isCollapsed ? (
              <button
                onClick={() => setIsCalendarOpen(!isCalendarOpen)}
                className="w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-bold text-white hover:bg-white/15 transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <Calendar className="w-4 h-4 text-white shrink-0" />
                  <span className="tracking-wide uppercase text-[11px] text-white">Content Calendar</span>
                </div>
                {isCalendarOpen ? (
                  <ChevronDown className="w-4 h-4 text-white shrink-0 ml-1" />
                ) : (
                  <ChevronRight className="w-4 h-4 text-white shrink-0 ml-1" />
                )}
              </button>
            ) : (
              <div className="px-2 py-1 text-center">
                <span title="Content Calendar"><Calendar className="w-5 h-5 text-white mx-auto" /></span>
              </div>
            )}

            {(isCalendarOpen || isCollapsed) && (
              <div className={!isCollapsed ? "pl-3 space-y-1 border-l-2 border-white/30 ml-3 mt-1" : "space-y-1"}>
                {contentTypeItems.map((item) => {
                  const isActive = currentView === 'calendar' && activeContentType === item.label;
                  const count = contentTypeCounts[item.label] || 0;

                  return (
                    <button
                      key={item.label}
                      title={isCollapsed ? `${item.label} (${count})` : undefined}
                      onClick={() => {
                        onSelectContentType(item.label);
                        if (currentView !== 'calendar') {
                          onSelectView('calendar');
                        }
                      }}
                      className={`w-full flex items-center ${isCollapsed ? 'justify-center p-2.5' : 'justify-between px-3 py-2'} rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                        isActive
                          ? 'bg-[#ffcc29]/25 text-[#ffcc29] border border-[#ffcc29]/50 shadow-2xs font-bold'
                          : 'text-white hover:bg-white/15 border border-transparent'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 flex-1 min-w-0 text-left">
                        <span className={isActive ? 'text-[#ffcc29]' : 'text-white'}>
                          {item.icon}
                        </span>
                        {!isCollapsed && <span className="text-white leading-tight break-words">{item.label}</span>}
                      </div>

                      {!isCollapsed && (
                        <span
                          className={`shrink-0 ml-2 text-[10px] font-mono px-1.5 py-0.5 rounded-md ${
                            isActive
                              ? 'bg-[#ffcc29] text-[#530093] font-black'
                              : 'bg-white/20 text-white font-bold'
                          }`}
                        >
                          {count}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* 3. SEO Tools */}
          <div className="space-y-1">
            {!isCollapsed ? (
              <button
                onClick={() => setIsToolsOpen(!isToolsOpen)}
                className="w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-bold text-white hover:bg-white/15 transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <Wrench className="w-4 h-4 text-white shrink-0" />
                  <span className="tracking-wide uppercase text-[11px] text-white">SEO Tools</span>
                </div>
                {isToolsOpen ? (
                  <ChevronDown className="w-4 h-4 text-white shrink-0 ml-1" />
                ) : (
                  <ChevronRight className="w-4 h-4 text-white shrink-0 ml-1" />
                )}
              </button>
            ) : (
              <div className="px-2 py-1 text-center">
                <span title="SEO Tools"><Wrench className="w-5 h-5 text-white mx-auto" /></span>
              </div>
            )}

            {(isToolsOpen || isCollapsed) && (
              <div className={!isCollapsed ? "pl-3 space-y-1 border-l-2 border-white/30 ml-3 mt-1" : "space-y-1"}>
                {/* Monthly Content Calendar */}
                <button
                  onClick={() => onSelectView('calendar')}
                  title={isCollapsed ? "Monthly Content Calendar" : undefined}
                  className={`w-full flex items-center ${isCollapsed ? 'justify-center p-2.5' : 'justify-between px-3 py-2'} rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    currentView === 'calendar'
                      ? 'bg-[#ffcc29]/25 text-[#ffcc29] border border-[#ffcc29]/50 shadow-2xs font-bold'
                      : 'text-white hover:bg-white/15 border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-2.5 flex-1 min-w-0 text-left">
                    <span className={currentView === 'calendar' ? 'text-[#ffcc29]' : 'text-white'}>
                      <Calendar className="w-4 h-4 shrink-0" />
                    </span>
                    {!isCollapsed && <span className="text-white leading-tight break-words">Monthly Content Calendar</span>}
                  </div>
                </button>


                {/* Keyword Data Sources */}
                <button
                  onClick={() => onSelectView('sources')}
                  title={isCollapsed ? "Keyword Data Sources" : undefined}
                  className={`w-full flex items-center ${isCollapsed ? 'justify-center p-2.5' : 'justify-between px-3 py-2'} rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    currentView === 'sources'
                      ? 'bg-[#ffcc29]/25 text-[#ffcc29] border border-[#ffcc29]/50 shadow-2xs font-bold'
                      : 'text-white hover:bg-white/15 border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-2.5 flex-1 min-w-0 text-left">
                    <span className={currentView === 'sources' ? 'text-[#ffcc29]' : 'text-white'}>
                      <Database className="w-4 h-4 shrink-0" />
                    </span>
                    {!isCollapsed && <span className="text-white leading-tight break-words">Keyword Data Sources</span>}
                  </div>
                </button>

                {/* Topic Clusters */}
                <button
                  onClick={() => onSelectView('clusters')}
                  title={isCollapsed ? "Topic Clusters" : undefined}
                  className={`w-full flex items-center ${isCollapsed ? 'justify-center p-2.5' : 'justify-between px-3 py-2'} rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    currentView === 'clusters'
                      ? 'bg-[#ffcc29]/25 text-[#ffcc29] border border-[#ffcc29]/50 shadow-2xs font-bold'
                      : 'text-white hover:bg-white/15 border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-2.5 flex-1 min-w-0 text-left">
                    <span className={currentView === 'clusters' ? 'text-[#ffcc29]' : 'text-white'}>
                      <Network className="w-4 h-4 shrink-0" />
                    </span>
                    {!isCollapsed && <span className="text-white leading-tight break-words">Topic Clusters</span>}
                  </div>
                </button>

                {/* Seasonality Planning */}
                <button
                  onClick={() => onSelectView('seasonality')}
                  title={isCollapsed ? "Seasonality Planning" : undefined}
                  className={`w-full flex items-center ${isCollapsed ? 'justify-center p-2.5' : 'justify-between px-3 py-2'} rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    currentView === 'seasonality'
                      ? 'bg-[#ffcc29]/25 text-[#ffcc29] border border-[#ffcc29]/50 shadow-2xs font-bold'
                      : 'text-white hover:bg-white/15 border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-2.5 flex-1 min-w-0 text-left">
                    <span className={currentView === 'seasonality' ? 'text-[#ffcc29]' : 'text-white'}>
                      <Flame className="w-4 h-4 shrink-0 text-white" />
                    </span>
                    {!isCollapsed && <span className="text-white leading-tight break-words">Seasonality Planning</span>}
                  </div>
                </button>

                {/* Organic Lead Intelligence */}
                <button
                  onClick={() => onSelectView('lead-intelligence')}
                  title={isCollapsed ? "Organic Lead Intelligence" : undefined}
                  className={`w-full flex items-center ${isCollapsed ? 'justify-center p-2.5' : 'justify-between px-3 py-2'} rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    currentView === 'lead-intelligence'
                      ? 'bg-[#ffcc29]/25 text-[#ffcc29] border border-[#ffcc29]/50 shadow-2xs font-bold'
                      : 'text-white hover:bg-white/15 border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-2.5 flex-1 min-w-0 text-left">
                    <span className={currentView === 'lead-intelligence' ? 'text-[#ffcc29]' : 'text-white'}>
                      <Users className="w-4 h-4 shrink-0 text-white" />
                    </span>
                    {!isCollapsed && <span className="text-white leading-tight break-words">Organic Lead Intelligence</span>}
                  </div>
                </button>
              </div>
            )}
          </div>

        </div>

      </div>

    </aside>
  );
};
