import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Users,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  ShieldCheck,
  ArrowRight,
  Building2,
  ExternalLink,
  Upload,
  Key,
  FileSpreadsheet,
  Search,
  Filter,
  Info,
  Check,
  Calendar,
  Sparkles,
  Globe,
  TrendingUp,
  BarChart3,
  Layers,
  Compass,
  FileText
} from 'lucide-react';
import { fallbackLeadSyncState } from '../data/fallbackLeadSyncState';

export interface LeadRecord {
  id: string;
  company: string;
  industry: string;
  leadType: string;
  status: string;
  source: string;
  region?: string;
  solution?: string;
  createdAt: string;
  isTestOrIncomplete?: boolean;
  qualityTier?: 'VERIFIED' | 'PARTIAL' | 'INCOMPLETE_TEST';
  industryProvenance?: 'ACTUAL' | 'INFERRED' | 'DEFAULT';
  sourceProvenance?: 'ACTUAL' | 'DEFAULTED';
  leadTypeProvenance?: 'ACTUAL' | 'INFERRED' | 'UNSPECIFIED';
  statusProvenance?: 'ACTUAL' | 'DEFAULTED';
  rawRequirements?: string;
  rawEmail?: string;
}

export interface LeadRecommendation {
  id?: string;
  industry: string;
  leadCount: number;
  qualifiedLeadCount?: number;
  leadStatusPattern?: string;
  recommendedTopic: string;
  keyword: string;
  solution: string;
  trustPillar?: 'Media Trust' | 'Brand Trust' | 'Financial Trust';
  region?: 'INDIA' | 'USA' | 'MENA';
  intent?: 'Informational' | 'Commercial Investigation' | 'Transactional';
  funnel?: 'TOFU' | 'MOFU' | 'BOFU';
  targetPersona?: string;
  contentAction?: 'NEW' | 'REVAMP' | 'EXPAND';
  searchVolume?: number;
  currentRanking?: number;
  rankingNote?: string;
  competitorGapName?: string;
  competitorGapUrl?: string;
  buyerPainPoints?: string;
  commercialRelevanceScore?: number;
  verifiedSeoPotentialScore?: number;
  overallPriorityScore?: number;
  whyRecommended?: string;
  isBasedOnReliableLeads?: boolean;
}

interface LeadSyncState {
  status: 'CONNECTED' | 'CONNECTED_WITH_WARNING' | 'AUTH_REQUIRED' | 'ERROR';
  lastSuccessfulSync: string;
  error: string | null;
  totalLeads: number;
  reliableLeadsCount?: number;
  testRecordsCount?: number;
  dataSource?: string;
  leads: LeadRecord[];
  industryBreakdown: Record<string, number>;
  leadTypeBreakdown: Record<string, number>;
  statusBreakdown: Record<string, number>;
  recommendations: LeadRecommendation[];
  sharepointUrl?: string;
  authRequired?: boolean;
  successfulParsing?: boolean;
  workbookDownloadSuccess?: boolean;
  authInstructions?: {
    title: string;
    steps: string[];
    permissionRecommendation: string;
  };
}

interface LeadIntelligenceViewProps {
  onPushToCalendar: (rec: LeadRecommendation) => void;
  onPushAllToCalendar?: (recs: LeadRecommendation[]) => void;
  onOpenGoogleSerp?: (kw: string, region: 'INDIA' | 'USA' | 'MENA' | 'GLOBAL') => void;
}

export const LeadIntelligenceView: React.FC<LeadIntelligenceViewProps> = ({
  onPushToCalendar,
  onPushAllToCalendar,
  onOpenGoogleSerp
}) => {
  const [syncState, setSyncState] = useState<LeadSyncState | null>(() => {
    try {
      const cached = localStorage.getItem('mfilterit_lead_sync_state');
      if (cached) {
        const parsed = JSON.parse(cached);
        if (parsed && parsed.leads && parsed.leads.length > 0) return parsed;
      }
    } catch (_) {}
    return fallbackLeadSyncState as unknown as LeadSyncState;
  });
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [showConfigModal, setShowConfigModal] = useState<boolean>(false);
  const [pushedTopics, setPushedTopics] = useState<Set<string>>(new Set());
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterIndustry, setFilterIndustry] = useState<string>('ALL');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [filterQuality, setFilterQuality] = useState<'RELIABLE' | 'ALL' | 'TEST_INCOMPLETE'>('RELIABLE');

  // Auth config states
  const [customCookie, setCustomCookie] = useState<string>('');
  const [customToken, setCustomToken] = useState<string>('');
  const [customUrl, setCustomUrl] = useState<string>('');
  const [customTenantId, setCustomTenantId] = useState<string>('');
  const [customClientId, setCustomClientId] = useState<string>('');
  const [customClientSecret, setCustomClientSecret] = useState<string>('');
  const [configSuccessMsg, setConfigSuccessMsg] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const fetchLeadData = async (forceSync = false, retries = 2) => {
    try {
      if (forceSync) setIsSyncing(true);
      const endpoint = forceSync ? '/api/lead-status/sync' : '/api/lead-status';
      
      let attempt = 0;
      let lastErr: unknown = null;
      while (attempt <= retries) {
        try {
          const res = await fetch(endpoint, {
            method: forceSync ? 'POST' : 'GET',
            headers: { Accept: 'application/json' }
          });
          if (res.ok) {
            const data: LeadSyncState = await res.json();
            setSyncState(data);
            try {
              localStorage.setItem('mfilterit_lead_sync_state', JSON.stringify(data));
            } catch (_) {}
            return;
          }
        } catch (fetchErr) {
          lastErr = fetchErr;
          attempt++;
          if (attempt <= retries) {
            await new Promise(r => setTimeout(r, 600 * attempt));
            continue;
          }
        }
        break;
      }
      if (lastErr) {
        console.warn('Notice: Background lead sync deferred due to connectivity:', lastErr);
      }
    } catch (err) {
      console.warn('Notice: Lead sync deferred:', err);
    } finally {
      setIsLoading(false);
      setIsSyncing(false);
    }
  };

  useEffect(() => {
    fetchLeadData();
    // 30s client polling to stay in sync with the 1-minute server scheduler
    const interval = setInterval(() => fetchLeadData(), 30000);
    return () => clearInterval(interval);
  }, []);

  const handlePushSingle = (rec: LeadRecommendation) => {
    onPushToCalendar({
      recommendedTopic: rec.recommendedTopic,
      keyword: rec.keyword,
      solution: rec.solution,
      industry: rec.industry,
      leadCount: rec.leadCount
    });
    setPushedTopics(prev => new Set(prev).add(rec.recommendedTopic));
  };

  const handlePushAll = () => {
    if (!syncState?.recommendations || syncState.recommendations.length === 0) return;
    if (onPushAllToCalendar) {
      onPushAllToCalendar(
        syncState.recommendations.map(r => ({
          recommendedTopic: r.recommendedTopic,
          keyword: r.keyword,
          solution: r.solution,
          industry: r.industry,
          leadCount: r.leadCount
        }))
      );
    } else {
      syncState.recommendations.forEach(r => {
        onPushToCalendar({
          recommendedTopic: r.recommendedTopic,
          keyword: r.keyword,
          solution: r.solution,
          industry: r.industry,
          leadCount: r.leadCount
        });
      });
    }
    const newPushed = new Set(pushedTopics);
    syncState.recommendations.forEach(r => newPushed.add(r.recommendedTopic));
    setPushedTopics(newPushed);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsUploading(true);
      const reader = new FileReader();
      reader.onload = async () => {
        const base64Data = reader.result as string;
        const res = await fetch('/api/lead-status/upload', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ filename: file.name, base64: base64Data })
        });
        if (res.ok) {
          const updated = await res.json();
          setSyncState(updated);
        }
        setIsUploading(false);
      };
      reader.readAsDataURL(file);
    } catch (err) {
      console.warn('File upload warning:', err);
      setIsUploading(false);
    }
  };

  const handleSaveConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setIsSyncing(true);
      const res = await fetch('/api/lead-status/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          cookie: customCookie,
          token: customToken,
          url: customUrl,
          tenantId: customTenantId,
          clientId: customClientId,
          clientSecret: customClientSecret
        })
      });
      if (res.ok) {
        const updated = await res.json();
        setSyncState(updated);
        setConfigSuccessMsg('Authentication settings saved and re-synced!');
        setTimeout(() => setConfigSuccessMsg(null), 4000);
      }
    } catch (err) {
      console.warn('Failed to save config:', err);
    } finally {
      setIsSyncing(false);
    }
  };

  const leads = syncState?.leads || [];
  const reliableCount = syncState?.reliableLeadsCount ?? leads.filter(l => !l.isTestOrIncomplete).length;
  const testCount = syncState?.testRecordsCount ?? leads.filter(l => l.isTestOrIncomplete).length;

  const filteredLeads = leads.filter(l => {
    if (filterQuality === 'RELIABLE' && l.isTestOrIncomplete) return false;
    if (filterQuality === 'TEST_INCOMPLETE' && !l.isTestOrIncomplete) return false;

    const matchesSearch =
      searchQuery === '' ||
      l.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
      l.industry.toLowerCase().includes(searchQuery.toLowerCase()) ||
      l.source.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesIndustry = filterIndustry === 'ALL' || l.industry === filterIndustry;
    const matchesStatus = filterStatus === 'ALL' || l.status === filterStatus;
    return matchesSearch && matchesIndustry && matchesStatus;
  });

  const industriesList = Array.from(new Set(leads.filter(l => !l.isTestOrIncomplete).map(l => l.industry))).filter(Boolean);
  const statusesList = Array.from(new Set(leads.map(l => l.status))).filter(Boolean);

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-neutral-500">
        <RefreshCw className="w-8 h-8 animate-spin text-[#530093] mb-3" />
        <span className="font-semibold text-neutral-800">Connecting to SharePoint Organic Lead Status Sheet...</span>
        <span className="text-xs text-neutral-400 mt-1">Initializing 1-minute secure background scheduler</span>
      </div>
    );
  }

  const isConnected = syncState?.status === 'CONNECTED' || syncState?.successfulParsing;
  const hasWarning = syncState?.status === 'AUTH_REQUIRED' || syncState?.status === 'ERROR';

  return (
    <div className="space-y-6">
      
      {/* Top Banner & Sync Controls */}
      <div className="bg-white border border-neutral-200 rounded-xl p-6 shadow-xs flex flex-col lg:flex-row lg:items-center justify-between gap-5">
        <div>
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl bg-[#530093]/10 text-[#530093] border border-[#530093]/20 shrink-0">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-xl font-bold text-neutral-950">Organic Lead Intelligence &amp; SharePoint Sync</h1>
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-[#530093]/10 text-[#530093] border border-[#530093]/20">
                  1-Min Scheduler
                </span>
              </div>
              <p className="text-xs text-neutral-500 mt-1 flex items-center gap-1.5 flex-wrap">
                <span>Direct SharePoint link:</span>
                <a
                  href="https://mfilteritd-my.sharepoint.com/:x:/g/personal/deepanshu_jaral_mfilterit_com/IQDwqrqjbOtZQq-s6bfyoE6xAUe1CTf3YaNrQ1Eyfkitjrw?rtime=Qpz7Qqwt30g"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-mono text-[#530093] hover:underline inline-flex items-center gap-1 font-semibold"
                >
                  <span>Leads Status 2025-26.xlsx</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
                <span className="text-neutral-300">|</span>
                <span>Secure Read-Only Access</span>
              </p>
            </div>
          </div>
        </div>

        {/* Sync Status Badge & Action Controls */}
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2.5 text-xs bg-neutral-50 px-3.5 py-2.5 rounded-xl border border-neutral-200">
            {isConnected ? (
              <span className="relative flex h-3 w-3 shrink-0">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-600"></span>
              </span>
            ) : (
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
            )}
            <div className="flex flex-col">
              <span className="font-bold text-neutral-900 flex items-center gap-2">
                <span>{isConnected ? 'Live Auto-Sync Active (Every 1m)' : 'Sync Alert: Authentication Required'}</span>
                {syncState?.dataSource && (
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    syncState.dataSource.includes('Live')
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                      : 'bg-amber-100 text-amber-800 border border-amber-300'
                  }`}>
                    {syncState.dataSource.includes('Live') ? 'LIVE' : 'CACHE'}
                  </span>
                )}
              </span>
              <span className="text-[11px] text-neutral-500 font-mono">
                Last Synced: {syncState?.lastSuccessfulSync ? new Date(syncState.lastSuccessfulSync).toLocaleTimeString() : 'N/A'}
              </span>
            </div>
          </div>

          {/* Sync Now Button */}
          <button
            onClick={() => fetchLeadData(true)}
            disabled={isSyncing}
            className="px-3.5 py-2 text-xs font-semibold bg-[#530093] hover:bg-[#430077] text-white rounded-lg shadow-xs flex items-center gap-2 cursor-pointer transition-colors disabled:opacity-50"
            title="Trigger immediate sync with SharePoint"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-[#ffcc29] ${isSyncing ? 'animate-spin' : ''}`} />
            <span>{isSyncing ? 'Syncing...' : 'Sync Now'}</span>
          </button>

          {/* Direct File Upload Bridge */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept=".xlsx,.xls,.csv"
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={isUploading}
            className="px-3.5 py-2 text-xs font-semibold bg-white border border-neutral-300 hover:bg-neutral-50 text-neutral-800 rounded-lg shadow-xs flex items-center gap-2 cursor-pointer transition-colors disabled:opacity-50"
            title="Upload downloaded Leads Status 2025-26.xlsx file for instant sync"
          >
            <Upload className={`w-3.5 h-3.5 text-[#530093] ${isUploading ? 'animate-spin' : ''}`} />
            <span>{isUploading ? 'Uploading...' : 'Upload Sheet'}</span>
          </button>

          </div>
        </div>

      {/* Permissions & Auth Instructions Drawer */}
      {(hasWarning || showConfigModal) && (
        <div className="bg-gradient-to-r from-purple-50 to-amber-50 border border-purple-200 rounded-xl p-5 shadow-xs space-y-4">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-lg bg-[#530093] text-white shrink-0 mt-0.5">
                <Key className="w-4 h-4 text-[#ffcc29]" />
              </div>
              <div className="space-y-1">
                <h2 className="text-sm font-bold text-neutral-900">
                  SharePoint Authentication &amp; Permissions Guide
                </h2>
                <p className="text-xs text-neutral-700">
                  {syncState?.error
                    ? syncState.error
                    : 'The SharePoint workbook link is hosted inside your internal Microsoft 365 organization tenant.'}
                </p>
              </div>
            </div>
            <button
              onClick={() => setShowConfigModal(false)}
              className="text-neutral-400 hover:text-neutral-600 text-xs font-semibold px-2 py-1"
            >
              Dismiss
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
            <div className="bg-white/80 backdrop-blur-xs p-4 rounded-lg border border-purple-100 space-y-2">
              <span className="inline-block px-2 py-0.5 text-[10px] font-bold bg-[#530093] text-white rounded">
                Option 1: Recommended (1-Click)
              </span>
              <h3 className="text-xs font-bold text-neutral-900">Change Link to "Anyone with the link"</h3>
              <p className="text-[11px] text-neutral-600 leading-relaxed">
                In SharePoint, open the sheet &gt; Click <strong>Share</strong> &gt; Link settings &gt; Select{' '}
                <strong>"Anyone with the link can view"</strong> (read-only). The 1-minute background scheduler will automatically download without login.
              </p>
            </div>

            <div className="bg-white/80 backdrop-blur-xs p-4 rounded-lg border border-purple-100 space-y-2">
              <span className="inline-block px-2 py-0.5 text-[10px] font-bold bg-amber-600 text-white rounded">
                Option 2: Immediate Local Drop
              </span>
              <h3 className="text-xs font-bold text-neutral-900">Upload "Leads Status 2025-26.xlsx"</h3>
              <p className="text-[11px] text-neutral-600 leading-relaxed">
                Click the <strong>Upload Sheet</strong> button above to load your latest local export. The system caches and parses all records immediately, preserving data across syncs.
              </p>
            </div>

            <div className="bg-white/80 backdrop-blur-xs p-4 rounded-lg border border-purple-100 space-y-2">
              <span className="inline-block px-2 py-0.5 text-[10px] font-bold bg-neutral-700 text-white rounded">
                Option 3: Enterprise Token / Cookie
              </span>
              <h3 className="text-xs font-bold text-neutral-900">Configure FedAuth or Bearer Token</h3>
              <p className="text-[11px] text-neutral-600 leading-relaxed">
                Enter your Microsoft 365 <code>FedAuth</code> session cookie or Graph API Bearer token in the form below to authenticate direct tenant calls.
              </p>
            </div>
          </div>

          {/* Credentials Input Form */}
          <form onSubmit={handleSaveConfig} className="bg-white p-4 rounded-lg border border-purple-100 space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-neutral-700 mb-1">
                  Azure Tenant ID
                </label>
                <input
                  type="text"
                  placeholder="e.g. 8fa2... or directory tenant id"
                  value={customTenantId}
                  onChange={e => setCustomTenantId(e.target.value)}
                  className="w-full text-xs font-mono px-3 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:border-[#530093]"
                />
              </div>
              <div>
                <label className="block text-[11px] font-bold text-neutral-700 mb-1">
                  Azure Client ID (App ID)
                </label>
                <input
                  type="text"
                  placeholder="e.g. 4b83... app registration id"
                  value={customClientId}
                  onChange={e => setCustomClientId(e.target.value)}
                  className="w-full text-xs font-mono px-3 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:border-[#530093]"
                />
              </div>
              <div>
                <label className="block text-[11px] font-bold text-neutral-700 mb-1">
                  Azure Client Secret
                </label>
                <input
                  type="password"
                  placeholder="Client secret value"
                  value={customClientSecret}
                  onChange={e => setCustomClientSecret(e.target.value)}
                  className="w-full text-xs font-mono px-3 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:border-[#530093]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
              <div>
                <label className="block text-[11px] font-bold text-neutral-700 mb-1">
                  SharePoint FedAuth Cookie (Optional)
                </label>
                <input
                  type="password"
                  placeholder="Paste FedAuth=... cookie string"
                  value={customCookie}
                  onChange={e => setCustomCookie(e.target.value)}
                  className="w-full text-xs font-mono px-3 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:border-[#530093]"
                />
              </div>
              <div>
                <label className="block text-[11px] font-bold text-neutral-700 mb-1">
                  Microsoft Graph Bearer Token (Optional)
                </label>
                <input
                  type="password"
                  placeholder="Paste Bearer eyJ..."
                  value={customToken}
                  onChange={e => setCustomToken(e.target.value)}
                  className="w-full text-xs font-mono px-3 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:border-[#530093]"
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-1">
              <span className="text-[11px] text-neutral-500">
                Credentials are stored safely in memory on your private backend runtime.
              </span>
              <div className="flex items-center gap-2">
                {configSuccessMsg && (
                  <span className="text-xs text-emerald-600 font-semibold">{configSuccessMsg}</span>
                )}
                <button
                  type="submit"
                  disabled={isSyncing}
                  className="px-4 py-2 bg-[#530093] hover:bg-[#430077] text-white text-xs font-semibold rounded-lg shadow-xs transition-colors cursor-pointer"
                >
                  Save &amp; Re-Sync
                </button>
              </div>
            </div>
          </form>
        </div>
      )}

      {/* Lead Data Quality & Provenance Banner */}
      <div className="bg-gradient-to-r from-purple-50 via-indigo-50/50 to-white border border-purple-200/80 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs shadow-2xs">
        <div className="flex items-start gap-3">
          <div className="p-2 rounded-lg bg-[#530093] text-white shrink-0 mt-0.5">
            <ShieldCheck className="w-4 h-4 text-[#ffcc29]" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-bold text-neutral-900">Verified Organic Lead Dataset:</span>
              <span className="font-semibold text-[#530093] bg-purple-100/70 px-2 py-0.5 rounded">
                {reliableCount} Reliable Commercial Leads
              </span>
              {testCount > 0 && (
                <span className="font-medium text-rose-700 bg-rose-100/80 px-2 py-0.5 rounded border border-rose-200 flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3 text-rose-600" />
                  <span>{testCount} Incomplete Test Row ({syncState?.leads.find(l => l.isTestOrIncomplete)?.company || 'SYNC TEST 2110'}) Excluded from Insights</span>
                </span>
              )}
            </div>
            <p className="text-[11px] text-neutral-600 mt-1">
              Field provenance is strictly tracked: Industry is inferred using Company and Requirements solution analysis; Lead Type is assigned only when supported by corporate scale or domain data; defaulted values like &ldquo;Organic Search&rdquo; and &ldquo;Enterprise&rdquo; are flagged and never treated as verified workbook columns.
            </p>
          </div>
        </div>
      </div>

      {/* Overview Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-neutral-200 rounded-xl p-5 space-y-1 shadow-xs">
          <span className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider">
            Reliable Organic Leads
          </span>
          <div className="text-3xl font-black text-[#530093]">{reliableCount}</div>
          <p className="text-[11px] text-neutral-500 flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            <span>{testCount > 0 ? `${testCount} test row excluded from insights` : '100% verified leads'}</span>
          </p>
        </div>

        <div className="bg-white border border-neutral-200 rounded-xl p-5 space-y-1 shadow-xs">
          <span className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider">
            Top Industry by Lead Volume
          </span>
          <div className="text-xl font-bold text-neutral-900 truncate">
            {Object.entries(syncState?.industryBreakdown || {}).sort((a, b) => b[1] - a[1])[0]?.[0] || 'AdTech & Digital Media'}
          </div>
          <p className="text-[11px] text-emerald-600 font-semibold">
            {Object.entries(syncState?.industryBreakdown || {}).sort((a, b) => b[1] - a[1])[0]?.[1] || 0} Reliable Leads Inferred
          </p>
        </div>

        <div className="bg-white border border-neutral-200 rounded-xl p-5 space-y-1 shadow-xs">
          <span className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider">
            Enterprise &amp; Mid-Market
          </span>
          <div className="text-3xl font-black text-amber-500">
            {reliableCount > 0
              ? Math.round((((syncState?.leadTypeBreakdown['Enterprise (Inferred)'] || 0) + (syncState?.leadTypeBreakdown['Corporate / Mid-Market (Inferred)'] || 0)) / reliableCount) * 100)
              : 0}
            %
          </div>
          <p className="text-[11px] text-neutral-500">Inferred from corporate domains</p>
        </div>

        <div className="bg-white border border-neutral-200 rounded-xl p-5 space-y-1 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider">
              Qualified Commercial Rate
            </span>
            <span className="text-[10px] font-mono font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
              {((syncState?.statusBreakdown['Qualified'] || 0) + (syncState?.statusBreakdown['Live'] || 0))} / {reliableCount}
            </span>
          </div>
          <div className="text-3xl font-black text-emerald-600">
            {reliableCount > 0
              ? Math.round(
                  (((syncState?.statusBreakdown['Qualified'] || 0) +
                    (syncState?.statusBreakdown['Live'] || 0)) /
                    reliableCount) *
                    100
                )
              : 25}
            %
          </div>
          <p className="text-[11px] text-neutral-500">
            {((syncState?.statusBreakdown['Qualified'] || 0) + (syncState?.statusBreakdown['Live'] || 0))} verified qualified &bull; 31 defaulted excluded
          </p>
        </div>
      </div>

      {/* 3-Column Breakdowns: Industry, Lead Type, Status */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* 1. Industry Breakdown */}
        <div className="bg-white border border-neutral-200 rounded-xl p-5 space-y-4 shadow-xs">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-bold text-neutral-800 uppercase tracking-wider flex items-center gap-2">
              <Building2 className="w-4 h-4 text-[#530093]" />
              <span>Lead Volume by Industry</span>
            </h2>
            <span className="text-[11px] font-bold text-[#530093]">
              {Object.keys(syncState?.industryBreakdown || {}).length} Sectors
            </span>
          </div>
          <div className="space-y-3">
            {Object.entries(syncState?.industryBreakdown || {})
              .sort((a, b) => b[1] - a[1])
              .map(([ind, count]) => {
                const total = reliableCount || 1;
                const pct = Math.round((count / total) * 100);
                return (
                  <div key={ind} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-neutral-800 truncate pr-2">{ind}</span>
                      <span className="font-mono text-neutral-600 shrink-0 font-medium">
                        {count} ({pct}%)
                      </span>
                    </div>
                    <div className="w-full bg-neutral-100 rounded-full h-2 overflow-hidden">
                      <div className="bg-[#530093] h-2 rounded-full transition-all duration-500" style={{ width: `${pct}%` }}></div>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>

        {/* 2. Lead Type Breakdown */}
        <div className="bg-white border border-neutral-200 rounded-xl p-5 space-y-4 shadow-xs">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xs font-bold text-neutral-800 uppercase tracking-wider flex items-center gap-2">
                <Users className="w-4 h-4 text-amber-500" />
                <span>Lead Type &amp; Segment</span>
              </h2>
              <span className="text-[10px] text-neutral-400 block mt-0.5">Assigned from domain scale, never defaulted</span>
            </div>
            <span className="text-[11px] font-bold text-neutral-500">Tier Distribution</span>
          </div>
          <div className="space-y-3">
            {Object.entries(syncState?.leadTypeBreakdown || {})
              .sort((a, b) => b[1] - a[1])
              .map(([type, count]) => {
                const total = reliableCount || 1;
                const pct = Math.round((count / total) * 100);
                return (
                  <div key={type} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-neutral-800">{type}</span>
                      <span className="font-mono text-neutral-600 font-medium">
                        {count} ({pct}%)
                      </span>
                    </div>
                    <div className="w-full bg-neutral-100 rounded-full h-2 overflow-hidden">
                      <div className="bg-amber-500 h-2 rounded-full transition-all duration-500" style={{ width: `${pct}%` }}></div>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>

        {/* 3. Status Breakdown */}
        <div className="bg-white border border-neutral-200 rounded-xl p-5 space-y-4 shadow-xs">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xs font-bold text-neutral-800 uppercase tracking-wider flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Lead Pipeline Status</span>
              </h2>
              <span className="text-[10px] text-neutral-400 block mt-0.5">Commercial qualification from sheet</span>
            </div>
            <span className="text-[11px] font-bold text-neutral-500">Conversion Stage</span>
          </div>
          <div className="space-y-3">
            {Object.entries(syncState?.statusBreakdown || {})
              .sort((a, b) => b[1] - a[1])
              .map(([status, count]) => {
                const total = reliableCount || 1;
                const pct = Math.round((count / total) * 100);
                return (
                  <div key={status} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-neutral-800">{status}</span>
                      <span className="font-mono text-neutral-600 font-medium">
                        {count} ({pct}%)
                      </span>
                    </div>
                    <div className="w-full bg-neutral-100 rounded-full h-2 overflow-hidden">
                      <div className="bg-emerald-600 h-2 rounded-full transition-all duration-500" style={{ width: `${pct}%` }}></div>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>

      </div>

      {/* Industry-Based Content Recommendations & Calendar Update */}
      <div className="bg-white border border-neutral-200 rounded-xl p-6 space-y-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-neutral-900 uppercase tracking-wider">
                Industry-Based Content Recommendations
              </h2>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#ffcc29] text-neutral-900">
                SEO Calendar Sync
              </span>
            </div>
            <p className="text-xs text-neutral-500 mt-1">
              Derived automatically from high-converting industries across your {reliableCount} verified organic leads. Incomplete test rows ({syncState?.leads.find(l => l.isTestOrIncomplete)?.company || 'SYNC TEST 2110'}) are excluded.
            </p>
          </div>

          {/* Sync All Recommendations Button */}
          <button
            onClick={handlePushAll}
            className="px-4 py-2 bg-[#530093] hover:bg-[#430077] text-white text-xs font-bold rounded-lg shadow-xs flex items-center gap-2 cursor-pointer transition-colors shrink-0"
          >
            <Calendar className="w-3.5 h-3.5 text-[#ffcc29]" />
            <span>Push All Recommendations to Calendar</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {syncState?.recommendations.map((rec, idx) => {
            const isPushed = pushedTopics.has(rec.recommendedTopic);
            return (
              <div
                key={idx}
                className="bg-neutral-50/80 hover:bg-neutral-50 border border-neutral-200 rounded-xl p-5 flex flex-col justify-between space-y-4 transition-all"
              >
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <span className="px-2.5 py-0.5 text-[10px] font-bold uppercase rounded-md bg-purple-100 text-[#530093] border border-purple-200">
                      {rec.industry}
                    </span>
                    <span className="text-xs font-mono text-neutral-600 font-semibold bg-white px-2 py-0.5 rounded border border-neutral-200">
                      {rec.leadCount} Organic Leads
                    </span>
                  </div>

                  <h3 className="text-sm font-bold text-neutral-900 leading-snug">
                    {rec.recommendedTopic}
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs pt-1">
                    <div className="bg-white p-2 rounded-lg border border-neutral-200">
                      <span className="text-[10px] font-bold text-neutral-400 block uppercase">Target Keyword</span>
                      <span className="font-mono text-[#530093] font-semibold truncate block">
                        {rec.keyword}
                      </span>
                    </div>

                    <div className="bg-white p-2 rounded-lg border border-neutral-200">
                      <span className="text-[10px] font-bold text-neutral-400 block uppercase">mFilterIt Solution</span>
                      <span className="text-neutral-800 font-medium truncate block">
                        {rec.solution}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 text-[11px] text-neutral-500">
                    <span>
                      Persona: <strong className="text-neutral-700">{rec.targetPersona || 'Marketing Head'}</strong>
                    </span>
                    <span>•</span>
                    <span>
                      Funnel: <strong className="text-neutral-700">{rec.funnel || 'BOFU'}</strong>
                    </span>
                    <span>•</span>
                    <span>
                      Intent: <strong className="text-neutral-700">{rec.intent || 'Commercial'}</strong>
                    </span>
                  </div>
                </div>

                <div className="pt-3 border-t border-neutral-200 flex items-center justify-between gap-3">
                  <span className="text-[11px] text-emerald-700 font-semibold">
                    Organic Lead Intent Alignment
                  </span>
                  <button
                    onClick={() => handlePushSingle(rec)}
                    disabled={isPushed}
                    className={`px-3 py-1.5 text-xs font-semibold rounded-lg flex items-center gap-1.5 cursor-pointer transition-colors ${
                      isPushed
                        ? 'bg-emerald-100 text-emerald-800 cursor-default'
                        : 'bg-[#ffcc29] hover:bg-[#ebd505] text-neutral-900 shadow-2xs'
                    }`}
                  >
                    <span>{isPushed ? 'Pushed to Calendar ✓' : 'Push to Calendar'}</span>
                    {!isPushed && <ArrowRight className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Deduplicated Real Leads Records Table */}
      <div className="bg-white border border-neutral-200 rounded-xl p-6 space-y-4 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-neutral-900 uppercase tracking-wider">
                Deduplicated Organic Lead Records
              </h2>
              <span className="text-xs font-mono font-bold text-neutral-500 bg-neutral-100 px-2 py-0.5 rounded">
                Showing {filteredLeads.length} of {leads.length}
              </span>
            </div>
            <p className="text-xs text-neutral-500 mt-0.5">
              Unique organic search leads synced from SharePoint with duplicate records filtered out.
            </p>
          </div>

          {/* Quality Tier Selector */}
          <div className="flex items-center gap-1.5 p-1 bg-neutral-100 rounded-lg shrink-0">
            <button
              onClick={() => setFilterQuality('RELIABLE')}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                filterQuality === 'RELIABLE'
                  ? 'bg-white text-[#530093] shadow-xs'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              Reliable Leads ({reliableCount})
            </button>
            <button
              onClick={() => setFilterQuality('ALL')}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                filterQuality === 'ALL'
                  ? 'bg-white text-[#530093] shadow-xs'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              All Records ({leads.length})
            </button>
            <button
              onClick={() => setFilterQuality('TEST_INCOMPLETE')}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                filterQuality === 'TEST_INCOMPLETE'
                  ? 'bg-rose-600 text-white shadow-xs'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              Incomplete / Test ({testCount})
            </button>
          </div>

          {/* Search & Filter Controls */}
          <div className="flex items-center gap-2 flex-wrap">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search company or lead..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="text-xs pl-8 pr-3 py-1.5 border border-neutral-300 rounded-lg focus:outline-none focus:border-[#530093] w-48"
              />
            </div>

            <select
              value={filterIndustry}
              onChange={e => setFilterIndustry(e.target.value)}
              className="text-xs px-2.5 py-1.5 border border-neutral-300 rounded-lg focus:outline-none focus:border-[#530093] bg-white"
            >
              <option value="ALL">All Industries ({industriesList.length})</option>
              {industriesList.map(ind => (
                <option key={ind} value={ind}>{ind}</option>
              ))}
            </select>

            <select
              value={filterStatus}
              onChange={e => setFilterStatus(e.target.value)}
              className="text-xs px-2.5 py-1.5 border border-neutral-300 rounded-lg focus:outline-none focus:border-[#530093] bg-white"
            >
              <option value="ALL">All Statuses</option>
              {statusesList.map(st => (
                <option key={st} value={st}>{st}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Table View */}
        <div className="overflow-x-auto border border-neutral-200 rounded-lg">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-50 text-neutral-500 font-semibold border-b border-neutral-200 uppercase text-[10px] tracking-wider">
              <tr>
                <th className="px-4 py-3">Company / Client</th>
                <th className="px-4 py-3">Industry / Sector</th>
                <th className="px-4 py-3">Lead Type</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Source</th>
                <th className="px-4 py-3">Requirements / Solution</th>
                <th className="px-4 py-3">Region</th>
                <th className="px-4 py-3">Data Quality</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100 font-sans">
              {filteredLeads.map(lead => (
                <tr key={lead.id} className={`hover:bg-neutral-50/80 transition-colors ${lead.isTestOrIncomplete ? 'bg-rose-50/40' : ''}`}>
                  <td className="px-4 py-3">
                    <div className="font-bold text-neutral-900 flex items-center gap-2">
                      <span>{lead.company}</span>
                      {lead.isTestOrIncomplete && (
                        <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
                          Incomplete Test Row
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex flex-col gap-0.5">
                      <span className="font-semibold text-neutral-800">{lead.industry}</span>
                      <span className={`text-[9px] font-bold uppercase tracking-wider w-fit px-1.5 py-0.2 rounded ${
                        lead.industryProvenance === 'ACTUAL'
                          ? 'bg-emerald-100 text-emerald-800'
                          : lead.industryProvenance === 'INFERRED'
                          ? 'bg-purple-100/70 text-purple-700'
                          : 'bg-neutral-100 text-neutral-500'
                      }`}>
                        {lead.industryProvenance === 'INFERRED' ? 'Inferred from Req' : lead.industryProvenance === 'ACTUAL' ? 'Sheet Column' : 'Default'}
                      </span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex flex-col gap-0.5">
                      <span className={`text-xs ${lead.leadType === 'Unspecified' ? 'text-neutral-400 italic' : 'text-neutral-800 font-medium'}`}>
                        {lead.leadType}
                      </span>
                      {lead.leadType !== 'Unspecified' && (
                        <span className={`text-[9px] font-bold uppercase tracking-wider w-fit px-1.5 py-0.2 rounded ${
                          lead.leadTypeProvenance === 'ACTUAL'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-sky-100 text-sky-800'
                        }`}>
                          {lead.leadTypeProvenance === 'ACTUAL' ? 'Sheet Column' : 'Inferred Domain'}
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex flex-col gap-0.5">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold w-fit ${
                          lead.statusProvenance === 'DEFAULTED'
                            ? 'bg-neutral-100 text-neutral-600 border border-dashed border-neutral-300'
                            : lead.status === 'Closed-Won' || lead.status === 'Live' || lead.status.toLowerCase().startsWith('live')
                            ? 'bg-emerald-100 text-emerald-800'
                            : lead.status === 'Demo Scheduled'
                            ? 'bg-blue-100 text-blue-800'
                            : lead.status.toLowerCase().includes('qualified')
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-neutral-100 text-neutral-700'
                        }`}
                      >
                        {lead.status}
                      </span>
                      <span className={`text-[9px] font-mono ${lead.statusProvenance === 'ACTUAL' ? 'text-emerald-700 font-semibold' : 'text-neutral-400'}`}>
                        {lead.statusProvenance === 'ACTUAL' ? 'Actual Sheet' : 'Defaulted (Excluded from Rate)'}
                      </span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex flex-col gap-0.5">
                      <span className="text-neutral-700 font-mono text-[11px]">{lead.source}</span>
                      <span className={`text-[9px] font-bold uppercase tracking-wider w-fit px-1.5 py-0.2 rounded ${
                        lead.sourceProvenance === 'ACTUAL'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}>
                        {lead.sourceProvenance === 'ACTUAL' ? 'Actual Sheet' : 'Defaulted'}
                      </span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="max-w-[240px] truncate" title={lead.rawRequirements || lead.solution}>
                      <span className="text-neutral-800">{lead.rawRequirements || lead.solution || 'Ad Fraud Detection'}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 font-semibold text-neutral-500 text-[10px]">{lead.region || 'INDIA'}</td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold whitespace-nowrap ${
                      lead.qualityTier === 'INCOMPLETE_TEST'
                        ? 'bg-rose-100 text-rose-800 border border-rose-200'
                        : lead.qualityTier === 'VERIFIED'
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                        : 'bg-amber-50 text-amber-800 border border-amber-200'
                    }`}>
                      {lead.qualityTier === 'INCOMPLETE_TEST' ? 'Excluded Test' : lead.qualityTier === 'VERIFIED' ? 'Verified Lead' : 'Partial Lead'}
                    </span>
                  </td>
                </tr>
              ))}
              {filteredLeads.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-4 py-8 text-center text-neutral-400">
                    No lead records match your search query or filter criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
