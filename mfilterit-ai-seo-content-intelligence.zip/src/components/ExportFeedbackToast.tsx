import React, { useEffect } from 'react';
import { CheckCircle2, AlertTriangle, X, Download, FileSpreadsheet } from 'lucide-react';
import { ContentTypeFilter } from '../types/seo';

export interface ToastData {
  id: string;
  type: 'success' | 'warning' | 'info';
  tab: ContentTypeFilter;
  monthLabel: string;
  rowCount: number;
  filename?: string;
  message: string;
  title?: string;
}

interface ExportFeedbackToastProps {
  toast: ToastData | null;
  onClose: () => void;
}

export const ExportFeedbackToast: React.FC<ExportFeedbackToastProps> = ({ toast, onClose }) => {
  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => {
      onClose();
    }, 6000);
    return () => clearTimeout(timer);
  }, [toast, onClose]);

  if (!toast) return null;

  const isSuccess = toast.type === 'success';

  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed bottom-6 right-6 z-50 max-w-md w-full bg-white border border-neutral-200 rounded-xl shadow-2xl p-4 transition-all duration-300 transform translate-y-0 opacity-100 animate-in fade-in slide-in-from-bottom-5"
    >
      <div className="flex items-start gap-3">
        {/* Status Icon */}
        <div
          className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${
            isSuccess
              ? 'bg-[#530093] text-[#FFCC29]'
              : 'bg-[#FFCC29]/20 text-[#530093] border border-[#FFCC29]'
          }`}
        >
          {isSuccess ? (
            <CheckCircle2 className="w-5 h-5 text-[#FFCC29]" />
          ) : (
            <AlertTriangle className="w-5 h-5 text-[#530093]" />
          )}
        </div>

        {/* Content Body */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2">
            <h4 className="text-sm font-bold text-neutral-900 flex items-center gap-1.5">
              <span>{toast.title || (isSuccess ? 'Excel Export Successful' : 'Notice')}</span>
            </h4>
            <button
              onClick={onClose}
              className="text-neutral-400 hover:text-neutral-700 p-0.5 rounded transition-colors"
              aria-label="Close notification"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Primary Message */}
          <p className="text-xs text-neutral-700 mt-1 font-medium leading-relaxed">
            {toast.message}
          </p>

          {/* Export Metadata Badges */}
          <div className="flex flex-wrap items-center gap-1.5 mt-2.5">
            {/* Tab Badge */}
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold bg-[#530093]/10 text-[#530093]">
              <span className="text-neutral-500 font-normal">Tab:</span>
              <span>{toast.tab}</span>
            </span>

            {/* Month Badge */}
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold bg-neutral-100 text-neutral-800 border border-neutral-200">
              <span className="text-neutral-500 font-normal">Month:</span>
              <span>{toast.monthLabel}</span>
            </span>

            {/* Records Count Badge */}
            <span
              className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold ${
                isSuccess
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                  : 'bg-amber-50 text-amber-800 border border-amber-200'
              }`}
            >
              <span>{toast.rowCount} {toast.rowCount === 1 ? 'record' : 'records'}</span>
            </span>
          </div>

          {/* Downloaded Filename Preview */}
          {toast.filename && (
            <div className="mt-2.5 pt-2 border-t border-neutral-150 flex items-center gap-1.5 text-[11px] text-neutral-600 font-mono truncate bg-neutral-50 px-2 py-1 rounded">
              <FileSpreadsheet className="w-3.5 h-3.5 text-[#530093] shrink-0" />
              <span className="truncate">{toast.filename}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
