import React, { useState } from 'react';
import { Download, Calendar, Plus, Sparkles, Globe, Search } from 'lucide-react';
import { MonthlyData, ContentTypeFilter } from '../types/seo';

export type AppViewMode = 'calendar' | 'sources' | 'clusters' | 'seasonality' | 'competitor-gap' | 'keyword-gap' | 'lead-intelligence';

interface HeaderProps {
  currentMonthKey: string;
  availableMonths: { key: string; label: string }[];
  onSelectMonth: (monthKey: string) => void;
  monthlyData: MonthlyData;
  activeContentType: ContentTypeFilter;
  currentView: AppViewMode;
  onSelectView: (view: AppViewMode) => void;
  onOpenAddModal: () => void;
  onOpenDataModal: () => void;
  onGenerateNextMonth: () => void;
  onExportCalendar: (targetType?: ContentTypeFilter) => void;
  onOpenGoogleSerp: (keyword: string, region?: 'INDIA' | 'USA' | 'MENA' | 'GLOBAL') => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentMonthKey,
  availableMonths,
  onSelectMonth,
  monthlyData,
  activeContentType,
  onOpenAddModal,
  onGenerateNextMonth,
  onExportCalendar,
  onOpenGoogleSerp,
}) => {
  const [headerSearchKw, setHeaderSearchKw] = useState('');
  const [searchRegion, setSearchRegion] = useState<'INDIA' | 'USA' | 'MENA' | 'GLOBAL'>('INDIA');

  const handleExport = () => {
    onExportCalendar(activeContentType);
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (headerSearchKw.trim()) {
      onOpenGoogleSerp(headerSearchKw.trim(), searchRegion);
    }
  };

  return (
    <header className="bg-white border-b border-neutral-200 sticky top-0 z-30 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Header Row */}
        <div className="py-3 flex items-center justify-between gap-4 flex-wrap">
          <div className="text-xs font-semibold text-neutral-600">
            SEO Content Intelligence Dashboard
          </div>

          {/* Primary Actions & Controls */}
          <div className="flex items-center flex-wrap gap-2.5">
            
            {/* Live Google SERP Search Bar with Region Selector */}
            <form onSubmit={handleSearchSubmit} className="relative flex items-center gap-1">
              <div className="flex items-center bg-neutral-100 hover:bg-white focus-within:bg-white border border-neutral-300 rounded-lg px-2 py-1 transition-all">
                <Globe className="w-3.5 h-3.5 text-[#530093] mr-1 shrink-0" />
                <label htmlFor="header-region-select" className="sr-only">Select Region</label>
                <select
                  id="header-region-select"
                  value={searchRegion}
                  onChange={(e) => setSearchRegion(e.target.value as 'INDIA' | 'USA' | 'MENA' | 'GLOBAL')}
                  className="bg-transparent text-[11px] font-bold text-neutral-800 focus:outline-none cursor-pointer pr-1"
                >
                  <option value="INDIA">🇮🇳 India</option>
                  <option value="USA">🇺🇸 USA</option>
                  <option value="MENA">🇦🇪 MENA</option>
                  <option value="GLOBAL">🌐 Global</option>
                </select>
              </div>

              <div className="relative flex items-center">
                <Search className="w-3.5 h-3.5 text-[#530093] absolute left-2.5 pointer-events-none" />
                <input
                  type="text"
                  value={headerSearchKw}
                  onChange={(e) => setHeaderSearchKw(e.target.value)}
                  placeholder="Search Google SERP..."
                  className="pl-8 pr-16 py-1.5 text-xs font-medium bg-neutral-100 hover:bg-white focus:bg-white border border-neutral-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#530093] transition-all w-36 sm:w-48"
                />
                <button
                  type="submit"
                  disabled={!headerSearchKw.trim()}
                  className="absolute right-1 px-2 py-0.5 text-[10px] font-bold text-neutral-900 bg-[#FFCC29] hover:bg-[#ebd505] rounded transition-colors disabled:opacity-40 cursor-pointer flex items-center gap-1"
                  title="Search live Google SERP results & top 3 blogs"
                >
                  <span>Search</span>
                </button>
              </div>
            </form>

            {/* Month Selector (always active to anchor calendar) */}
            <div className="flex items-center bg-neutral-100 rounded-lg p-1 border border-neutral-200">
              <Calendar className="w-4 h-4 text-neutral-500 ml-2 mr-1.5 shrink-0" />
              <label htmlFor="month-selector" className="sr-only">Select Month</label>
              <select
                id="month-selector"
                value={currentMonthKey}
                onChange={(e) => onSelectMonth(e.target.value)}
                className="bg-transparent text-sm font-semibold text-neutral-800 pr-3 py-1 focus:outline-none cursor-pointer"
              >
                {availableMonths.map((m) => (
                  <option key={m.key} value={m.key}>
                    {m.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Generate Next Month button */}
            <button
              onClick={onGenerateNextMonth}
              title="Generate new future month while strictly preserving historical records"
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-[#530093] bg-[#530093]/10 hover:bg-[#530093]/20 rounded-lg transition-colors cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#530093]" />
              <span>+ Plan Next Month</span>
            </button>

            {/* Add Opportunity button */}
            <button
              onClick={onOpenAddModal}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-neutral-900 bg-[#FFCC29] hover:bg-[#ebd505] rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Topic</span>
            </button>

            {/* Export Excel button */}
            <button
              onClick={handleExport}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-white bg-[#530093] hover:bg-[#430077] rounded-lg shadow-xs transition-colors cursor-pointer"
              title={`Export ${activeContentType} entries for ${monthlyData.monthLabel} to Excel (.xlsx)`}
            >
              <Download className="w-3.5 h-3.5 text-[#FFCC29]" />
              <span>Export Excel</span>
              <span className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] font-bold rounded bg-white/20 text-[#FFCC29]">
                {activeContentType === 'All Content' ? 'All' : activeContentType}
              </span>
            </button>

          </div>
        </div>

      </div>
    </header>
  );
};
