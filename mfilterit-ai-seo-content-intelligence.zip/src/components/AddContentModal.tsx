import React, { useState } from 'react';
import { X, Plus, AlertTriangle, Globe, Sparkles, Loader2, CheckCircle2 } from 'lucide-react';
import {
  ContentItem,
  ContentType,
  FunnelStage,
  ContentAction,
  Region,
  Priority,
  PotentialLevel,
  ContentStatus,
  mFilterItSolution,
  IcpPersona
} from '../types/seo';
import {
  mFilterItSolutions,
  ICP_PERSONAS,
  CONTENT_TYPES,
  REGIONS
} from '../data/solutionsAndPersonas';

interface AddContentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (item: ContentItem) => void;
  defaultDate: string;
}

export const AddContentModal: React.FC<AddContentModalProps> = ({
  isOpen,
  onClose,
  onAdd,
  defaultDate,
}) => {
  const [topic, setTopic] = useState('');
  const [contentType, setContentType] = useState<ContentType>('Website Blog');
  const [focusKeyword, setFocusKeyword] = useState('');
  const [secondaryKeywords, setSecondaryKeywords] = useState('');
  const [tertiaryKeywords, setTertiaryKeywords] = useState('');
  const [competitorReferenceLinks, setCompetitorReferenceLinks] = useState('');
  const [searchIntent, setSearchIntent] = useState<'Informational' | 'Commercial Investigation' | 'Transactional' | 'Navigational'>('Commercial Investigation');
  const [funnelStage, setFunnelStage] = useState<FunnelStage>('BOFU');
  const [region, setRegion] = useState<Region>('INDIA');
  const [icpPersona, setIcpPersona] = useState<IcpPersona>('Performance Marketing Head');
  const [productMapping, setProductMapping] = useState<mFilterItSolution>('Ad Fraud Detection');
  const [contentAction, setContentAction] = useState<ContentAction>('NEW');
  const [priority, setPriority] = useState<Priority>('High');
  const [leadPotential, setLeadPotential] = useState<PotentialLevel>('High');
  const [conversionPotential, setConversionPotential] = useState<PotentialLevel>('High');
  const [leadRationale, setLeadRationale] = useState('');
  const [recommendedCta, setRecommendedCta] = useState('');
  const [referenceLink, setReferenceLink] = useState('');
  const [status, setStatus] = useState<ContentStatus>('Planned');
  const [date, setDate] = useState(defaultDate);

  // Live Grounded SERP Analysis State
  const [isAnalyzingSerp, setIsAnalyzingSerp] = useState(false);
  const [serpFeedback, setSerpFeedback] = useState<string | null>(null);

  const handleGenerateDiagnosticTitle = () => {
    const kw = focusKeyword.trim() || 'Ad Fraud Detection';
    if (productMapping.includes('Affiliate') || kw.toLowerCase().includes('affiliate') || kw.toLowerCase().includes('bidding')) {
      setTopic(`Affiliate Growth vs Brand Infringement: 5 Signs Rogue Partners Are Cannibalizing Paid Search`);
      setRecommendedCta('Request Free Affiliate Traffic & Brand Bidding Poaching Audit');
    } else if (productMapping.includes('Digital Shelf') || kw.toLowerCase().includes('buy box') || kw.toLowerCase().includes('map')) {
      setTopic(`Amazon & Flipkart Buy Box Defense: 4 Early Warning Signals of Price Scraping & MAP Undercutting`);
      setRecommendedCta('Request Digital Shelf & Buy Box Health Check');
    } else if (productMapping.includes('Brand Protection') || kw.toLowerCase().includes('infringement') || kw.toLowerCase().includes('counterfeit')) {
      setTopic(`Brand Infringement in Retail & Banking: How Counterfeits Target Your Customers and How to Protect Them`);
      setRecommendedCta('Run a Complimentary Brand Infringement & Counterfeit Scan');
    } else if (productMapping.includes('Brand Safety')) {
      setTopic(`Brand Safety Floors vs Brand Suitability Frameworks: Applying GARM Standards in Programmatic Media`);
      setRecommendedCta('Schedule Contextual Brand Safety & Suitability Audit');
    } else if (productMapping.includes('Creative Compliance')) {
      setTopic(`Automating Ad Creative Compliance Trails: Meeting ASCI & BFSI Disclosure Mandates`);
      setRecommendedCta('Schedule Automated Ad Creative Compliance Demo');
    } else {
      setTopic(`Are You Paying for Clicks, or Paying for Users? Why App Install Fraud & IVT Begin Before the Install`);
      setRecommendedCta('Request Free Enterprise Ad Fraud & IVT Audit with mFilterIt');
    }
  };

  if (!isOpen) return null;

  const handleAnalyzeSerp = async () => {
    if (!focusKeyword.trim()) return;
    setIsAnalyzingSerp(true);
    setSerpFeedback(null);

    try {
      const res = await fetch('/api/search-serp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ keyword: focusKeyword.trim(), region }),
      });

      if (res.ok) {
        const data = await res.json();
        
        // Populate competitor URLs directly from grounded SERP results
        if (data.serpResults && data.serpResults.length > 0) {
          const urls = data.serpResults.slice(0, 3).map((r: any) => r.url).filter(Boolean);
          if (urls.length > 0) {
            setCompetitorReferenceLinks(urls.join(' | '));
          }
        }

        // Auto-detect Search Intent
        if (data.searchIntent) {
          if (data.searchIntent.toLowerCase().includes('informational')) {
            setSearchIntent('Informational');
            setFunnelStage('TOFU');
          } else if (data.searchIntent.toLowerCase().includes('transactional')) {
            setSearchIntent('Transactional');
            setFunnelStage('BOFU');
          } else {
            setSearchIntent('Commercial Investigation');
            setFunnelStage('BOFU');
          }
        }

        // Determine content action (NEW vs REVAMP vs EXPAND vs SUPPORT vs MERGE) based on mFilterIt presence & SERP gap
        const ranksInSerp = data.serpResults?.some((r: any) => r.domain?.includes('mfilterit'));
        if (ranksInSerp) {
          setContentAction('REVAMP');
          setLeadRationale(`Grounded SERP Analysis: mFilterIt already ranks on page 1 for "${focusKeyword}". Action set to REVAMP to refresh statistics and capture top 3 positions.`);
        } else if (data.topBlogs && data.topBlogs.length >= 3) {
          setContentAction('EXPAND');
          setLeadRationale(`Grounded SERP Analysis: Top competitors (${data.topBlogs.map((b: any) => b.domain).slice(0, 2).join(', ')}) have extensive guide coverage. Action set to EXPAND to build a broader definitive framework.`);
        } else {
          setContentAction('NEW');
          setLeadRationale(`Grounded SERP Analysis: Significant content gap detected on Google for "${focusKeyword}" in ${region}. Action set to NEW.`);
        }

        setSerpFeedback(`Grounded Google Search analysis complete for "${data.keyword}". Extracted ${data.serpResults?.length || 0} competitor URLs.`);
      }
    } catch (err) {
      setSerpFeedback('Unable to query Google SERP API. Please manually fill the fields.');
    } finally {
      setIsAnalyzingSerp(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim() || !focusKeyword.trim()) return;

    const newItem: ContentItem = {
      id: `custom-${Date.now()}`,
      date: date || defaultDate,
      contentType,
      topic: topic.trim(),
      primaryKeyword: focusKeyword.trim(),
      focusKeyword: focusKeyword.trim(),
      secondaryKeywords: secondaryKeywords
        ? secondaryKeywords.split(',').map((s) => s.trim()).filter(Boolean)
        : undefined,
      tertiaryKeywords: tertiaryKeywords
        ? tertiaryKeywords.split(',').map((s) => s.trim()).filter(Boolean)
        : undefined,
      competitorReferenceLinks: competitorReferenceLinks
        ? competitorReferenceLinks.split(/[|\n,]/).map((s) => s.trim()).filter(Boolean)
        : undefined,
      searchIntent,
      funnelStage,
      region,
      icpPersona,
      productMapping,
      contentAction,
      priority,
      leadPotential,
      conversionPotential,
      leadRationale: leadRationale.trim() || 'Identified opportunity aligned with solution intent.',
      recommendedCta: recommendedCta.trim() || 'Request Free Enterprise Audit',
      referenceLink: referenceLink.trim() || undefined,
      status,
    };

    onAdd(newItem);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full p-6 space-y-4 border border-neutral-200 my-8">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded bg-[#530093] flex items-center justify-center text-white font-bold text-xs">
              mF
            </div>
            <h2 className="text-base font-bold text-neutral-900">
              Add Monthly Content Opportunity
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-neutral-700 p-1 rounded cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          
          {/* Topic / Proposed Title */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="font-semibold text-neutral-700">
                Topic / Proposed Title *
              </label>
              <button
                type="button"
                onClick={handleGenerateDiagnosticTitle}
                className="text-[11px] font-bold text-[#530093] hover:text-[#430077] flex items-center gap-1 cursor-pointer bg-purple-50 hover:bg-purple-100 px-2 py-0.5 rounded border border-purple-200"
                title="Generate an authentic diagnostic title according to mFilterIt Editorial Style Guide"
              >
                <Sparkles className="w-3 h-3 text-[#530093]" />
                <span>Apply mFilterIt Editorial Formula</span>
              </button>
            </div>
            <input
              type="text"
              required
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g., Click Injection vs Click Spamming: Root Cause Analysis for Media Buyers"
              className="w-full px-3 py-2 border border-neutral-300 rounded-md focus:border-[#530093] focus:outline-none"
            />
          </div>

          {/* Row 1: Content Type & Date & Region */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="font-semibold text-neutral-700 block mb-1">
                Content Type *
              </label>
              <select
                value={contentType}
                onChange={(e) => setContentType(e.target.value as ContentType)}
                className="w-full px-3 py-2 border border-neutral-300 rounded-md focus:border-[#530093] focus:outline-none"
              >
                {CONTENT_TYPES.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="font-semibold text-neutral-700 block mb-1">
                Scheduled Date *
              </label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2 border border-neutral-300 rounded-md focus:border-[#530093] focus:outline-none"
              />
            </div>

            <div>
              <label className="font-semibold text-neutral-700 block mb-1">
                Target Region *
              </label>
              <select
                value={region}
                onChange={(e) => setRegion(e.target.value as Region)}
                className="w-full px-3 py-2 border border-neutral-300 rounded-md focus:border-[#530093] focus:outline-none"
              >
                {REGIONS.map((r) => (
                  <option key={r} value={r}>
                    {r}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Row 2: Focus / Primary Keyword & Secondary Keywords */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="font-semibold text-neutral-700 block">
                  Primary / Focus Keyword *
                </label>
                <button
                  type="button"
                  onClick={handleAnalyzeSerp}
                  disabled={!focusKeyword.trim() || isAnalyzingSerp}
                  className="inline-flex items-center gap-1 text-[11px] font-bold text-[#530093] hover:text-[#3a0068] disabled:opacity-40 cursor-pointer"
                >
                  {isAnalyzingSerp ? (
                    <>
                      <Loader2 className="w-3 h-3 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-3 h-3 text-[#FFCC29]" />
                      Analyze Grounded SERP
                    </>
                  )}
                </button>
              </div>
              <input
                type="text"
                required
                value={focusKeyword}
                onChange={(e) => setFocusKeyword(e.target.value)}
                placeholder="e.g., brand bidding affiliate fraud"
                className="w-full px-3 py-2 border border-neutral-300 rounded-md focus:border-[#530093] focus:outline-none font-mono text-xs"
              />
            </div>

            <div>
              <label className="font-semibold text-neutral-700 block mb-1">
                Secondary Keywords (comma separated)
              </label>
              <input
                type="text"
                value={secondaryKeywords}
                onChange={(e) => setSecondaryKeywords(e.target.value)}
                placeholder="e.g., stop affiliate ad hijacking, brand search protection"
                className="w-full px-3 py-2 border border-neutral-300 rounded-md focus:border-[#530093] focus:outline-none text-xs"
              />
            </div>
          </div>

          {serpFeedback && (
            <div className="p-2.5 bg-purple-50 border border-purple-200 rounded-md text-[11.5px] text-purple-900 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{serpFeedback}</span>
            </div>
          )}

          {/* Row 2B: Tertiary Keywords & Competitor Reference Links */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-neutral-700 block mb-1">
                Tertiary Keywords (long-tail variations, comma separated)
              </label>
              <input
                type="text"
                value={tertiaryKeywords}
                onChange={(e) => setTertiaryKeywords(e.target.value)}
                placeholder="e.g., google ads brand keyword poaching, affiliate cpc arbitrage"
                className="w-full px-3 py-2 border border-neutral-300 rounded-md focus:border-[#530093] focus:outline-none text-xs"
              />
            </div>

            <div>
              <label className="font-semibold text-neutral-700 block mb-1">
                Competitor Reference Links (URLs separated by pipe | or comma)
              </label>
              <input
                type="text"
                value={competitorReferenceLinks}
                onChange={(e) => setCompetitorReferenceLinks(e.target.value)}
                placeholder="e.g., https://impact.com/brand-protection | https://cheq.ai/affiliate-fraud"
                className="w-full px-3 py-2 border border-neutral-300 rounded-md focus:border-[#530093] focus:outline-none font-mono text-xs"
              />
            </div>
          </div>

          {/* Row 3: Solution & Persona */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-neutral-700 block mb-1">
                mFilterIt Solution Mapping *
              </label>
              <select
                value={productMapping}
                onChange={(e) => setProductMapping(e.target.value as mFilterItSolution)}
                className="w-full px-3 py-2 border border-neutral-300 rounded-md focus:border-[#530093] focus:outline-none"
              >
                {mFilterItSolutions.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="font-semibold text-neutral-700 block mb-1">
                ICP / Target Persona *
              </label>
              <select
                value={icpPersona}
                onChange={(e) => setIcpPersona(e.target.value as IcpPersona)}
                className="w-full px-3 py-2 border border-neutral-300 rounded-md focus:border-[#530093] focus:outline-none"
              >
                {ICP_PERSONAS.map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Row 4: Action, Funnel, Priority, Status */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <label className="font-semibold text-neutral-700 block mb-1">
                Content Action *
              </label>
              <select
                value={contentAction}
                onChange={(e) => setContentAction(e.target.value as ContentAction)}
                className="w-full px-2.5 py-2 border border-neutral-300 rounded-md focus:border-[#530093] focus:outline-none"
              >
                <option value="NEW">NEW</option>
                <option value="REVAMP">REVAMP</option>
                <option value="EXPAND">EXPAND</option>
                <option value="MERGE">MERGE</option>
                <option value="SUPPORTING">SUPPORTING</option>
              </select>
            </div>

            <div>
              <label className="font-semibold text-neutral-700 block mb-1">
                Funnel Stage *
              </label>
              <select
                value={funnelStage}
                onChange={(e) => setFunnelStage(e.target.value as FunnelStage)}
                className="w-full px-2.5 py-2 border border-neutral-300 rounded-md focus:border-[#530093] focus:outline-none"
              >
                <option value="BOFU">BOFU (Bottom)</option>
                <option value="MOFU">MOFU (Middle)</option>
                <option value="TOFU">TOFU (Top)</option>
              </select>
            </div>

            <div>
              <label className="font-semibold text-neutral-700 block mb-1">
                Lead Potential *
              </label>
              <select
                value={leadPotential}
                onChange={(e) => setLeadPotential(e.target.value as PotentialLevel)}
                className="w-full px-2.5 py-2 border border-neutral-300 rounded-md focus:border-[#530093] focus:outline-none"
              >
                <option value="High">High</option>
                <option value="Medium">Medium</option>
                <option value="Low">Low</option>
              </select>
            </div>

            <div>
              <label className="font-semibold text-neutral-700 block mb-1">
                Priority *
              </label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as Priority)}
                className="w-full px-2.5 py-2 border border-neutral-300 rounded-md focus:border-[#530093] focus:outline-none"
              >
                <option value="High">High</option>
                <option value="Medium">Medium</option>
                <option value="Low">Low</option>
              </select>
            </div>
          </div>

          {/* Row 5: CTA & Reference Link */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-neutral-700 block mb-1">
                Recommended CTA
              </label>
              <input
                type="text"
                value={recommendedCta}
                onChange={(e) => setRecommendedCta(e.target.value)}
                placeholder="e.g., Run Free Ad Fraud Audit"
                className="w-full px-3 py-2 border border-neutral-300 rounded-md focus:border-[#530093] focus:outline-none"
              />
            </div>

            <div>
              <label className="font-semibold text-neutral-700 block mb-1">
                Existing / Reference URL
              </label>
              <input
                type="text"
                value={referenceLink}
                onChange={(e) => setReferenceLink(e.target.value)}
                placeholder="https://www.mfilterit.com/..."
                className="w-full px-3 py-2 border border-neutral-300 rounded-md focus:border-[#530093] focus:outline-none font-mono"
              />
            </div>
          </div>

          {/* Lead Potential Rationale */}
          <div>
            <label className="font-semibold text-neutral-700 block mb-1">
              Lead Potential Rationale
            </label>
            <textarea
              rows={2}
              value={leadRationale}
              onChange={(e) => setLeadRationale(e.target.value)}
              placeholder="Why this topic will drive qualified leads (commercial intent, pain severity, decision-maker appeal)..."
              className="w-full px-3 py-2 border border-neutral-300 rounded-md focus:border-[#530093] focus:outline-none"
            />
          </div>

          {/* Buttons */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-neutral-700 hover:bg-neutral-100 rounded-md cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-bold text-neutral-900 bg-[#FFCC29] hover:bg-[#ebd505] rounded-md shadow-xs transition-colors cursor-pointer"
            >
              Add to Calendar
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
