const fs = require('fs');

async function testOfficeApps() {
  const html = fs.readFileSync('doc.html', 'utf-8');

  const match = html.match(/var\s+_wopiContextJson\s*=\s*(\{.+?\})\s*;\s*var\s+/);
  const wopiContext = JSON.parse(match[1]);
  const tokenMatch = html.match(/AccessToken:\s*'([^']+)'/);
  const tokenTtlMatch = html.match(/AccessTokenExpiry:\s*([0-9]+)/);

  const accessToken = tokenMatch[1];
  const webAppUrl = wopiContext.WebAppUrl;

  console.log('Posting to WebAppUrl:', webAppUrl);
  // Office Online viewer accepts POST with access_token and access_token_ttl
  const params = new URLSearchParams();
  params.append('access_token', accessToken);
  params.append('access_token_ttl', tokenTtlMatch ? tokenTtlMatch[1] : '1791176594950');

  const res = await fetch(webAppUrl, {
    method: 'POST',
    body: params,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Content-Type': 'application/x-www-form-urlencoded'
    }
  });

  console.log('OfficeApps POST status:', res.status, res.statusText);
  const text = await res.text();
  console.log('OfficeApps response length:', text.length);
  fs.writeFileSync('officeapps.html', text);
  console.log('Saved to officeapps.html');

  // Search for sheet names or data in officeapps.html
  const sheets = text.match(/India|USA|MENA|Rankings|Sheet/gi);
  console.log('Matches for keywords in OfficeApps HTML:', sheets ? sheets.slice(0, 20) : 'none');
}

testOfficeApps().catch(console.error);
