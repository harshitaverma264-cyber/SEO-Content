const XLSX = require('xlsx');
const wb = XLSX.readFile('/tmp/downloaded_sheet.xlsx');

for (const name of wb.SheetNames) {
  const ws = wb.Sheets[name];
  const rows = XLSX.utils.sheet_to_json(ws, { header: 1 });
  console.log(`\n=================== ALL ROWS FOR SHEET: ${name} ===================`);
  
  // Find date columns
  // Look for header row that has date strings like '2026'
  let headerRow = null;
  let headerIdx = -1;
  for (let i = 0; i < Math.min(10, rows.length); i++) {
    if (rows[i] && rows[i].some(cell => String(cell).includes('2026'))) {
      headerRow = rows[i];
      headerIdx = i;
      break;
    }
  }
  
  console.log('Header row index:', headerIdx);
  if (headerRow) {
    const dateCols = [];
    headerRow.forEach((col, idx) => {
      if (String(col).includes('2026')) {
        dateCols.push({ idx, name: String(col).trim() });
      }
    });
    console.log('Date columns count:', dateCols.length);
    console.log('Latest 3 date columns:', dateCols.slice(-3));
  }

  let validKeywords = [];
  rows.forEach((r, idx) => {
    const kw = r[0];
    if (kw !== undefined && kw !== null && String(kw).trim() !== '') {
      const kwStr = String(kw).trim();
      console.log(`[${idx}] "${kwStr}"`);
    }
  });
}
