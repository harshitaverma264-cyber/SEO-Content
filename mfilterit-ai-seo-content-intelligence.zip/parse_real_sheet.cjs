const XLSX = require('xlsx');
const wb = XLSX.readFile('/tmp/downloaded_sheet.xlsx');

wb.SheetNames.forEach(name => {
  const ws = wb.Sheets[name];
  const rows = XLSX.utils.sheet_to_json(ws, { header: 1 });
  console.log(`\n=================== SHEET: ${name} (Total rows: ${rows.length}) ===================`);
  rows.forEach((r, idx) => {
    const kw = r[0];
    if (kw !== undefined && kw !== null && String(kw).trim() !== '') {
      console.log(`Row ${idx}: "${String(kw).trim()}" | Col1: ${r[1]} | Col2: ${r[2]} | TotalCols: ${r.length}`);
    }
  });
});
