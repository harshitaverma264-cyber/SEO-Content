const XLSX = require('xlsx');
const wb = XLSX.readFile('/app/applet/live_sharepoint_workbook.xlsx');

function parseRank(val) {
  if (val === null || val === undefined) return null;
  const str = String(val).trim();
  if (!str || str.toLowerCase() === 'unranked' || str.toLowerCase() === 'nr' || str.includes('100<') || str.includes('>100') || str.includes('100+')) {
    return null;
  }
  const match = str.match(/\b\d+\b/);
  if (match) {
    const n = parseInt(match[0], 10);
    return n > 100 ? null : n;
  }
  return null;
}

const allParsed = {};

for (const name of wb.SheetNames) {
  const ws = wb.Sheets[name];
  const rows = XLSX.utils.sheet_to_json(ws, { header: 1 });
  
  let headerRow = null;
  for (let i = 0; i < Math.min(10, rows.length); i++) {
    if (rows[i] && rows[i].some(cell => String(cell).includes('2026'))) {
      headerRow = rows[i];
      break;
    }
  }

  const dateCols = [];
  headerRow.forEach((col, idx) => {
    if (String(col).includes('2026') && !String(col).toLowerCase().includes('received')) {
      dateCols.push({ idx, name: String(col).trim() });
    }
  });

  const latestCol = dateCols[dateCols.length - 1];
  const prevCol = dateCols[dateCols.length - 2];

  const regionKey = name.toUpperCase() === 'MENA' ? 'MENA' : name.toUpperCase();
  allParsed[regionKey] = [];

  let currentSection = 'General';
  for (let r = 0; r < rows.length; r++) {
    const row = rows[r];
    if (!row || row.length === 0) continue;
    const firstCell = row[0];
    if (firstCell === undefined || firstCell === null) continue;
    const str = String(firstCell).trim();
    if (!str) continue;

    if (str.toLowerCase().includes('(ad fraud)') || str.toLowerCase().includes('(brand safety)') || 
        str.toLowerCase().includes('(brand protection)') || str.toLowerCase().includes('(ecommerce') || 
        str.toLowerCase().includes('( affiliate') || str.toLowerCase().includes('(creative compliance') ||
        str.toLowerCase().includes('region - keyword') || str === 'VALID 8' || str === 'Brand Safety' ||
        str === 'ECOM-mSCANIT' || str === 'EFFCENT' || str === 'SENTINEL+') {
      currentSection = str;
      continue;
    }

    if (str.toLowerCase() === 'keyword') continue;

    const prevPos = parseRank(row[prevCol.idx]);
    const currPos = parseRank(row[latestCol.idx]);
    
    let positionChange = null;
    let movement = 'STABLE';

    if (currPos !== null && prevPos !== null) {
      positionChange = prevPos - currPos;
      if (positionChange > 0) movement = 'IMPROVING';
      else if (positionChange < 0) movement = 'DECLINING';
      else movement = 'STABLE';
    } else if (currPos !== null && prevPos === null) {
      movement = 'NEWLY RANKING';
    }

    const vol = typeof row[1] === 'number' ? row[1] : parseInt(String(row[1] || '0').replace(/[^0-9]/g, '')) || 0;

    allParsed[regionKey].push({
      id: `${regionKey.toLowerCase()}-${allParsed[regionKey].length + 1}`,
      keyword: str,
      region: regionKey,
      previousPosition: prevPos,
      currentPosition: currPos,
      positionChange,
      movement,
      searchVolume: vol,
      section: currentSection,
      rawPrev: row[prevCol.idx],
      rawCurr: row[latestCol.idx]
    });
  }
}

console.log('Parsed counts:');
console.log('INDIA:', allParsed.INDIA.length);
console.log('USA:', allParsed.USA.length);
console.log('MENA:', allParsed.MENA.length);
console.log('TOTAL:', allParsed.INDIA.length + allParsed.USA.length + allParsed.MENA.length);

console.log('\n--- INDIA (First 10 of 81) ---');
allParsed.INDIA.slice(0, 10).forEach((k, i) => console.log(`${i+1}. "${k.keyword}" | Prev: ${k.previousPosition} (${k.rawPrev}) | Curr: ${k.currentPosition} (${k.rawCurr}) | Mov: ${k.movement}`));

console.log('\n--- USA (First 10 of 66) ---');
allParsed.USA.slice(0, 10).forEach((k, i) => console.log(`${i+1}. "${k.keyword}" | Prev: ${k.previousPosition} (${k.rawPrev}) | Curr: ${k.currentPosition} (${k.rawCurr}) | Mov: ${k.movement}`));

console.log('\n--- MENA (First 10 of 64) ---');
allParsed.MENA.slice(0, 10).forEach((k, i) => console.log(`${i+1}. "${k.keyword}" | Prev: ${k.previousPosition} (${k.rawPrev}) | Curr: ${k.currentPosition} (${k.rawCurr}) | Mov: ${k.movement}`));
module.exports = { allParsed };

