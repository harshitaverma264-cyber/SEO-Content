const XLSX = require('xlsx');
const wb = XLSX.readFile('/tmp/downloaded_sheet.xlsx');

for (const name of wb.SheetNames) {
  const ws = wb.Sheets[name];
  const rows = XLSX.utils.sheet_to_json(ws, { header: 1 });
  console.log(`\n=================== INSPECTING COLUMNS FOR: ${name} ===================`);
  
  // Find header row with date columns
  let headerRow = null;
  let headerIdx = -1;
  for (let i = 0; i < Math.min(10, rows.length); i++) {
    if (rows[i] && rows[i].some(cell => String(cell).includes('2026'))) {
      headerRow = rows[i];
      headerIdx = i;
      break;
    }
  }

  const dateCols = [];
  headerRow.forEach((col, idx) => {
    if (String(col).includes('2026') && !String(col).toLowerCase().includes('received')) {
      dateCols.push({ idx, name: String(col).trim() });
    }
  });

  const latestCol = dateCols[dateCols.length - 1];
  const prevCol = dateCols[dateCols.length - 2];
  console.log('Latest Col:', latestCol);
  console.log('Prev Col:', prevCol);

  // Check section detection and keywords
  const sectionKeywords = [];
  let currentSection = 'General';
  
  for (let r = 0; r < rows.length; r++) {
    const row = rows[r];
    if (!row || row.length === 0) continue;
    const firstCell = row[0];
    if (firstCell === undefined || firstCell === null) continue;
    const str = String(firstCell).trim();
    if (!str) continue;

    // Check if this is a section header (e.g. Valid8 (Ad Fraud), Pace (Brand Safety), etc.)
    // A section header usually has 1 or very few columns, or contains parentheses with product name, or is Row 0
    if (str.toLowerCase().includes('(ad fraud)') || str.toLowerCase().includes('(brand safety)') || 
        str.toLowerCase().includes('(brand protection)') || str.toLowerCase().includes('(ecommerce') || 
        str.toLowerCase().includes('( affiliate') || str.toLowerCase().includes('(creative compliance') ||
        str.toLowerCase().includes('region - keyword') || str === 'VALID 8' || str === 'Brand Safety' ||
        str === 'ECOM-mSCANIT' || str === 'EFFCENT' || str === 'SENTINEL+') {
      currentSection = str;
      continue;
    }

    if (str.toLowerCase() === 'keyword') {
      continue;
    }

    // This is a keyword row!
    const prevRankRaw = row[prevCol.idx];
    const currRankRaw = row[latestCol.idx];
    sectionKeywords.push({
      rowIdx: r,
      section: currentSection,
      keyword: str,
      searchVolume: row[1],
      prevRankRaw,
      currRankRaw
    });
  }

  console.log(`Found ${sectionKeywords.length} keywords in ${name}. First 5:`);
  sectionKeywords.slice(0, 5).forEach(k => {
    console.log(`  [Row ${k.rowIdx}] "${k.keyword}" (Vol: ${k.searchVolume}, Prev: ${k.prevRankRaw}, Curr: ${k.currRankRaw})`);
  });
}
